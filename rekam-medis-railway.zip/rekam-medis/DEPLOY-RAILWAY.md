# 🚀 Panduan Deploy ke Railway.app
### Apotek Sejahtera — Sistem Rekam Medis Laravel 11

---

## ⚡ Deploy dalam 5 Langkah

### LANGKAH 1 — Daftar GitHub & Upload Project

1. Daftar/login di **github.com**
2. Klik **➕ New repository**
3. Nama: `apotek-sejahtera` → Create repository
4. Upload semua isi folder project ini ke repository tersebut:
   - Bisa pakai **GitHub Desktop** (lebih mudah)
   - Atau drag & drop file di browser GitHub

---

### LANGKAH 2 — Daftar Railway

1. Buka **railway.app**
2. Klik **Login** → pilih **Login with GitHub**
3. Authorize Railway untuk akses GitHub Anda

---

### LANGKAH 3 — Buat Project Baru di Railway

1. Di dashboard Railway → klik **New Project**
2. Pilih **Deploy from GitHub repo**
3. Pilih repository `apotek-sejahtera`
4. Railway otomatis detect **Dockerfile** dan mulai build

---

### LANGKAH 4 — Tambah Database MySQL

1. Di project Railway → klik **+ Add Service**
2. Pilih **Database** → **MySQL**
3. Railway otomatis buat database dan inject variabel:
   - `MYSQLHOST`, `MYSQLPORT`, `MYSQLDATABASE`, `MYSQLUSER`, `MYSQLPASSWORD`

---

### LANGKAH 5 — Set Environment Variables

Di Railway → klik service Laravel → tab **Variables** → tambahkan:

```
APP_NAME=Apotek Sejahtera
APP_ENV=production
APP_DEBUG=false
APP_KEY=   (kosongkan, akan di-generate otomatis)

DB_CONNECTION=mysql
DB_HOST=${{MySQL.MYSQLHOST}}
DB_PORT=${{MySQL.MYSQLPORT}}
DB_DATABASE=${{MySQL.MYSQLDATABASE}}
DB_USERNAME=${{MySQL.MYSQLUSER}}
DB_PASSWORD=${{MySQL.MYSQLPASSWORD}}

SESSION_DRIVER=file
CACHE_DRIVER=file
QUEUE_CONNECTION=sync

# Opsional - Email
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=email@gmail.com
MAIL_PASSWORD=app_password_gmail
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=email@gmail.com

# Opsional - WhatsApp
FONNTE_TOKEN=token_dari_fonnte
```

**Klik Deploy** → tunggu 3-5 menit ✅

---

## 🌐 Akses Aplikasi

Setelah deploy selesai:
1. Railway otomatis beri domain: `https://nama-project.up.railway.app`
2. Set `APP_URL` ke domain tersebut di Variables
3. Buka URL → halaman login muncul!

**Akun Demo:**
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@apotek.com | password |
| Dokter | dokter@apotek.com | password |
| Apoteker | apoteker@apotek.com | password |
| Kasir | kasir@apotek.com | password |

---

## 🔧 Jika Ada Error

### Error: Build failed
```
Pastikan semua file ter-upload ke GitHub termasuk:
- Dockerfile
- docker/ folder (nginx.conf, supervisord.conf, php.ini, start.sh)
- composer.json
- package.json
```

### Error: Database connection
```
Pastikan variabel DB_HOST menggunakan:
${{MySQL.MYSQLHOST}}  ← format Railway untuk referensi service lain
```

### Error: APP_KEY not set
```
Di Variables, tambahkan:
APP_KEY=base64:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Generate dengan: php artisan key:generate --show
```

### Error: 500 Internal Server Error
```
1. Cek Logs di Railway dashboard
2. Pastikan APP_DEBUG=false di production
3. Pastikan DB_ variables sudah benar
```

---

## 💰 Harga Railway

| Plan | Harga | Batas |
|------|-------|-------|
| **Hobby (Gratis)** | $0 | $5 credit/bulan, tidur setelah inaktif |
| **Pro** | $20/bulan | Unlimited, tidak tidur |

> Untuk **demo / testing**: Plan gratis cukup!
> Untuk **production / klien**: Upgrade ke Pro ($20/bulan)

---

## 🔄 Update Aplikasi (Setelah Deploy Pertama)

Setiap kali ada perubahan code:
1. Push ke GitHub
2. Railway otomatis re-deploy dalam 2-3 menit ✅

---

## 🌍 Pakai Domain Sendiri (Opsional)

1. Di Railway → Settings → **Domains**
2. Klik **Custom Domain**
3. Masukkan domain Anda (misal: `apotek-sejahtera.com`)
4. Tambahkan CNAME record di DNS provider Anda
5. Railway otomatis setup SSL (HTTPS) gratis!

---

## 📱 Alternatif Platform Gratis Lainnya

| Platform | Cara Deploy |
|----------|-------------|
| **Render.com** | Sama seperti Railway, support Docker |
| **Fly.io** | Perlu install flyctl CLI |
| **Koyeb.com** | Deploy via GitHub, gratis |

---

*© 2025 Apotek Sejahtera — Built with Laravel 11*
