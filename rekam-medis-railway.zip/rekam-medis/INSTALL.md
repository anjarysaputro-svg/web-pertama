# 🏥 Apotek Sejahtera — Sistem Rekam Medis
### Laravel 11 + TailwindCSS + MySQL | Multi-Role | PDF | Excel | WhatsApp

---

## 📋 AKUN DEMO (Setelah Seeder)

| Role      | Email                  | Password   |
|-----------|------------------------|------------|
| Admin     | admin@apotek.com       | password   |
| Dokter    | dokter@apotek.com      | password   |
| Apoteker  | apoteker@apotek.com    | password   |
| Kasir     | kasir@apotek.com       | password   |

---

## 🖥️ KEBUTUHAN SERVER

- **PHP** 8.2 atau 8.3
- **MySQL** 8.0 / MariaDB 10.6
- **Composer** 2.x
- **Node.js** 20 LTS + NPM
- **Nginx** atau Apache
- **RAM** minimal 1GB (rekomendasi 2GB)

---

## 🚀 INSTALASI LOKAL (Development)

### 1. Install Dependencies PHP
```bash
composer install
```

### 2. Install Dependencies Node.js
```bash
npm install
```

### 3. Setup Environment
```bash
cp .env.example .env
php artisan key:generate
```

### 4. Buat Database MySQL
```sql
CREATE DATABASE rekam_medis CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 5. Edit file `.env`
```env
DB_DATABASE=rekam_medis
DB_USERNAME=root
DB_PASSWORD=your_password
```

### 6. Publish & Jalankan Migrasi
```bash
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
php artisan migrate
php artisan db:seed
```

### 7. Build Assets
```bash
npm run dev
# Atau untuk production:
npm run build
```

### 8. Buat Storage Link
```bash
php artisan storage:link
```

### 9. Jalankan Server
```bash
php artisan serve
```

Buka browser: **http://localhost:8000**

---

## 🌐 DEPLOY KE VPS (Ubuntu 22.04)

### A. Install PHP 8.2 + Extensions
```bash
sudo apt update && sudo apt upgrade -y
sudo add-apt-repository ppa:ondrej/php -y && sudo apt update
sudo apt install -y php8.2 php8.2-fpm php8.2-mysql php8.2-mbstring \
  php8.2-xml php8.2-curl php8.2-zip php8.2-gd php8.2-redis \
  php8.2-bcmath php8.2-tokenizer php8.2-intl
```

### B. Install MySQL, Nginx, Redis
```bash
sudo apt install -y mysql-server nginx redis-server
sudo mysql_secure_installation
```

### C. Install Composer & Node.js
```bash
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

### D. Upload & Setup Project
```bash
# Upload project ke /var/www/rekam-medis
cd /var/www/rekam-medis

# Install dependencies production
composer install --no-dev --optimize-autoloader
npm ci && npm run build

# Setup environment
cp .env.example .env
php artisan key:generate
# Edit .env: DB, MAIL, FONNTE_TOKEN, APP_URL, APP_DEBUG=false

# Migrasi & Seeder
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
php artisan migrate --force
php artisan db:seed --force

# Storage link & optimize
php artisan storage:link
php artisan optimize

# Permission
sudo chown -R www-data:www-data /var/www/rekam-medis
sudo chmod -R 775 storage bootstrap/cache
```

### E. Konfigurasi Nginx
```nginx
# /etc/nginx/sites-available/rekam-medis
server {
    listen 80;
    server_name domain-anda.com;
    root /var/www/rekam-medis/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    client_max_body_size 10M;
}
```
```bash
sudo ln -s /etc/nginx/sites-available/rekam-medis /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

### F. SSL dengan Let's Encrypt
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d domain-anda.com
```

---

## 📱 KONFIGURASI WHATSAPP (Fonnte)

1. Daftar di https://fonnte.com
2. Sambungkan nomor WhatsApp
3. Copy token dari dashboard
4. Isi di `.env`:
```env
FONNTE_TOKEN=token_anda_disini
```

---

## 📧 KONFIGURASI EMAIL (Gmail)

1. Aktifkan **2-Step Verification** di Google Account
2. Buat **App Password** di https://myaccount.google.com/apppasswords
3. Isi di `.env`:
```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=email@gmail.com
MAIL_PASSWORD=app_password_16_karakter
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=email@gmail.com
```

---

## 📦 FITUR LENGKAP

| No | Modul              | Fitur                                      |
|----|--------------------|--------------------------------------------|
| 1  | Dashboard          | Statistik, grafik Chart.js, stok kritis    |
| 2  | Data Pasien        | CRUD, foto, export Excel                   |
| 3  | Data Dokter        | CRUD, spesialis, jadwal                    |
| 4  | Poliklinik         | CRUD, dokter PJ                            |
| 5  | Data Obat          | CRUD, stok, expired, alert kritis          |
| 6  | Rekam Medis        | SOAP, tanda vital, diagnosis, status       |
| 7  | Hasil MCU          | 6 kategori lab, cetak PDF DomPDF           |
| 8  | Resep Dokter       | Buat resep, auto kurangi stok              |
| 9  | Tindakan Medis     | Jenis tindakan, tarif, status              |
| 10 | Billing            | Invoice PDF, status bayar, metode          |
| 11 | Laporan            | Export Excel (Maatwebsite), PDF bulanan    |
| 12 | Notifikasi         | Email Laravel Mail, WhatsApp Fonnte API    |
| 13 | Manajemen User     | CRUD user, assign role Spatie              |
| 14 | Multi-Role Auth    | Admin, Dokter, Apoteker, Kasir             |
| 15 | Responsive         | Mobile (bottom nav), tablet, desktop       |

---

## 🔐 ROLE & AKSES

| Fitur          | Admin | Dokter | Apoteker | Kasir |
|----------------|-------|--------|----------|-------|
| Dashboard      | ✅    | ✅     | ✅       | ✅    |
| Pasien         | ✅    | ✅     | 👁️       | 👁️    |
| Dokter         | ✅    | ❌     | ❌       | ❌    |
| Obat           | ✅    | ❌     | ✅       | ❌    |
| Rekam Medis    | ✅    | ✅     | ❌       | ❌    |
| MCU            | ✅    | ✅     | ❌       | ❌    |
| Resep          | ✅    | ✅     | ✅       | ❌    |
| Tindakan       | ✅    | ✅     | ❌       | ❌    |
| Billing        | ✅    | ❌     | ❌       | ✅    |
| Laporan        | ✅    | ❌     | ❌       | ❌    |
| Notifikasi     | ✅    | ❌     | ❌       | ❌    |
| User Mgmt      | ✅    | ❌     | ❌       | ❌    |

---

## ❓ TROUBLESHOOTING

**Error: Permission denied storage/**
```bash
sudo chmod -R 775 storage bootstrap/cache
sudo chown -R www-data:www-data storage bootstrap/cache
```

**Error: Class not found (Spatie)**
```bash
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
php artisan migrate
php artisan optimize:clear
```

**Error: Vite manifest not found**
```bash
npm install && npm run build
```

**Tampilan CSS tidak muncul**
```bash
npm run build
# atau saat dev:
npm run dev
```

---

© 2025 Apotek Sejahtera. Built with ❤️ using Laravel 11.
