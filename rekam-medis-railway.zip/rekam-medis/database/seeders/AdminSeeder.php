<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        $users = [
            ['name' => 'Administrator',   'email' => 'admin@apotek.com',    'password' => 'password', 'role' => 'admin'],
            ['name' => 'dr. Budi Hartono','email' => 'dokter@apotek.com',   'password' => 'password', 'role' => 'dokter'],
            ['name' => 'Siti Apoteker',   'email' => 'apoteker@apotek.com', 'password' => 'password', 'role' => 'apoteker'],
            ['name' => 'Kasir Apotek',    'email' => 'kasir@apotek.com',    'password' => 'password', 'role' => 'kasir'],
        ];

        foreach ($users as $u) {
            $user = User::firstOrCreate(
                ['email' => $u['email']],
                ['name'  => $u['name'], 'password' => Hash::make($u['password'])]
            );
            $user->syncRoles([$u['role']]);
            $this->command->info("✅ User {$u['name']} ({$u['role']}) siap — {$u['email']} / {$u['password']}");
        }
    }
}
