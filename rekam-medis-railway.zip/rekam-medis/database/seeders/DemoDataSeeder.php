<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\{Dokter, Poliklinik, Obat, Pasien, RekamMedis, HasilMcu, Resep, Tindakan, Billing};
use App\Models\User;
use Carbon\Carbon;

class DemoDataSeeder extends Seeder
{
    public function run(): void
    {
        // Dokter
        $dokter1 = Dokter::create(['nama'=>'dr. Budi Hartono','spesialis'=>'Dokter Umum','sip'=>'SIP-001/2024','no_hp'=>'0812-1111-2222','jadwal'=>'Senin–Jumat, 08:00–14:00','status'=>'Aktif','user_id'=>User::where('email','dokter@apotek.com')->first()?->id]);
        $dokter2 = Dokter::create(['nama'=>'dr. Ratna Sari, Sp.PD','spesialis'=>'Penyakit Dalam','sip'=>'SIP-002/2024','no_hp'=>'0812-3333-4444','jadwal'=>'Selasa & Kamis, 09:00–13:00','status'=>'Aktif']);
        $dokter3 = Dokter::create(['nama'=>'dr. Hendra Wijaya, Sp.A','spesialis'=>'Anak','sip'=>'SIP-003/2024','no_hp'=>'0812-5555-6666','jadwal'=>'Senin, Rabu, Jumat, 10:00–14:00','status'=>'Aktif']);

        // Poliklinik
        Poliklinik::create(['kode'=>'PLI-001','nama'=>'Poli Umum','gedung'=>'Gedung A / Lantai 1','dokter_id'=>$dokter1->id,'status'=>'Aktif']);
        Poliklinik::create(['kode'=>'PLI-002','nama'=>'Poli Penyakit Dalam','gedung'=>'Gedung A / Lantai 2','dokter_id'=>$dokter2->id,'status'=>'Aktif']);
        $poli3 = Poliklinik::create(['kode'=>'PLI-003','nama'=>'Poli Anak','gedung'=>'Gedung B / Lantai 1','dokter_id'=>$dokter3->id,'status'=>'Aktif']);

        // Obat
        $obat1 = Obat::create(['kode'=>'OBT-001','nama'=>'Amoxicillin 500mg','satuan'=>'Kapsul','kategori'=>'Antibiotik','stok'=>150,'harga'=>3500,'expired'=>'2026-12-31']);
        $obat2 = Obat::create(['kode'=>'OBT-002','nama'=>'Paracetamol 500mg','satuan'=>'Tablet','kategori'=>'Analgesik','stok'=>300,'harga'=>1500,'expired'=>'2027-06-30']);
        $obat3 = Obat::create(['kode'=>'OBT-003','nama'=>'Amlodipine 5mg','satuan'=>'Tablet','kategori'=>'Antihipertensi','stok'=>80,'harga'=>5000,'expired'=>'2026-09-30']);
        $obat4 = Obat::create(['kode'=>'OBT-004','nama'=>'Metformin 500mg','satuan'=>'Tablet','kategori'=>'Antidiabetes','stok'=>8,'harga'=>4000,'expired'=>'2026-03-31','keterangan'=>'Stok menipis']);
        Obat::create(['kode'=>'OBT-005','nama'=>'Vitamin C 1000mg','satuan'=>'Tablet','kategori'=>'Vitamin','stok'=>200,'harga'=>2500,'expired'=>'2027-12-31']);
        Obat::create(['kode'=>'OBT-006','nama'=>'Omeprazole 20mg','satuan'=>'Kapsul','kategori'=>'Antasida','stok'=>5,'harga'=>6000,'expired'=>'2025-12-31','keterangan'=>'Stok kritis!']);
        Obat::create(['kode'=>'OBT-007','nama'=>'Salbutamol Sirup','satuan'=>'Botol','kategori'=>'Bronkodilator','stok'=>45,'harga'=>18000,'expired'=>'2026-06-30']);

        // Pasien
        $pasiens = [
            ['nama'=>'Budi Santoso','tgl_lahir'=>'1985-03-12','jenis_kelamin'=>'Laki-laki','gol_darah'=>'A','no_hp'=>'0812-3456-7890','email'=>'budi@email.com','alamat'=>'Jl. Melati No.5, Jakarta','pekerjaan'=>'Wiraswasta','alergi'=>'Penisilin','riwayat_penyakit'=>'Hipertensi'],
            ['nama'=>'Siti Rahayu','tgl_lahir'=>'1990-07-22','jenis_kelamin'=>'Perempuan','gol_darah'=>'O','no_hp'=>'0856-9876-5432','email'=>'siti@email.com','alamat'=>'Jl. Kenanga No.10, Bandung','pekerjaan'=>'Guru','alergi'=>null,'riwayat_penyakit'=>null],
            ['nama'=>'Ahmad Fauzi','tgl_lahir'=>'1978-11-05','jenis_kelamin'=>'Laki-laki','gol_darah'=>'B','no_hp'=>'0877-1122-3344','email'=>null,'alamat'=>'Jl. Mawar No.3, Surabaya','pekerjaan'=>'PNS','alergi'=>null,'riwayat_penyakit'=>'Diabetes Tipe 2'],
            ['nama'=>'Dewi Lestari','tgl_lahir'=>'1995-01-30','jenis_kelamin'=>'Perempuan','gol_darah'=>'AB','no_hp'=>'0821-5566-7788','email'=>null,'alamat'=>'Jl. Anggrek No.7, Medan','pekerjaan'=>'Karyawan','alergi'=>null,'riwayat_penyakit'=>null],
            ['nama'=>'Eko Prasetyo','tgl_lahir'=>'1988-09-14','jenis_kelamin'=>'Laki-laki','gol_darah'=>'A','no_hp'=>'0813-9900-1122','email'=>null,'alamat'=>'Jl. Dahlia No.2, Yogyakarta','pekerjaan'=>'Petani','alergi'=>null,'riwayat_penyakit'=>'Asma'],
            ['nama'=>'Rina Fitriani','tgl_lahir'=>'1992-05-18','jenis_kelamin'=>'Perempuan','gol_darah'=>'B','no_hp'=>'0856-3344-5566','email'=>null,'alamat'=>'Jl. Cempaka No.9, Semarang','pekerjaan'=>'Ibu Rumah Tangga','alergi'=>null,'riwayat_penyakit'=>null],
        ];
        $createdPasiens = [];
        foreach ($pasiens as $pd) {
            $createdPasiens[] = Pasien::create($pd);
        }

        // Rekam Medis
        $rekams = [
            ['pasien_id'=>$createdPasiens[0]->id,'dokter_id'=>$dokter2->id,'tgl_kunjungan'=>'2025-05-01','keluhan'=>'Pusing dan nyeri kepala','diagnosis'=>'Hipertensi Stage 2','terapi'=>'Amlodipine 5mg 1x1','tekanan_darah'=>'148/92','nadi'=>'82','suhu'=>'36.8','berat_badan'=>78,'tinggi_badan'=>170,'status'=>'Dalam Perawatan'],
            ['pasien_id'=>$createdPasiens[1]->id,'dokter_id'=>$dokter1->id,'tgl_kunjungan'=>'2025-05-02','keluhan'=>'Batuk pilek 3 hari','diagnosis'=>'ISPA','terapi'=>'Amoxicillin 3x1, Paracetamol 3x1','tekanan_darah'=>'112/72','nadi'=>'76','suhu'=>'37.5','berat_badan'=>55,'tinggi_badan'=>158,'status'=>'Sembuh'],
            ['pasien_id'=>$createdPasiens[2]->id,'dokter_id'=>$dokter2->id,'tgl_kunjungan'=>'2025-05-03','keluhan'=>'Lemas, sering haus, sering kencing','diagnosis'=>'Diabetes Mellitus Tipe 2','terapi'=>'Metformin 2x1','tekanan_darah'=>'120/80','nadi'=>'78','suhu'=>'36.5','berat_badan'=>72,'tinggi_badan'=>165,'status'=>'Dalam Perawatan'],
            ['pasien_id'=>$createdPasiens[3]->id,'dokter_id'=>$dokter1->id,'tgl_kunjungan'=>'2025-05-04','keluhan'=>'Nyeri ulu hati, mual','diagnosis'=>'Gastritis Akut','terapi'=>'Omeprazole 1x1','tekanan_darah'=>'110/70','nadi'=>'74','suhu'=>'36.6','berat_badan'=>52,'tinggi_badan'=>155,'status'=>'Sembuh'],
            ['pasien_id'=>$createdPasiens[4]->id,'dokter_id'=>$dokter1->id,'tgl_kunjungan'=>'2025-05-05','keluhan'=>'Sesak napas, mengi','diagnosis'=>'Bronkitis Akut + Eksaserbasi Asma','terapi'=>'Salbutamol nebulisasi','tekanan_darah'=>'118/76','nadi'=>'88','suhu'=>'37.2','berat_badan'=>68,'tinggi_badan'=>168,'status'=>'Dirujuk'],
            ['pasien_id'=>$createdPasiens[5]->id,'dokter_id'=>$dokter3->id,'tgl_kunjungan'=>'2025-05-06','keluhan'=>'Demam tinggi 3 hari, bintik merah','diagnosis'=>'Demam Berdarah Dengue','terapi'=>'Infus RL, monitoring trombosit','tekanan_darah'=>'100/65','nadi'=>'92','suhu'=>'38.8','berat_badan'=>48,'tinggi_badan'=>158,'status'=>'Dalam Perawatan'],
        ];
        $createdRekams = [];
        $uid = User::first()?->id;
        foreach ($rekams as $rd) {
            $createdRekams[] = RekamMedis::create($rd + ['user_id' => $uid]);
        }

        // Resep
        Resep::create(['pasien_id'=>$createdPasiens[0]->id,'rekam_medis_id'=>$createdRekams[0]->id,'obat_id'=>$obat3->id,'jumlah'=>30,'dosis'=>'1x1 tablet','aturan'=>'Sebelum tidur','status'=>'Diberikan','user_id'=>$uid]);
        Resep::create(['pasien_id'=>$createdPasiens[1]->id,'rekam_medis_id'=>$createdRekams[1]->id,'obat_id'=>$obat1->id,'jumlah'=>21,'dosis'=>'3x1 kapsul','aturan'=>'Sesudah makan','status'=>'Diberikan','user_id'=>$uid]);
        Resep::create(['pasien_id'=>$createdPasiens[2]->id,'rekam_medis_id'=>$createdRekams[2]->id,'obat_id'=>$obat4->id,'jumlah'=>60,'dosis'=>'2x1 tablet','aturan'=>'Sesudah makan','status'=>'Diberikan','user_id'=>$uid]);
        Resep::create(['pasien_id'=>$createdPasiens[3]->id,'rekam_medis_id'=>$createdRekams[3]->id,'obat_id'=>$obat2->id,'jumlah'=>10,'dosis'=>'3x1 tablet','aturan'=>'Bila perlu','status'=>'Menunggu','user_id'=>$uid]);

        // Tindakan
        Tindakan::create(['pasien_id'=>$createdPasiens[0]->id,'dokter_id'=>$dokter2->id,'rekam_medis_id'=>$createdRekams[0]->id,'jenis'=>'Pemeriksaan Fisik Lengkap','tarif'=>75000,'tgl'=>'2025-05-01','status'=>'Selesai','user_id'=>$uid]);
        Tindakan::create(['pasien_id'=>$createdPasiens[4]->id,'dokter_id'=>$dokter1->id,'rekam_medis_id'=>$createdRekams[4]->id,'jenis'=>'Nebulisasi','tarif'=>50000,'tgl'=>'2025-05-05','status'=>'Selesai','user_id'=>$uid]);
        Tindakan::create(['pasien_id'=>$createdPasiens[5]->id,'dokter_id'=>$dokter3->id,'rekam_medis_id'=>$createdRekams[5]->id,'jenis'=>'Pemasangan Infus','tarif'=>120000,'tgl'=>'2025-05-06','status'=>'Dalam Proses','user_id'=>$uid]);

        // Billing
        Billing::create(['pasien_id'=>$createdPasiens[0]->id,'layanan'=>'Konsultasi Spesialis + Obat','total'=>225000,'bayar'=>225000,'metode'=>'Tunai','status'=>'Lunas','tgl'=>'2025-05-01','user_id'=>$uid]);
        Billing::create(['pasien_id'=>$createdPasiens[1]->id,'layanan'=>'Konsultasi Umum + Obat','total'=>105000,'bayar'=>105000,'metode'=>'BPJS','status'=>'Lunas','tgl'=>'2025-05-02','user_id'=>$uid]);
        Billing::create(['pasien_id'=>$createdPasiens[2]->id,'layanan'=>'Konsultasi Spesialis + Obat','total'=>280000,'bayar'=>150000,'metode'=>'Transfer','status'=>'Cicilan','tgl'=>'2025-05-03','user_id'=>$uid]);
        Billing::create(['pasien_id'=>$createdPasiens[4]->id,'layanan'=>'Tindakan Medis + Obat','total'=>200000,'bayar'=>0,'metode'=>'-','status'=>'Belum Bayar','tgl'=>'2025-05-05','user_id'=>$uid]);

        // MCU
        HasilMcu::create([
            'pasien_id'  => $createdPasiens[0]->id,
            'dokter_id'  => $dokter1->id,
            'tgl'        => '2025-04-10',
            'jenis'      => 'MCU Komprehensif',
            'fisik'      => ['bb'=>78,'tb'=>170,'bmi'=>27.0,'sistol'=>148,'diastol'=>92,'nadi'=>82,'napas'=>18,'suhu'=>36.8,'spo2'=>97,'lp'=>92,'ping'=>88],
            'darah'      => ['hb'=>14.2,'ht'=>44,'rbc'=>4.8,'wbc'=>7.2,'plt'=>220,'mcv'=>88,'mch'=>29,'mchc'=>33,'led'=>12,'netro'=>65,'limfo'=>28,'mono'=>5,'eosi'=>1,'baso'=>1,'batang'=>0],
            'kimia'      => ['gdp'=>108,'gpp'=>145,'hba1c'=>6.1,'kol'=>218,'hdl'=>45,'ldl'=>138,'trig'=>175,'au'=>6.8,'krea'=>1.1,'bun'=>18,'sgot'=>32,'sgpt'=>38,'bili'=>0.9,'prot'=>7.2,'alb'=>4.2,'ca'=>9.4,'na'=>140,'k'=>4.1,'tsh'=>2.1,'ft4'=>1.2,'ft3'=>3.1],
            'urin'       => ['warna'=>'Kuning Jernih','jernih'=>'Jernih','ph'=>6.0,'bj'=>1.018,'prot'=>'Negatif','gluk'=>'Negatif','keton'=>'Negatif','darah'=>'Negatif','nitrit'=>'Negatif','leu'=>'Negatif','seri'=>1,'sleu'=>2,'silinder'=>'Tidak Ada','bakteri'=>'Negatif'],
            'jantung'    => ['ekg'=>'Normal Sinus Rhythm','irama'=>82,'hasil'=>'Normal','trop'=>'Negatif','ckmb'=>18,'rontgen'=>'Normal','cor'=>'Normal','pulmo'=>'Normal','fvc'=>3.8,'fev1'=>3.2,'ratio'=>0.84],
            'mata'       => ['od'=>'6/6','os'=>'6/6','tio_r'=>16,'tio_l'=>15,'bwarna'=>'Normal','fundus'=>'Retinopati Hipertensi','audio_r'=>20,'audio_l'=>18,'telinga'=>'Normal','hidung'=>'Deviasi Septum','tenggo'=>'Normal','gigi'=>'Karies Gigi'],
            'kategori'   => 'Sehat dengan Catatan',
            'risiko'     => 'Sedang',
            'kesimpulan' => 'Tekanan darah tinggi (hipertensi stage 2), kolesterol dan LDL di atas normal, GDP mengarah pre-diabetes. Berat badan berlebih (overweight).',
            'rekomendasi'=> 'Kontrol tekanan darah rutin, diet rendah lemak dan garam, olahraga teratur 30 menit/hari, konsultasi gizi, kontrol ulang 3 bulan.',
            'followup'   => '2025-07-10',
            'status'     => 'Selesai',
            'user_id'    => $uid,
        ]);

        HasilMcu::create([
            'pasien_id'  => $createdPasiens[1]->id,
            'dokter_id'  => $dokter1->id,
            'tgl'        => '2025-04-15',
            'jenis'      => 'MCU Standard',
            'fisik'      => ['bb'=>55,'tb'=>158,'bmi'=>22.0,'sistol'=>112,'diastol'=>72,'nadi'=>76,'napas'=>16,'suhu'=>36.5,'spo2'=>99,'lp'=>72,'ping'=>68],
            'darah'      => ['hb'=>12.8,'ht'=>38,'rbc'=>4.2,'wbc'=>6.5,'plt'=>280,'mcv'=>85,'mch'=>28,'mchc'=>33,'led'=>10,'netro'=>58,'limfo'=>32,'mono'=>6,'eosi'=>3,'baso'=>1,'batang'=>0],
            'kimia'      => ['gdp'=>88,'gpp'=>120,'hba1c'=>5.2,'kol'=>178,'hdl'=>62,'ldl'=>98,'trig'=>110,'au'=>4.5,'krea'=>0.8,'bun'=>14,'sgot'=>24,'sgpt'=>22,'bili'=>0.7,'prot'=>7.0,'alb'=>4.5,'ca'=>9.2,'na'=>138,'k'=>3.9,'tsh'=>1.8,'ft4'=>1.3,'ft3'=>3.5],
            'urin'       => ['warna'=>'Kuning Jernih','jernih'=>'Jernih','ph'=>6.5,'bj'=>1.015,'prot'=>'Negatif','gluk'=>'Negatif','keton'=>'Negatif','darah'=>'Negatif','nitrit'=>'Negatif','leu'=>'Negatif','seri'=>0,'sleu'=>1,'silinder'=>'Tidak Ada','bakteri'=>'Negatif'],
            'jantung'    => ['ekg'=>'Normal Sinus Rhythm','irama'=>76,'hasil'=>'Normal','trop'=>'Negatif','ckmb'=>14,'rontgen'=>'Normal','cor'=>'Normal','pulmo'=>'Normal','fvc'=>3.2,'fev1'=>2.8,'ratio'=>0.88],
            'mata'       => ['od'=>'6/6','os'=>'6/6','tio_r'=>14,'tio_l'=>14,'bwarna'=>'Normal','fundus'=>'Normal','audio_r'=>15,'audio_l'=>16,'telinga'=>'Normal','hidung'=>'Normal','tenggo'=>'Normal','gigi'=>'Normal'],
            'kategori'   => 'Sehat – Fit untuk Bekerja',
            'risiko'     => 'Rendah',
            'kesimpulan' => 'Semua hasil pemeriksaan dalam batas normal. Kondisi kesehatan sangat baik.',
            'rekomendasi'=> 'Pertahankan pola hidup sehat. MCU ulang dianjurkan 1 tahun kemudian.',
            'followup'   => '2026-04-15',
            'status'     => 'Selesai',
            'user_id'    => $uid,
        ]);

        $this->command->info('✅ Demo data berhasil ditambahkan!');
    }
}
