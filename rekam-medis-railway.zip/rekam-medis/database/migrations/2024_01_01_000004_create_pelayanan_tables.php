<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {

        Schema::create('rekam_medis', function (Blueprint $t) {
            $t->id();
            $t->string('no_rm_kunjungan')->unique();
            $t->foreignId('pasien_id')->constrained('pasiens')->cascadeOnDelete();
            $t->foreignId('dokter_id')->nullable()->constrained('dokters')->nullOnDelete();
            $t->foreignId('poliklinik_id')->nullable()->constrained('polikliniks')->nullOnDelete();
            $t->date('tgl_kunjungan');
            $t->text('keluhan');
            $t->text('diagnosis');
            $t->text('terapi')->nullable();
            $t->string('tekanan_darah', 20)->nullable();
            $t->string('nadi', 10)->nullable();
            $t->string('suhu', 10)->nullable();
            $t->decimal('berat_badan', 5, 1)->nullable();
            $t->decimal('tinggi_badan', 5, 1)->nullable();
            $t->text('catatan')->nullable();
            $t->enum('status', ['Dalam Perawatan','Sembuh','Dirujuk'])->default('Dalam Perawatan');
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('reseps', function (Blueprint $t) {
            $t->id();
            $t->string('no_resep')->unique();
            $t->foreignId('rekam_medis_id')->nullable()->constrained('rekam_medis')->nullOnDelete();
            $t->foreignId('pasien_id')->constrained('pasiens')->cascadeOnDelete();
            $t->foreignId('obat_id')->constrained('obats')->cascadeOnDelete();
            $t->integer('jumlah');
            $t->string('dosis', 50);
            $t->string('aturan', 100);
            $t->text('catatan')->nullable();
            $t->enum('status', ['Menunggu','Diberikan','Batal'])->default('Menunggu');
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('tindakans', function (Blueprint $t) {
            $t->id();
            $t->string('kode')->unique();
            $t->foreignId('pasien_id')->constrained('pasiens')->cascadeOnDelete();
            $t->foreignId('dokter_id')->nullable()->constrained('dokters')->nullOnDelete();
            $t->foreignId('rekam_medis_id')->nullable()->constrained('rekam_medis')->nullOnDelete();
            $t->string('jenis');
            $t->integer('tarif')->default(0);
            $t->date('tgl');
            $t->text('catatan')->nullable();
            $t->enum('status', ['Dalam Proses','Selesai'])->default('Selesai');
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('billings', function (Blueprint $t) {
            $t->id();
            $t->string('no_tagihan')->unique();
            $t->foreignId('pasien_id')->constrained('pasiens')->cascadeOnDelete();
            $t->string('layanan');
            $t->integer('total')->default(0);
            $t->integer('bayar')->default(0);
            $t->string('metode', 30)->default('Tunai');
            $t->text('catatan')->nullable();
            $t->enum('status', ['Belum Bayar','Cicilan','Lunas'])->default('Belum Bayar');
            $t->date('tgl');
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamps();
        });

        Schema::create('hasil_mcus', function (Blueprint $t) {
            $t->id();
            $t->string('no_mcu')->unique();
            $t->foreignId('pasien_id')->constrained('pasiens')->cascadeOnDelete();
            $t->foreignId('dokter_id')->nullable()->constrained('dokters')->nullOnDelete();
            $t->date('tgl');
            $t->string('jenis')->default('MCU Komprehensif');
            $t->json('fisik')->nullable();
            $t->json('darah')->nullable();
            $t->json('kimia')->nullable();
            $t->json('urin')->nullable();
            $t->json('jantung')->nullable();
            $t->json('mata')->nullable();
            $t->string('kategori')->nullable();
            $t->enum('risiko', ['Rendah','Sedang','Tinggi'])->default('Rendah');
            $t->text('kesimpulan')->nullable();
            $t->text('rekomendasi')->nullable();
            $t->date('followup')->nullable();
            $t->enum('status', ['Selesai','Menunggu Lab','Perlu Review Dokter'])->default('Selesai');
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('hasil_mcus');
        Schema::dropIfExists('billings');
        Schema::dropIfExists('tindakans');
        Schema::dropIfExists('reseps');
        Schema::dropIfExists('rekam_medis');
    }
};
