<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('dokters', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->string('nama');
            $t->string('spesialis');
            $t->string('sip', 50)->nullable();
            $t->string('no_hp', 20)->nullable();
            $t->string('jadwal')->nullable();
            $t->string('foto')->nullable();
            $t->enum('status', ['Aktif','Non-Aktif'])->default('Aktif');
            $t->timestamps();
        });

        Schema::create('polikliniks', function (Blueprint $t) {
            $t->id();
            $t->string('kode')->unique();
            $t->string('nama');
            $t->string('gedung')->nullable();
            $t->foreignId('dokter_id')->nullable()->constrained('dokters')->nullOnDelete();
            $t->enum('status', ['Aktif','Non-Aktif'])->default('Aktif');
            $t->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('polikliniks');
        Schema::dropIfExists('dokters');
    }
};
