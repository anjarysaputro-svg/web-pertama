<?php
// database/migrations/2024_01_01_000001_create_pasiens_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('pasiens', function (Blueprint $t) {
            $t->id();
            $t->string('no_rm')->unique();
            $t->string('nama');
            $t->date('tgl_lahir')->nullable();
            $t->enum('jenis_kelamin', ['Laki-laki','Perempuan'])->nullable();
            $t->enum('gol_darah', ['A','B','AB','O'])->nullable();
            $t->string('no_hp', 20)->nullable();
            $t->string('email', 100)->nullable();
            $t->text('alamat')->nullable();
            $t->string('pekerjaan', 100)->nullable();
            $t->string('alergi', 200)->nullable();
            $t->string('riwayat_penyakit', 200)->nullable();
            $t->string('foto')->nullable();
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('pasiens'); }
};
