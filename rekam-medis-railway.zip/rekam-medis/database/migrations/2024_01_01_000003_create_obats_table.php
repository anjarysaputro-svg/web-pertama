<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('obats', function (Blueprint $t) {
            $t->id();
            $t->string('kode')->unique();
            $t->string('nama');
            $t->string('satuan', 30)->default('Tablet');
            $t->string('kategori', 50)->default('Lainnya');
            $t->integer('stok')->default(0);
            $t->integer('harga')->default(0);
            $t->date('expired')->nullable();
            $t->text('keterangan')->nullable();
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('obats'); }
};
