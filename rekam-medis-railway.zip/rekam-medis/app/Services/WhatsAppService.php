<?php
namespace App\Services;
use Illuminate\Support\Facades\Http;

class WhatsAppService
{
    private string $token;
    private string $baseUrl = 'https://api.fonnte.com';

    public function __construct()
    {
        $this->token = config('services.fonnte.token', '');
    }

    public function send(string $nomorHp, string $pesan): array
    {
        // Bersihkan nomor HP (hilangkan strip dan spasi)
        $nomor = preg_replace('/[^0-9]/', '', $nomorHp);
        // Ganti awalan 0 dengan 62
        if (str_starts_with($nomor, '0')) {
            $nomor = '62' . substr($nomor, 1);
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => $this->token,
            ])->post($this->baseUrl . '/send', [
                'target'  => $nomor,
                'message' => $pesan,
                'delay'   => '2',
            ]);
            return $response->json() ?? ['status' => false];
        } catch (\Exception $e) {
            return ['status' => false, 'reason' => $e->getMessage()];
        }
    }

    public function sendMcuReminder(\App\Models\Pasien $pasien, \App\Models\HasilMcu $mcu): array
    {
        $pesan  = "*APOTEK SEJAHTERA* 🏥\n\n";
        $pesan .= "Halo _{$pasien->nama}_,\n\n";
        $pesan .= "Hasil *Medical Check-Up (MCU)* Anda sudah tersedia.\n\n";
        $pesan .= "📅 Tanggal MCU : *{$mcu->tgl->format('d F Y')}*\n";
        $pesan .= "🏷️ Jenis       : *{$mcu->jenis}*\n";
        $pesan .= "✅ Kategori    : *{$mcu->kategori}*\n";
        $pesan .= "⚠️ Risiko      : *{$mcu->risiko}*\n\n";
        $pesan .= "Silakan hubungi kami untuk konsultasi lebih lanjut.\n\n";
        $pesan .= "_Terima kasih telah mempercayai Apotek Sejahtera._ 🙏";
        return $this->send($pasien->no_hp, $pesan);
    }
}
