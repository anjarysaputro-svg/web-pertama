<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class RekamMedis extends Model
{
    use HasFactory;
    protected $table    = 'rekam_medis';
    protected $fillable = [
        'no_rm_kunjungan','pasien_id','dokter_id','poliklinik_id',
        'tgl_kunjungan','keluhan','diagnosis','terapi',
        'tekanan_darah','nadi','suhu','berat_badan','tinggi_badan',
        'catatan','status','user_id',
    ];
    protected $casts = ['tgl_kunjungan' => 'date'];

    public function pasien()     { return $this->belongsTo(Pasien::class); }
    public function dokter()     { return $this->belongsTo(Dokter::class); }
    public function poliklinik() { return $this->belongsTo(Poliklinik::class); }
    public function reseps()     { return $this->hasMany(Resep::class); }
    public function tindakans()  { return $this->hasMany(Tindakan::class); }
    public function user()       { return $this->belongsTo(User::class); }

    protected static function booted()
    {
        static::creating(function ($m) {
            $m->no_rm_kunjungan = 'RK-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        });
    }
}
