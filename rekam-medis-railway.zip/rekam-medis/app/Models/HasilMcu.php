<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class HasilMcu extends Model
{
    use HasFactory;
    protected $table    = 'hasil_mcus';
    protected $fillable = [
        'no_mcu','pasien_id','dokter_id','tgl','jenis',
        'fisik','darah','kimia','urin','jantung','mata',
        'kategori','risiko','kesimpulan','rekomendasi',
        'followup','status','user_id',
    ];
    protected $casts = [
        'tgl'      => 'date',
        'followup' => 'date',
        'fisik'    => 'array',
        'darah'    => 'array',
        'kimia'    => 'array',
        'urin'     => 'array',
        'jantung'  => 'array',
        'mata'     => 'array',
    ];

    public function pasien() { return $this->belongsTo(Pasien::class); }
    public function dokter() { return $this->belongsTo(Dokter::class); }
    public function user()   { return $this->belongsTo(User::class); }

    protected static function booted()
    {
        static::creating(function ($m) {
            $m->no_mcu = 'MCU-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        });
    }
}
