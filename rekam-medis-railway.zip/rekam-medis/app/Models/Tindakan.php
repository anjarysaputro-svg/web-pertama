<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Tindakan extends Model
{
    use HasFactory;
    protected $fillable = ['kode','pasien_id','dokter_id','rekam_medis_id','jenis','tarif','tgl','catatan','status','user_id'];
    protected $casts    = ['tgl' => 'date', 'tarif' => 'integer'];

    public function pasien()    { return $this->belongsTo(Pasien::class); }
    public function dokter()    { return $this->belongsTo(Dokter::class); }
    public function rekamMedis(){ return $this->belongsTo(RekamMedis::class); }

    protected static function booted()
    {
        static::creating(function ($m) {
            $m->kode = 'TDK-' . date('Ymd') . '-' . str_pad(rand(1,9999), 4, '0', STR_PAD_LEFT);
        });
    }
}
