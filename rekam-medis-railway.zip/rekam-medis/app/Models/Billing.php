<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Billing extends Model
{
    use HasFactory;
    protected $fillable = ['no_tagihan','pasien_id','layanan','total','bayar','metode','catatan','status','tgl','user_id'];
    protected $casts    = ['tgl' => 'date', 'total' => 'integer', 'bayar' => 'integer'];

    public function pasien() { return $this->belongsTo(Pasien::class); }

    public function getSisaAttribute(): int  { return $this->total - $this->bayar; }
    public function getStatusPembayaranAttribute(): string
    {
        if ($this->sisa <= 0)      return 'Lunas';
        if ($this->bayar > 0)      return 'Cicilan';
        return 'Belum Bayar';
    }

    protected static function booted()
    {
        static::creating(function ($m) {
            $m->no_tagihan = 'BLL-' . date('Ymd') . '-' . str_pad(rand(1,9999), 4, '0', STR_PAD_LEFT);
        });
    }
}
