<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Dokter extends Model
{
    use HasFactory;
    protected $fillable = ['user_id','nama','spesialis','sip','no_hp','jadwal','foto','status'];

    public function user()        { return $this->belongsTo(User::class); }
    public function poliklinik()  { return $this->hasMany(Poliklinik::class); }
    public function rekamMedis()  { return $this->hasMany(RekamMedis::class); }
    public function hasilMcus()   { return $this->hasMany(HasilMcu::class); }
    public function tindakans()   { return $this->hasMany(Tindakan::class); }
}
