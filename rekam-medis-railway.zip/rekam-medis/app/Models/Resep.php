<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Resep extends Model
{
    use HasFactory;
    protected $fillable = ['no_resep','rekam_medis_id','pasien_id','obat_id','jumlah','dosis','aturan','catatan','status','user_id'];

    public function pasien()    { return $this->belongsTo(Pasien::class); }
    public function obat()      { return $this->belongsTo(Obat::class); }
    public function rekamMedis(){ return $this->belongsTo(RekamMedis::class); }

    protected static function booted()
    {
        static::creating(function ($m) {
            $m->no_resep = 'RS-' . date('Ymd') . '-' . str_pad(rand(1,9999), 4, '0', STR_PAD_LEFT);
        });
    }
}
