<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pasien extends Model
{
    use HasFactory;

    protected $fillable = [
        'no_rm', 'nama', 'tgl_lahir', 'jenis_kelamin', 'gol_darah',
        'no_hp', 'email', 'alamat', 'pekerjaan',
        'alergi', 'riwayat_penyakit', 'foto',
    ];

    protected $casts = ['tgl_lahir' => 'date'];

    public function rekamMedis()  { return $this->hasMany(RekamMedis::class); }
    public function hasilMcus()   { return $this->hasMany(HasilMcu::class); }
    public function reseps()      { return $this->hasMany(Resep::class); }
    public function billings()    { return $this->hasMany(Billing::class); }
    public function tindakans()   { return $this->hasMany(Tindakan::class); }

    public function getUmurAttribute(): int
    {
        return $this->tgl_lahir ? $this->tgl_lahir->age : 0;
    }

    protected static function booted()
    {
        static::creating(function ($p) {
            $p->no_rm = 'RM-' . str_pad(static::max('id') + 1, 5, '0', STR_PAD_LEFT);
        });
    }
}
