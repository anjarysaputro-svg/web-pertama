<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Poliklinik extends Model
{
    use HasFactory;
    protected $fillable = ['kode','nama','gedung','dokter_id','status'];

    public function dokter()     { return $this->belongsTo(Dokter::class); }
    public function rekamMedis() { return $this->hasMany(RekamMedis::class); }

    protected static function booted()
    {
        static::creating(function ($m) {
            $m->kode = 'PLI-' . str_pad(static::max('id') + 1, 3, '0', STR_PAD_LEFT);
        });
    }
}
