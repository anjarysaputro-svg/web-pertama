<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Obat extends Model
{
    use HasFactory;
    protected $fillable = ['kode','nama','satuan','kategori','stok','harga','expired','keterangan'];
    protected $casts    = ['expired' => 'date', 'harga' => 'integer', 'stok' => 'integer'];

    public function reseps() { return $this->hasMany(Resep::class); }

    public function getStatusStokAttribute(): string
    {
        if ($this->stok <= 0)  return 'habis';
        if ($this->stok <= 10) return 'kritis';
        if ($this->stok <= 30) return 'rendah';
        return 'aman';
    }

    protected static function booted()
    {
        static::creating(function ($m) {
            $m->kode = 'OBT-' . str_pad(static::max('id') + 1, 3, '0', STR_PAD_LEFT);
        });
    }
}
