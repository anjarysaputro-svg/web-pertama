<?php
namespace App\Notifications;
use App\Models\HasilMcu;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class HasilMcuNotification extends Notification
{
    use Queueable;

    public function __construct(public HasilMcu $mcu) {}

    public function via(object $notifiable): array { return ['mail']; }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Hasil MCU Anda – Apotek Sejahtera')
            ->greeting('Halo, ' . $notifiable->nama . '!')
            ->line('Hasil Medical Check-Up (MCU) Anda pada **' . $this->mcu->tgl->format('d F Y') . '** sudah tersedia.')
            ->line('**Jenis MCU:** ' . $this->mcu->jenis)
            ->line('**Kategori Kesehatan:** ' . $this->mcu->kategori)
            ->line('**Tingkat Risiko:** ' . $this->mcu->risiko)
            ->line('---')
            ->line('**Kesimpulan:** ' . $this->mcu->kesimpulan)
            ->action('Lihat Hasil MCU Lengkap', url('/mcu/' . $this->mcu->id))
            ->line('Jika ada pertanyaan, silakan hubungi kami.')
            ->salutation('Salam sehat,  
**Apotek Sejahtera**');
    }
}
