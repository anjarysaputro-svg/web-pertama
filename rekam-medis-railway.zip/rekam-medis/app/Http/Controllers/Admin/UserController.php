<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index() {
        $users = User::with('roles')->paginate(15);
        return view('admin.users.index', compact('users'));
    }
    public function create() {
        $roles = Role::all();
        return view('admin.users.form', compact('roles'));
    }
    public function store(Request $request) {
        $request->validate([
            'name'     => 'required|string|max:100',
            'email'    => 'required|email|unique:users',
            'password' => 'required|min:8|confirmed',
            'role'     => 'required|exists:roles,name',
        ]);
        $user = User::create([
            'name'     => $request->name,
            'email'    => $request->email,
            'password' => Hash::make($request->password),
        ]);
        $user->assignRole($request->role);
        return redirect()->route('users.index')->with('success','User berhasil ditambahkan!');
    }
    public function edit(User $user) {
        $roles = Role::all();
        return view('admin.users.form', compact('user','roles'));
    }
    public function update(Request $request, User $user) {
        $request->validate(['name'=>'required','email'=>'required|email|unique:users,email,'.$user->id,'role'=>'required']);
        $user->update(['name'=>$request->name,'email'=>$request->email]);
        if ($request->password) $user->update(['password'=>Hash::make($request->password)]);
        $user->syncRoles([$request->role]);
        return redirect()->route('users.index')->with('success','User diupdate!');
    }
    public function destroy(User $user) {
        if ($user->id === auth()->id()) return back()->with('error','Tidak bisa hapus akun sendiri!');
        $user->delete();
        return redirect()->route('users.index')->with('success','User dihapus!');
    }
}
