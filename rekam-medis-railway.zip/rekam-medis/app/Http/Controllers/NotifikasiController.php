<?php
namespace App\Http\Controllers;
use App\Models\{Pasien, HasilMcu};
use App\Services\WhatsAppService;
use App\Notifications\HasilMcuNotification;
use Illuminate\Http\Request;

class NotifikasiController extends Controller
{
    public function index() {
        $pasiens = Pasien::orderBy('nama')->get();
        $mcus    = HasilMcu::with('pasien')->latest()->take(20)->get();
        return view('notifikasi.index', compact('pasiens','mcus'));
    }

    public function kirimEmail(Request $request) {
        $request->validate(['pasien_id'=>'required|exists:pasiens,id','mcu_id'=>'required|exists:hasil_mcus,id']);
        $pasien = Pasien::find($request->pasien_id);
        $mcu    = HasilMcu::find($request->mcu_id);
        if ($pasien->email) {
            $pasien->notify(new HasilMcuNotification($mcu));
            return back()->with('success',"Email berhasil dikirim ke {$pasien->email}");
        }
        return back()->with('error','Pasien tidak memiliki email!');
    }

    public function kirimWhatsapp(Request $request) {
        $request->validate(['pasien_id'=>'required|exists:pasiens,id','pesan'=>'required|string']);
        $pasien = Pasien::find($request->pasien_id);
        if (!$pasien->no_hp) return back()->with('error','Pasien tidak memiliki nomor HP!');
        $wa = new WhatsAppService();
        $result = $wa->send($pasien->no_hp, $request->pesan);
        if ($result['status'] ?? false) {
            return back()->with('success',"WhatsApp berhasil dikirim ke {$pasien->no_hp}");
        }
        return back()->with('error','Gagal kirim WhatsApp. Cek token Fonnte.');
    }
}
