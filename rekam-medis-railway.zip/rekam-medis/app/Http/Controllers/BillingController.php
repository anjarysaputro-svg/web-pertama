<?php
namespace App\Http\Controllers;
use App\Models\{Billing, Pasien};
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class BillingController extends Controller
{
    public function index(Request $request) {
        $billings = Billing::with('pasien')
            ->when($request->search, fn($q,$s) => $q->whereHas('pasien', fn($p) => $p->where('nama','like',"%$s%"))->orWhere('no_tagihan','like',"%$s%"))
            ->when($request->status, fn($q,$s) => $q->where('status',$s))
            ->latest()->paginate(15);
        return view('billing.index', compact('billings'));
    }
    public function create() {
        $pasiens = Pasien::orderBy('nama')->get();
        return view('billing.form', compact('pasiens'));
    }
    public function store(Request $request) {
        $request->validate([
            'pasien_id' => 'required|exists:pasiens,id',
            'layanan'   => 'required|string',
            'total'     => 'required|integer|min:0',
            'bayar'     => 'required|integer|min:0',
            'metode'    => 'required|string',
            'tgl'       => 'required|date',
        ]);
        $data = $request->all();
        $data['status'] = ($data['bayar'] >= $data['total']) ? 'Lunas' : (($data['bayar'] > 0) ? 'Cicilan' : 'Belum Bayar');
        $data['user_id'] = auth()->id();
        Billing::create($data);
        return redirect()->route('billing.index')->with('success','Tagihan berhasil dibuat!');
    }
    public function show(Billing $billing) {
        $billing->load('pasien');
        return view('billing.show', compact('billing'));
    }
    public function edit(Billing $billing) {
        $pasiens = Pasien::orderBy('nama')->get();
        return view('billing.form', compact('billing','pasiens'));
    }
    public function update(Request $request, Billing $billing) {
        $data = $request->except('_token','_method');
        $data['status'] = ($data['bayar'] >= $data['total']) ? 'Lunas' : (($data['bayar'] > 0) ? 'Cicilan' : 'Belum Bayar');
        $billing->update($data);
        return redirect()->route('billing.index')->with('success','Tagihan diupdate!');
    }
    public function destroy(Billing $billing) {
        $billing->delete();
        return redirect()->route('billing.index')->with('success','Tagihan dihapus!');
    }
    public function invoice(Billing $billing) {
        $billing->load('pasien');
        $pdf = Pdf::loadView('pdf.invoice', compact('billing'))->setPaper('A4','portrait');
        return $pdf->stream('Invoice-'.$billing->no_tagihan.'.pdf');
    }
}
