<?php
namespace App\Http\Controllers;
use App\Models\RekamMedis;
use App\Models\Pasien;
use App\Models\Dokter;
use App\Models\Poliklinik;
use Illuminate\Http\Request;

class RekamMedisController extends Controller
{
    public function index(Request $request) {
        $rekams = RekamMedis::with(['pasien','dokter','poliklinik'])
            ->when($request->search, fn($q,$s)=>$q->whereHas('pasien',fn($p)=>$p->where('nama','like',"%$s%"))->orWhere('diagnosis','like',"%$s%"))
            ->when($request->status, fn($q,$s)=>$q->where('status',$s))
            ->latest('tgl_kunjungan')->paginate(15);
        return view('rekam-medis.index', compact('rekams'));
    }
    public function create() {
        $pasiens     = Pasien::orderBy('nama')->get();
        $dokters     = Dokter::orderBy('nama')->get();
        $polikliniks = Poliklinik::orderBy('nama')->get();
        return view('rekam-medis.form', compact('pasiens','dokters','polikliniks'));
    }
    public function store(Request $request) {
        $data = $request->validate([
            'pasien_id'     => 'required|exists:pasiens,id',
            'dokter_id'     => 'required|exists:dokters,id',
            'poliklinik_id' => 'nullable|exists:polikliniks,id',
            'tgl_kunjungan' => 'required|date',
            'keluhan'       => 'required|string',
            'diagnosis'     => 'required|string',
            'terapi'        => 'nullable|string',
            'tekanan_darah' => 'nullable|string',
            'nadi'          => 'nullable|string',
            'suhu'          => 'nullable|string',
            'berat_badan'   => 'nullable|numeric',
            'tinggi_badan'  => 'nullable|numeric',
            'catatan'       => 'nullable|string',
            'status'        => 'required|in:Dalam Perawatan,Sembuh,Dirujuk',
        ]);
        $data['user_id'] = auth()->id();
        RekamMedis::create($data);
        return redirect()->route('rekam-medis.index')->with('success','Rekam medis berhasil disimpan!');
    }
    public function show(RekamMedis $rekamMedis) {
        $rekamMedis->load(['pasien','dokter','poliklinik','reseps.obat','tindakans']);
        return view('rekam-medis.show', compact('rekamMedis'));
    }
    public function edit(RekamMedis $rekamMedis) {
        $pasiens = Pasien::orderBy('nama')->get();
        $dokters = Dokter::orderBy('nama')->get();
        $polikliniks = Poliklinik::orderBy('nama')->get();
        return view('rekam-medis.form', compact('rekamMedis','pasiens','dokters','polikliniks'));
    }
    public function update(Request $request, RekamMedis $rekamMedis) {
        $rekamMedis->update($request->except('_token','_method'));
        return redirect()->route('rekam-medis.index')->with('success','Rekam medis diupdate!');
    }
    public function destroy(RekamMedis $rekamMedis) {
        $rekamMedis->delete();
        return redirect()->route('rekam-medis.index')->with('success','Rekam medis dihapus!');
    }
}
