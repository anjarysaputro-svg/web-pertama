<?php
namespace App\Http\Controllers;

use App\Models\Dokter;
use App\Models\User;
use Illuminate\Http\Request;

class DokterController extends Controller
{
    public function index()
    {
        $dokters = Dokter::with('user')->paginate(15);
        return view('dokter.index', compact('dokters'));
    }
    public function create()
    {
        $users = User::role('dokter')->get();
        return view('dokter.form', compact('users'));
    }
    public function store(Request $request)
    {
        $data = $request->validate([
            'nama'      => 'required|string|max:100',
            'spesialis' => 'required|string',
            'sip'       => 'nullable|string|max:50',
            'no_hp'     => 'nullable|string|max:20',
            'jadwal'    => 'nullable|string',
            'user_id'   => 'nullable|exists:users,id',
        ]);
        Dokter::create($data);
        return redirect()->route('dokter.index')->with('success', 'Dokter berhasil ditambahkan!');
    }
    public function edit(Dokter $dokter)
    {
        $users = User::role('dokter')->get();
        return view('dokter.form', compact('dokter','users'));
    }
    public function update(Request $request, Dokter $dokter)
    {
        $data = $request->validate([
            'nama'      => 'required|string|max:100',
            'spesialis' => 'required|string',
            'sip'       => 'nullable|string|max:50',
            'no_hp'     => 'nullable|string|max:20',
            'jadwal'    => 'nullable|string',
        ]);
        $dokter->update($data);
        return redirect()->route('dokter.index')->with('success', 'Data dokter berhasil diupdate!');
    }
    public function destroy(Dokter $dokter)
    {
        $dokter->delete();
        return redirect()->route('dokter.index')->with('success', 'Dokter berhasil dihapus!');
    }
}
