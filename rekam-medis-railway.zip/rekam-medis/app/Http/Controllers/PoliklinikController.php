<?php
namespace App\Http\Controllers;
use App\Models\Poliklinik;
use App\Models\Dokter;
use Illuminate\Http\Request;

class PoliklinikController extends Controller
{
    public function index() {
        $polikliniks = Poliklinik::with('dokter')->paginate(15);
        return view('poliklinik.index', compact('polikliniks'));
    }
    public function create() {
        $dokters = Dokter::orderBy('nama')->get();
        return view('poliklinik.form', compact('dokters'));
    }
    public function store(Request $request) {
        $request->validate(['nama' => 'required|string', 'gedung' => 'nullable|string', 'dokter_id' => 'nullable|exists:dokters,id']);
        Poliklinik::create($request->only('nama','gedung','dokter_id') + ['status' => 'Aktif']);
        return redirect()->route('poliklinik.index')->with('success', 'Poliklinik ditambahkan!');
    }
    public function edit(Poliklinik $poliklinik) {
        $dokters = Dokter::orderBy('nama')->get();
        return view('poliklinik.form', compact('poliklinik','dokters'));
    }
    public function update(Request $request, Poliklinik $poliklinik) {
        $poliklinik->update($request->only('nama','gedung','dokter_id','status'));
        return redirect()->route('poliklinik.index')->with('success', 'Poliklinik diupdate!');
    }
    public function destroy(Poliklinik $poliklinik) {
        $poliklinik->delete();
        return redirect()->route('poliklinik.index')->with('success', 'Poliklinik dihapus!');
    }
}
