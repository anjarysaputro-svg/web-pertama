<?php
namespace App\Http\Controllers;
use App\Models\Obat;
use Illuminate\Http\Request;

class ObatController extends Controller
{
    public function index(Request $request) {
        $obats = Obat::when($request->search, fn($q,$s)=>$q->where('nama','like',"%$s%")->orWhere('kode','like',"%$s%"))
            ->when($request->kategori, fn($q,$k)=>$q->where('kategori',$k))
            ->orderBy('nama')->paginate(20);
        $kategoris = Obat::distinct()->pluck('kategori');
        return view('obat.index', compact('obats','kategoris'));
    }
    public function create() { return view('obat.form'); }
    public function store(Request $request) {
        $request->validate(['nama'=>'required','satuan'=>'required','kategori'=>'required','stok'=>'required|integer|min:0','harga'=>'required|integer|min:0']);
        Obat::create($request->all());
        return redirect()->route('obat.index')->with('success','Obat berhasil ditambahkan!');
    }
    public function edit(Obat $obat) { return view('obat.form', compact('obat')); }
    public function update(Request $request, Obat $obat) {
        $obat->update($request->all());
        return redirect()->route('obat.index')->with('success','Data obat diupdate!');
    }
    public function destroy(Obat $obat) {
        $obat->delete();
        return redirect()->route('obat.index')->with('success','Obat dihapus!');
    }
}
