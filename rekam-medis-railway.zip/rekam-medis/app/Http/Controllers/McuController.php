<?php
namespace App\Http\Controllers;

use App\Models\HasilMcu;
use App\Models\Pasien;
use App\Models\Dokter;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class McuController extends Controller
{
    public function index(Request $request)
    {
        $mcus = HasilMcu::with(['pasien', 'dokter'])
            ->when($request->search, fn($q, $s) =>
                $q->whereHas('pasien', fn($p) => $p->where('nama', 'like', "%$s%"))
                  ->orWhere('no_mcu', 'like', "%$s%")
            )
            ->latest()->paginate(15);

        $stats = [
            'total'  => HasilMcu::count(),
            'normal' => HasilMcu::where('risiko', 'Rendah')->count(),
            'sedang' => HasilMcu::where('risiko', 'Sedang')->count(),
            'tinggi' => HasilMcu::where('risiko', 'Tinggi')->count(),
        ];

        return view('mcu.index', compact('mcus', 'stats'));
    }

    public function create()
    {
        $pasiens = Pasien::orderBy('nama')->get();
        $dokters = Dokter::orderBy('nama')->get();
        return view('mcu.create', compact('pasiens', 'dokters'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'pasien_id'  => 'required|exists:pasiens,id',
            'dokter_id'  => 'required|exists:dokters,id',
            'tgl'        => 'required|date',
            'jenis'      => 'required|string',
            'kesimpulan' => 'required|string',
            'risiko'     => 'required|in:Rendah,Sedang,Tinggi',
        ]);

        HasilMcu::create([
            'pasien_id'   => $request->pasien_id,
            'dokter_id'   => $request->dokter_id,
            'tgl'         => $request->tgl,
            'jenis'       => $request->jenis,
            'fisik'       => $request->fisik ?? [],
            'darah'       => $request->darah ?? [],
            'kimia'       => $request->kimia ?? [],
            'urin'        => $request->urin ?? [],
            'jantung'     => $request->jantung ?? [],
            'mata'        => $request->mata ?? [],
            'kategori'    => $request->kategori,
            'risiko'      => $request->risiko,
            'kesimpulan'  => $request->kesimpulan,
            'rekomendasi' => $request->rekomendasi,
            'followup'    => $request->followup,
            'status'      => $request->status ?? 'Selesai',
            'user_id'     => auth()->id(),
        ]);

        return redirect()->route('mcu.index')->with('success', 'Hasil MCU berhasil disimpan!');
    }

    public function show(HasilMcu $mcu)
    {
        $mcu->load(['pasien', 'dokter']);
        return view('mcu.show', compact('mcu'));
    }

    public function destroy(HasilMcu $mcu)
    {
        $mcu->delete();
        return redirect()->route('mcu.index')->with('success', 'Data MCU berhasil dihapus!');
    }

    public function pdf(HasilMcu $mcu)
    {
        $mcu->load(['pasien', 'dokter']);
        $pdf = Pdf::loadView('pdf.mcu', compact('mcu'))
            ->setPaper('A4', 'portrait')
            ->setOptions(['defaultFont' => 'dejavu sans', 'isHtml5ParserEnabled' => true]);

        return $pdf->stream('MCU-' . $mcu->pasien->nama . '-' . $mcu->tgl . '.pdf');
    }
}
