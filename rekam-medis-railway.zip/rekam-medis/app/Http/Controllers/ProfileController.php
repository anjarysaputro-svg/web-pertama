<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    public function edit() { return view('profile.edit', ['user' => auth()->user()]); }

    public function update(Request $request) {
        $request->validate(['name'=>'required|string|max:100','email'=>'required|email']);
        $user = auth()->user();
        $user->update(['name'=>$request->name,'email'=>$request->email]);
        if ($request->password) {
            $request->validate(['password'=>'min:8|confirmed']);
            $user->update(['password'=>Hash::make($request->password)]);
        }
        return back()->with('success','Profil berhasil diupdate!');
    }
}
