<?php
namespace App\Http\Controllers;
use App\Models\{Tindakan, Pasien, Dokter, RekamMedis};
use Illuminate\Http\Request;

class TindakanController extends Controller
{
    public function index() {
        $tindakans = Tindakan::with(['pasien','dokter'])->latest()->paginate(15);
        return view('tindakan.index', compact('tindakans'));
    }
    public function create() {
        $pasiens = Pasien::orderBy('nama')->get();
        $dokters = Dokter::orderBy('nama')->get();
        return view('tindakan.form', compact('pasiens','dokters'));
    }
    public function store(Request $request) {
        $request->validate([
            'pasien_id' => 'required|exists:pasiens,id',
            'dokter_id' => 'required|exists:dokters,id',
            'jenis'     => 'required|string',
            'tarif'     => 'required|integer|min:0',
            'tgl'       => 'required|date',
            'status'    => 'required|in:Dalam Proses,Selesai',
        ]);
        Tindakan::create($request->all() + ['user_id' => auth()->id()]);
        return redirect()->route('tindakan.index')->with('success','Tindakan berhasil disimpan!');
    }
    public function edit(Tindakan $tindakan) {
        $pasiens = Pasien::orderBy('nama')->get();
        $dokters = Dokter::orderBy('nama')->get();
        return view('tindakan.form', compact('tindakan','pasiens','dokters'));
    }
    public function update(Request $request, Tindakan $tindakan) {
        $tindakan->update($request->except('_token','_method'));
        return redirect()->route('tindakan.index')->with('success','Tindakan diupdate!');
    }
    public function destroy(Tindakan $tindakan) {
        $tindakan->delete();
        return redirect()->route('tindakan.index')->with('success','Tindakan dihapus!');
    }
}
