<?php
namespace App\Http\Controllers;
use App\Models\{Resep, Pasien, Obat, RekamMedis};
use Illuminate\Http\Request;

class ResepController extends Controller
{
    public function index() {
        $reseps = Resep::with(['pasien','obat'])->latest()->paginate(15);
        return view('resep.index', compact('reseps'));
    }
    public function create() {
        $pasiens = Pasien::orderBy('nama')->get();
        $obats   = Obat::orderBy('nama')->get();
        return view('resep.form', compact('pasiens','obats'));
    }
    public function store(Request $request) {
        $request->validate(['pasien_id'=>'required','obat_id'=>'required','jumlah'=>'required|integer|min:1','dosis'=>'required','aturan'=>'required']);
        Resep::create($request->all() + ['user_id'=>auth()->id(),'status'=>'Menunggu']);
        // Kurangi stok obat
        $obat = Obat::find($request->obat_id);
        if ($obat) $obat->decrement('stok', $request->jumlah);
        return redirect()->route('resep.index')->with('success','Resep berhasil dibuat!');
    }
    public function destroy(Resep $resep) {
        $resep->delete();
        return redirect()->route('resep.index')->with('success','Resep dihapus!');
    }
}
