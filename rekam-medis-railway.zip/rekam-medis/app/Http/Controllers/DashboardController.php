<?php
namespace App\Http\Controllers;

use App\Models\Pasien;
use App\Models\RekamMedis;
use App\Models\Obat;
use App\Models\Billing;
use Illuminate\Http\Request;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'pasien'           => Pasien::count(),
            'pasien_baru'      => Pasien::whereMonth('created_at', now()->month)->count(),
            'rekam_medis'      => RekamMedis::count(),
            'rekam_aktif'      => RekamMedis::where('status', 'Dalam Perawatan')->count(),
            'sembuh'           => RekamMedis::where('status', 'Sembuh')->count(),
            'dirujuk'          => RekamMedis::where('status', 'Dirujuk')->count(),
            'obat'             => Obat::count(),
            'obat_kritis'      => Obat::where('stok', '<=', 10)->count(),
            'pendapatan_bulan' => Billing::whereMonth('tgl', now()->month)->sum('bayar'),
        ];

        // Chart data — 7 hari terakhir
        $chartData   = [];
        $chartLabels = [];
        for ($i = 6; $i >= 0; $i--) {
            $date          = Carbon::now()->subDays($i);
            $chartLabels[] = $date->isoFormat('ddd');
            $chartData[]   = RekamMedis::whereDate('tgl_kunjungan', $date)->count();
        }

        $kunjungan_terbaru = RekamMedis::with(['pasien', 'dokter'])->latest()->take(6)->get();
        $obat_kritis       = Obat::where('stok', '<=', 20)->orderBy('stok')->take(5)->get();

        return view('dashboard.index', compact('stats', 'chartData', 'chartLabels', 'kunjungan_terbaru', 'obat_kritis'));
    }
}
