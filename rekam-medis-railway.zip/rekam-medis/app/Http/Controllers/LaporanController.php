<?php
namespace App\Http\Controllers;
use App\Models\{Pasien, RekamMedis, Billing, Obat, HasilMcu};
use App\Exports\LaporanExport;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

class LaporanController extends Controller
{
    public function index(Request $request)
    {
        $bulan = $request->bulan ?? now()->month;
        $tahun = $request->tahun ?? now()->year;

        $data = [
            'pasien_baru'       => Pasien::whereMonth('created_at',$bulan)->whereYear('created_at',$tahun)->count(),
            'total_kunjungan'   => RekamMedis::whereMonth('tgl_kunjungan',$bulan)->whereYear('tgl_kunjungan',$tahun)->count(),
            'total_mcu'         => HasilMcu::whereMonth('tgl',$bulan)->whereYear('tgl',$tahun)->count(),
            'pendapatan'        => Billing::whereMonth('tgl',$bulan)->whereYear('tgl',$tahun)->sum('bayar'),
            'tagihan_belum'     => Billing::whereMonth('tgl',$bulan)->whereYear('tgl',$tahun)->where('status','Belum Bayar')->sum('total'),
            'obat_kritis'       => Obat::where('stok','<=',10)->count(),
        ];

        // Data bulanan untuk tabel
        $bulanan = collect(range(1,12))->map(fn($b) => [
            'bulan'           => Carbon::create(null,$b)->isoFormat('MMMM'),
            'pasien_baru'     => Pasien::whereMonth('created_at',$b)->whereYear('created_at',$tahun)->count(),
            'kunjungan'       => RekamMedis::whereMonth('tgl_kunjungan',$b)->whereYear('tgl_kunjungan',$tahun)->count(),
            'mcu'             => HasilMcu::whereMonth('tgl',$b)->whereYear('tgl',$tahun)->count(),
            'pendapatan'      => Billing::whereMonth('tgl',$b)->whereYear('tgl',$tahun)->sum('bayar'),
        ]);

        return view('laporan.index', compact('data','bulanan','bulan','tahun'));
    }

    public function exportExcel(Request $request)
    {
        $tahun = $request->tahun ?? now()->year;
        return Excel::download(new LaporanExport($tahun), "laporan-{$tahun}.xlsx");
    }

    public function exportPdf(Request $request)
    {
        $bulan = $request->bulan ?? now()->month;
        $tahun = $request->tahun ?? now()->year;
        $pdf   = Pdf::loadView('pdf.laporan', compact('bulan','tahun'))->setPaper('A4','landscape');
        return $pdf->stream("laporan-{$bulan}-{$tahun}.pdf");
    }
}
