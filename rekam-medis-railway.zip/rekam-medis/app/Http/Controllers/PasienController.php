<?php
namespace App\Http\Controllers;

use App\Models\Pasien;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\PasienExport;

class PasienController extends Controller
{
    public function index(Request $request)
    {
        $pasiens = Pasien::when($request->search, fn($q, $s) =>
            $q->where('nama', 'like', "%$s%")
              ->orWhere('no_rm', 'like', "%$s%")
              ->orWhere('no_hp', 'like', "%$s%")
        )->latest()->paginate(15);

        return view('pasien.index', compact('pasiens'));
    }

    public function create()
    {
        return view('pasien.form');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nama'             => 'required|string|max:100',
            'tgl_lahir'        => 'required|date',
            'jenis_kelamin'    => 'required|in:Laki-laki,Perempuan',
            'gol_darah'        => 'nullable|in:A,B,AB,O',
            'no_hp'            => 'nullable|string|max:20',
            'email'            => 'nullable|email|max:100',
            'alamat'           => 'nullable|string',
            'pekerjaan'        => 'nullable|string|max:100',
            'alergi'           => 'nullable|string|max:200',
            'riwayat_penyakit' => 'nullable|string|max:200',
            'foto'             => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('pasien', 'public');
        }

        Pasien::create($data);

        return redirect()->route('pasien.index')->with('success', 'Pasien berhasil ditambahkan!');
    }

    public function show(Pasien $pasien)
    {
        $pasien->load(['rekamMedis.dokter', 'hasilMcus', 'billings', 'reseps.obat']);
        return view('pasien.show', compact('pasien'));
    }

    public function edit(Pasien $pasien)
    {
        return view('pasien.form', compact('pasien'));
    }

    public function update(Request $request, Pasien $pasien)
    {
        $data = $request->validate([
            'nama'             => 'required|string|max:100',
            'tgl_lahir'        => 'required|date',
            'jenis_kelamin'    => 'required|in:Laki-laki,Perempuan',
            'gol_darah'        => 'nullable|in:A,B,AB,O',
            'no_hp'            => 'nullable|string|max:20',
            'email'            => 'nullable|email|max:100',
            'alamat'           => 'nullable|string',
            'pekerjaan'        => 'nullable|string|max:100',
            'alergi'           => 'nullable|string|max:200',
            'riwayat_penyakit' => 'nullable|string|max:200',
            'foto'             => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('pasien', 'public');
        }

        $pasien->update($data);

        return redirect()->route('pasien.index')->with('success', 'Data pasien berhasil diupdate!');
    }

    public function destroy(Pasien $pasien)
    {
        $pasien->delete();
        return redirect()->route('pasien.index')->with('success', 'Pasien berhasil dihapus!');
    }

    public function export()
    {
        return Excel::download(new PasienExport, 'data-pasien-' . date('Ymd') . '.xlsx');
    }
}
