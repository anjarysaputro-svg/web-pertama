<?php
namespace App\Exports;
use App\Models\{RekamMedis, HasilMcu, Billing, Pasien};
use Maatwebsite\Excel\Concerns\{FromCollection, WithHeadings, WithStyles, WithTitle, ShouldAutoSize, WithMapping};
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Carbon\Carbon;

class LaporanExport implements FromCollection, WithHeadings, WithStyles, WithTitle, ShouldAutoSize
{
    public function __construct(private int $tahun) {}

    public function collection()
    {
        return collect(range(1,12))->map(fn($b) => [
            Carbon::create(null, $b)->isoFormat('MMMM'),
            Pasien::whereMonth('created_at',$b)->whereYear('created_at',$this->tahun)->count(),
            RekamMedis::whereMonth('tgl_kunjungan',$b)->whereYear('tgl_kunjungan',$this->tahun)->count(),
            HasilMcu::whereMonth('tgl',$b)->whereYear('tgl',$this->tahun)->count(),
            'Rp ' . number_format(Billing::whereMonth('tgl',$b)->whereYear('tgl',$this->tahun)->sum('bayar'), 0, ',', '.'),
        ]);
    }

    public function headings(): array
    {
        return ['Bulan', 'Pasien Baru', 'Total Kunjungan', 'MCU', 'Pendapatan'];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']], 'fill' => ['fillType' => 'solid', 'startColor' => ['rgb' => '1565C0']]],
        ];
    }

    public function title(): string { return 'Laporan ' . $this->tahun; }
}
