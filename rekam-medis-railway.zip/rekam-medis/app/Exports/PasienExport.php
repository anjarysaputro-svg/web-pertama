<?php
namespace App\Exports;
use App\Models\Pasien;
use Maatwebsite\Excel\Concerns\{FromCollection, WithHeadings, WithStyles, WithTitle, ShouldAutoSize};
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class PasienExport implements FromCollection, WithHeadings, WithStyles, WithTitle, ShouldAutoSize
{
    public function collection()
    {
        return Pasien::all()->map(fn($p, $i) => [
            'No'              => $i + 1,
            'No. RM'          => $p->no_rm,
            'Nama'            => $p->nama,
            'Tgl Lahir'       => $p->tgl_lahir?->format('d/m/Y'),
            'Jenis Kelamin'   => $p->jenis_kelamin,
            'Gol. Darah'      => $p->gol_darah,
            'No. HP'          => $p->no_hp,
            'Email'           => $p->email,
            'Alamat'          => $p->alamat,
            'Alergi'          => $p->alergi,
            'Riwayat Penyakit'=> $p->riwayat_penyakit,
            'Tgl Daftar'      => $p->created_at->format('d/m/Y'),
        ]);
    }

    public function headings(): array
    {
        return ['No','No. RM','Nama','Tgl Lahir','Jenis Kelamin','Gol. Darah','No. HP','Email','Alamat','Alergi','Riwayat Penyakit','Tgl Daftar'];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true], 'fill' => ['fillType' => 'solid', 'startColor' => ['rgb' => '1565C0']], 'font' => ['color' => ['rgb' => 'FFFFFF'], 'bold' => true]],
        ];
    }

    public function title(): string { return 'Data Pasien'; }
}
