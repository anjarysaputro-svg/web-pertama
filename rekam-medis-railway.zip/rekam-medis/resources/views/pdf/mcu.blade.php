<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan MCU - {{ $mcu->pasien->nama }}</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'DejaVu Sans', Arial, sans-serif; font-size: 10px; color: #1a2332; background: white; }
.page { padding: 15mm 12mm; }

/* Header */
.header { display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 10px; border-bottom: 3px solid #1565C0; margin-bottom: 12px; }
.header-left h1 { font-size: 18px; font-weight: 800; color: #1565C0; }
.header-left p { font-size: 9px; color: #607080; margin-top: 2px; }
.header-right { text-align: right; }
.header-right .label { font-size: 16px; font-weight: 800; color: #1565C0; }
.header-right p { font-size: 9px; color: #607080; }

/* Patient Info Banner */
.patient-banner { background: #1565C0; color: white; padding: 10px 14px; border-radius: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: flex-start; }
.patient-banner h2 { font-size: 14px; font-weight: 800; margin-bottom: 3px; }
.patient-banner p { font-size: 9px; opacity: 0.8; }
.result-box { background: white; color: #1a2332; border-radius: 6px; padding: 6px 12px; text-align: center; }
.result-box .cat { font-size: 8px; font-weight: 700; text-transform: uppercase; color: #607080; }
.result-box .val { font-size: 11px; font-weight: 800; margin: 2px 0; }
.result-box .risk { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 9px; font-weight: 700; color: white; }
.risk-rendah { background: #2E7D32; }
.risk-sedang { background: #F57F17; }
.risk-tinggi { background: #C62828; }

/* Section Title */
.section-title { font-size: 9px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; color: #607080; padding: 6px 0; border-bottom: 1px solid #DDE3EA; margin-bottom: 8px; margin-top: 10px; }

/* Results Grid */
.results-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; }
.result-item { background: #F7FAFC; border-radius: 6px; padding: 6px 8px; border-left: 3px solid #DDE3EA; }
.result-item.normal { border-left-color: #2E7D32; }
.result-item.tinggi  { border-left-color: #C62828; }
.result-item.rendah  { border-left-color: #0277BD; }
.result-item.waspada { border-left-color: #F57F17; }
.ri-label { font-size: 8px; font-weight: 700; text-transform: uppercase; color: #607080; }
.ri-value { font-size: 12px; font-weight: 800; color: #1a2332; margin: 1px 0; }
.ri-unit  { font-size: 8px; color: #607080; }
.ri-ref   { font-size: 7.5px; color: #607080; display: flex; justify-content: space-between; }
.ri-flag  { font-weight: 700; }
.flag-normal { color: #2E7D32; }
.flag-tinggi { color: #C62828; }
.flag-rendah { color: #0277BD; }

/* Conclusion */
.conclusion { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 8px; }
.conc-box { background: #F7FAFC; border-radius: 8px; padding: 10px 12px; }
.conc-box label { display: block; font-size: 8px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.07em; color: #607080; margin-bottom: 5px; }
.conc-box p { font-size: 9px; line-height: 1.6; }

/* Footer */
.footer { margin-top: 16px; padding-top: 8px; border-top: 1px solid #DDE3EA; display: flex; justify-content: space-between; align-items: center; }
.footer p { font-size: 8px; color: #607080; }
.sign-area { text-align: center; }
.sign-area .line { width: 140px; border-bottom: 1px solid #1a2332; margin: 30px auto 5px; }
.sign-area p { font-size: 9px; font-weight: 700; }
</style>
</head>
<body>
<div class="page">

    {{-- Header --}}
    <div class="header">
        <div class="header-left">
            <h1>✚ Apotek Sejahtera</h1>
            <p>Sistem Informasi Rekam Medis Digital</p>
            <p>Jl. Contoh No. 1, Jakarta | Telp: (021) 1234-5678</p>
        </div>
        <div class="header-right">
            <div class="label">LAPORAN MCU</div>
            <p>No: {{ $mcu->no_mcu }}</p>
            <p>Dicetak: {{ now()->format('d/m/Y H:i') }}</p>
        </div>
    </div>

    {{-- Patient Banner --}}
    <div class="patient-banner">
        <div>
            <h2>{{ $mcu->pasien->nama ?? '-' }}</h2>
            <p>No. RM: {{ $mcu->pasien->no_rm ?? '-' }} &nbsp;|&nbsp;
               Tgl Lahir: {{ $mcu->pasien->tgl_lahir ? \Carbon\Carbon::parse($mcu->pasien->tgl_lahir)->format('d/m/Y') : '-' }} &nbsp;|&nbsp;
               Jenis Kelamin: {{ $mcu->pasien->jenis_kelamin ?? '-' }}</p>
            <p>Jenis MCU: {{ $mcu->jenis }} &nbsp;|&nbsp; Tanggal: {{ \Carbon\Carbon::parse($mcu->tgl)->format('d F Y') }} &nbsp;|&nbsp; Dokter: {{ $mcu->dokter->nama ?? '-' }}</p>
        </div>
        <div class="result-box">
            <div class="cat">Hasil</div>
            <div class="val">{{ $mcu->kategori }}</div>
            <span class="risk risk-{{ strtolower($mcu->risiko) }}">Risiko {{ $mcu->risiko }}</span>
        </div>
    </div>

    @php
    function riItem($label, $val, $unit, $min, $max) {
        if (!$val && $val !== 0) return '';
        $v = floatval($val);
        $cls = 'normal'; $flag = '✓ Normal';
        if ($min !== null && $max !== null) {
            if ($v < $min) { $cls = 'rendah'; $flag = '↓ Rendah'; }
            elseif ($v > $max) { $cls = 'tinggi'; $flag = '↑ Tinggi'; }
        }
        $ref = ($min !== null) ? "$min–$max" : '—';
        $flagCls = "flag-$cls";
        return "<div class='result-item $cls'>
            <div class='ri-label'>$label</div>
            <div class='ri-value'>$val <span class='ri-unit'>$unit</span></div>
            <div class='ri-ref'><span>$ref</span><span class='ri-flag $flagCls'>$flag</span></div>
        </div>";
    }
    function riText($label, $val) {
        if (!$val) return '';
        $normals = ['Normal','Negatif','Tidak Ada','Jernih','Kuning Jernih','Normal Sinus Rhythm'];
        $isNorm = false;
        foreach($normals as $n) { if (str_contains($val, $n)) { $isNorm = true; break; } }
        $cls = $isNorm ? 'normal' : 'waspada';
        return "<div class='result-item $cls'>
            <div class='ri-label'>$label</div>
            <div class='ri-value' style='font-size:9px;font-weight:600'>$val</div>
        </div>";
    }
    $fisik   = $mcu->fisik   ?? [];
    $darah   = $mcu->darah   ?? [];
    $kimia   = $mcu->kimia   ?? [];
    $urin    = $mcu->urin    ?? [];
    $jantung = $mcu->jantung ?? [];
    $mata    = $mcu->mata    ?? [];
    @endphp

    {{-- 1. Fisik & Vital --}}
    <div class="section-title">🩺 Tanda Vital & Antropometri</div>
    <div class="results-grid">
        {!! riItem('Berat Badan', $fisik['bb']??null, 'kg', 50, 90) !!}
        {!! riItem('Tinggi Badan', $fisik['tb']??null, 'cm', 150, 200) !!}
        {!! riItem('IMT/BMI', $fisik['bmi']??null, 'kg/m²', 18.5, 24.9) !!}
        {!! riItem('Sistolik', $fisik['sistol']??null, 'mmHg', 90, 120) !!}
        {!! riItem('Diastolik', $fisik['diastol']??null, 'mmHg', 60, 80) !!}
        {!! riItem('Denyut Nadi', $fisik['nadi']??null, 'x/mnt', 60, 100) !!}
        {!! riItem('Suhu Tubuh', $fisik['suhu']??null, '°C', 36.1, 37.2) !!}
        {!! riItem('Saturasi O₂', $fisik['spo2']??null, '%', 95, 100) !!}
    </div>

    {{-- 2. Darah Lengkap --}}
    <div class="section-title">🔴 Darah Lengkap (Hematologi)</div>
    <div class="results-grid">
        {!! riItem('Hemoglobin', $darah['hb']??null, 'g/dL', 12, 17.5) !!}
        {!! riItem('Hematokrit', $darah['ht']??null, '%', 36, 53) !!}
        {!! riItem('Eritrosit', $darah['rbc']??null, 'jt/µL', 4.0, 5.9) !!}
        {!! riItem('Leukosit', $darah['wbc']??null, 'rb/µL', 4.0, 11.0) !!}
        {!! riItem('Trombosit', $darah['plt']??null, 'rb/µL', 150, 400) !!}
        {!! riItem('MCV', $darah['mcv']??null, 'fL', 80, 100) !!}
        {!! riItem('MCH', $darah['mch']??null, 'pg', 27, 33) !!}
        {!! riItem('LED/ESR', $darah['led']??null, 'mm/jam', 0, 20) !!}
    </div>

    {{-- 3. Kimia Darah --}}
    <div class="section-title">⚗️ Kimia Darah – Metabolik & Fungsi Organ</div>
    <div class="results-grid">
        {!! riItem('Glukosa Puasa', $kimia['gdp']??null, 'mg/dL', 70, 100) !!}
        {!! riItem('HbA1c', $kimia['hba1c']??null, '%', 0, 5.7) !!}
        {!! riItem('Kol. Total', $kimia['kol']??null, 'mg/dL', 0, 200) !!}
        {!! riItem('HDL', $kimia['hdl']??null, 'mg/dL', 60, 999) !!}
        {!! riItem('LDL', $kimia['ldl']??null, 'mg/dL', 0, 100) !!}
        {!! riItem('Trigliserida', $kimia['trig']??null, 'mg/dL', 0, 150) !!}
        {!! riItem('Asam Urat', $kimia['au']??null, 'mg/dL', 2.5, 7.0) !!}
        {!! riItem('Kreatinin', $kimia['krea']??null, 'mg/dL', 0.6, 1.3) !!}
        {!! riItem('SGOT', $kimia['sgot']??null, 'U/L', 0, 40) !!}
        {!! riItem('SGPT', $kimia['sgpt']??null, 'U/L', 0, 41) !!}
        {!! riItem('Natrium', $kimia['na']??null, 'mEq/L', 136, 145) !!}
        {!! riItem('Kalium', $kimia['k']??null, 'mEq/L', 3.5, 5.1) !!}
    </div>

    {{-- 4. Urinalisis --}}
    <div class="section-title">🧫 Urinalisis</div>
    <div class="results-grid">
        {!! riText('Warna Urin', $urin['warna']??null) !!}
        {!! riText('Protein', $urin['prot']??null) !!}
        {!! riText('Glukosa Urin', $urin['gluk']??null) !!}
        {!! riText('Nitrit', $urin['nitrit']??null) !!}
        {!! riItem('pH Urin', $urin['ph']??null, '', 4.5, 8.0) !!}
        {!! riItem('Eritrosit Sedimen', $urin['seri']??null, '/LPB', 0, 3) !!}
        {!! riItem('Leukosit Sedimen', $urin['sleu']??null, '/LPB', 0, 5) !!}
        {!! riText('Bakteri', $urin['bakteri']??null) !!}
    </div>

    {{-- 5. Jantung & Paru --}}
    <div class="section-title">❤️ Jantung & 🫁 Paru</div>
    <div class="results-grid">
        {!! riText('EKG', $jantung['ekg']??null) !!}
        {!! riItem('Irama Jantung', $jantung['irama']??null, 'bpm', 60, 100) !!}
        {!! riText('Rontgen Thorax', $jantung['rontgen']??null) !!}
        {!! riText('Troponin I', $jantung['trop']??null) !!}
        {!! riItem('FEV1/FVC', $jantung['ratio']??null, '', 0.7, 1.0) !!}
    </div>

    {{-- 6. Mata & THT --}}
    <div class="section-title">👁️ Mata & 👂 THT</div>
    <div class="results-grid">
        {!! riText('Visus OD (Kanan)', $mata['od']??null) !!}
        {!! riText('Visus OS (Kiri)', $mata['os']??null) !!}
        {!! riItem('TIO Kanan', $mata['tio_r']??null, 'mmHg', 10, 21) !!}
        {!! riItem('TIO Kiri', $mata['tio_l']??null, 'mmHg', 10, 21) !!}
        {!! riText('Buta Warna', $mata['bwarna']??null) !!}
        {!! riItem('Audiometri Kanan', $mata['audio_r']??null, 'dB', 0, 25) !!}
        {!! riItem('Audiometri Kiri', $mata['audio_l']??null, 'dB', 0, 25) !!}
        {!! riText('THT', $mata['tenggo']??null) !!}
    </div>

    {{-- Kesimpulan --}}
    <div class="section-title">📝 Kesimpulan & Rekomendasi</div>
    <div class="conclusion">
        <div class="conc-box">
            <label>Kesimpulan Umum</label>
            <p>{{ $mcu->kesimpulan }}</p>
        </div>
        <div class="conc-box">
            <label>Rekomendasi Dokter</label>
            <p>{{ $mcu->rekomendasi }}</p>
        </div>
    </div>

    {{-- Footer --}}
    <div class="footer">
        <div>
            <p>Follow-up: <strong>{{ $mcu->followup ? \Carbon\Carbon::parse($mcu->followup)->format('d F Y') : '-' }}</strong></p>
            <p style="margin-top:4px">Dokumen ini dicetak secara resmi oleh sistem Apotek Sejahtera</p>
        </div>
        <div class="sign-area">
            <div class="line"></div>
            <p>{{ $mcu->dokter->nama ?? 'Dokter Pemeriksa' }}</p>
            <p style="font-weight:400;color:#607080">Dokter Pemeriksa</p>
        </div>
    </div>

</div>
</body>
</html>
