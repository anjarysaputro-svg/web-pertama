<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><title>Invoice {{ $billing->no_tagihan }}</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DejaVu Sans',Arial,sans-serif;font-size:11px;color:#1a2332;background:#fff;padding:15mm 12mm}
.header{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:12px;border-bottom:3px solid #1565C0;margin-bottom:16px}
.logo h1{font-size:22px;font-weight:800;color:#1565C0}
.logo p{font-size:9px;color:#607080;margin-top:2px}
.inv-title{text-align:right}
.inv-title .label{font-size:20px;font-weight:800;color:#1565C0}
.inv-title p{font-size:9px;color:#607080}
.status-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:700;margin-top:4px}
.lunas{background:#E8F5E9;color:#2E7D32}.cicilan{background:#FFF9C4;color:#F57F17}.belum{background:#FFEBEE;color:#C62828}
.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px}
.info-box{background:#F7FAFC;border-radius:8px;padding:10px 12px}
.info-box label{display:block;font-size:8px;font-weight:800;text-transform:uppercase;letter-spacing:.07em;color:#607080;margin-bottom:4px}
.info-box p{font-size:11px;font-weight:600}
table{width:100%;border-collapse:collapse;margin-bottom:12px}
thead th{background:#1565C0;color:#fff;padding:8px 10px;text-align:left;font-size:9px;font-weight:800;text-transform:uppercase}
tbody td{padding:8px 10px;border-bottom:1px solid #F0F4F8;font-size:10px}
.total-box{background:#1565C0;color:#fff;border-radius:8px;padding:12px 16px;display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.total-box .label{font-size:11px;font-weight:600}
.total-box .amount{font-size:18px;font-weight:800}
.subtotal{display:flex;justify-content:space-between;font-size:10px;padding:4px 0}
.footer{margin-top:20px;padding-top:10px;border-top:1px solid #DDE3EA;display:flex;justify-content:space-between;align-items:flex-end}
.sign{text-align:center}
.sign .line{width:130px;border-bottom:1px solid #1a2332;margin:30px auto 5px}
.sign p{font-size:9px}
.notes{font-size:9px;color:#607080;font-style:italic}
</style></head>
<body>
<div class="header">
    <div class="logo">
        <h1>✚ Apotek Sejahtera</h1>
        <p>Sistem Informasi Rekam Medis Digital</p>
        <p>Jl. Contoh No. 1, Jakarta | (021) 1234-5678</p>
    </div>
    <div class="inv-title">
        <div class="label">INVOICE</div>
        <p>No: {{ $billing->no_tagihan }}</p>
        <p>Tanggal: {{ $billing->tgl->format('d/m/Y') }}</p>
        <span class="status-badge {{ $billing->status==='Lunas'?'lunas':($billing->status==='Cicilan'?'cicilan':'belum') }}">
            {{ $billing->status_pembayaran }}
        </span>
    </div>
</div>

<div class="info-grid">
    <div class="info-box">
        <label>Tagihan Kepada</label>
        <p>{{ $billing->pasien->nama??'-' }}</p>
        <p style="font-weight:400;font-size:9px;margin-top:2px">No. RM: {{ $billing->pasien->no_rm??'-' }}</p>
        <p style="font-weight:400;font-size:9px">{{ $billing->pasien->no_hp??'' }}</p>
        <p style="font-weight:400;font-size:9px">{{ $billing->pasien->alamat??'' }}</p>
    </div>
    <div class="info-box">
        <label>Detail Pembayaran</label>
        <p>Metode: {{ $billing->metode }}</p>
        <p style="font-weight:400;font-size:9px;margin-top:2px">Tgl Bayar: {{ $billing->tgl->format('d F Y') }}</p>
        @if($billing->catatan)<p style="font-weight:400;font-size:9px">Catatan: {{ $billing->catatan }}</p>@endif
    </div>
</div>

<table>
    <thead><tr><th>No</th><th>Keterangan Layanan</th><th style="text-align:right">Jumlah</th></tr></thead>
    <tbody>
        <tr><td>1</td><td>{{ $billing->layanan }}</td><td style="text-align:right">Rp {{ number_format($billing->total,0,',','.') }}</td></tr>
    </tbody>
</table>

<div style="max-width:280px;margin-left:auto">
    <div class="subtotal"><span>Subtotal</span><span>Rp {{ number_format($billing->total,0,',','.') }}</span></div>
    <div class="subtotal"><span>Dibayar</span><span style="color:#2E7D32;font-weight:700">Rp {{ number_format($billing->bayar,0,',','.') }}</span></div>
    @if($billing->sisa > 0)
    <div class="subtotal"><span>Sisa Tagihan</span><span style="color:#C62828;font-weight:700">Rp {{ number_format($billing->sisa,0,',','.') }}</span></div>
    @endif
    <div class="total-box" style="margin-top:8px">
        <span class="label">TOTAL TAGIHAN</span>
        <span class="amount">Rp {{ number_format($billing->total,0,',','.') }}</span>
    </div>
</div>

<div class="footer">
    <div class="notes">
        <p>* Invoice ini dibuat secara otomatis oleh sistem Apotek Sejahtera</p>
        <p>* Simpan bukti pembayaran ini sebagai tanda bukti transaksi</p>
        <p>* Dicetak: {{ now()->format('d/m/Y H:i') }}</p>
    </div>
    <div class="sign">
        <div class="line"></div>
        <p style="font-weight:700">Petugas Kasir</p>
        <p>Apotek Sejahtera</p>
    </div>
</div>
</body></html>
