@extends('layouts.app')
@section('title','🧪 Detail MCU – ' . $mcu->pasien->nama)

@section('content')
@php
function riItem($label, $val, $unit, $min, $max) {
    if (!isset($val) || $val === '' || $val === null) return '';
    $v = floatval($val);
    $cls = 'border-green-400 bg-green-50'; $flag = '✓ Normal'; $fc = 'text-green-600';
    if ($min !== null && $max !== null) {
        if ($v < $min)      { $cls='border-blue-400 bg-blue-50';   $flag='↓ Rendah'; $fc='text-blue-600'; }
        elseif ($v > $max)  { $cls='border-red-400 bg-red-50';     $flag='↑ Tinggi'; $fc='text-red-600'; }
    }
    return "<div class='rounded-xl p-3 border-l-4 $cls'>
        <p class='text-[10px] font-bold text-slate-500 uppercase tracking-wider'>$label</p>
        <p class='text-lg font-black text-slate-800 my-0.5'>$val <span class='text-xs font-normal text-slate-400'>$unit</span></p>
        <p class='text-[10px] flex justify-between'><span class='text-slate-400'>".($min!==null?"$min–$max":'—')."</span><span class='font-bold $fc'>$flag</span></p>
    </div>";
}
function riText($label, $val) {
    if (!$val) return '';
    $normals = ['Normal','Negatif','Tidak Ada','Jernih','Kuning Jernih','Normal Sinus'];
    $isNorm = false; foreach($normals as $n) { if(str_contains($val,$n)){$isNorm=true;break;} }
    $cls = $isNorm ? 'border-green-400 bg-green-50' : 'border-yellow-400 bg-yellow-50';
    return "<div class='rounded-xl p-3 border-l-4 $cls'>
        <p class='text-[10px] font-bold text-slate-500 uppercase tracking-wider'>$label</p>
        <p class='text-sm font-semibold text-slate-800 mt-1'>$val</p>
    </div>";
}
$f = $mcu->fisik ?? []; $d = $mcu->darah ?? []; $k = $mcu->kimia ?? []; $u = $mcu->urin ?? []; $j = $mcu->jantung ?? []; $m = $mcu->mata ?? [];
$riskColor = ['Rendah'=>'green','Sedang'=>'yellow','Tinggi'=>'red'][$mcu->risiko] ?? 'gray';
@endphp

<div class="max-w-5xl mx-auto space-y-5">

    {{-- Header --}}
    <div class="card overflow-hidden">
        <div class="bg-gradient-to-r from-blue-700 to-cyan-500 p-6 text-white">
            <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div>
                    <p class="text-blue-200 text-xs font-bold uppercase tracking-widest mb-1">{{ $mcu->no_mcu }}</p>
                    <h2 class="text-xl font-black">Laporan MCU – {{ $mcu->pasien->nama }}</h2>
                    <p class="text-blue-100 text-sm mt-1">{{ $mcu->jenis }} &nbsp;|&nbsp; {{ $mcu->tgl->isoFormat('D MMMM Y') }} &nbsp;|&nbsp; {{ $mcu->dokter->nama??'-' }}</p>
                </div>
                <div class="flex flex-col items-end gap-2">
                    <div class="bg-white rounded-xl px-4 py-2 text-center">
                        <p class="text-xs font-bold text-slate-500 uppercase">Kategori</p>
                        <p class="font-bold text-slate-800 text-sm mt-0.5">{{ $mcu->kategori }}</p>
                        <span class="badge badge-{{ $riskColor }} mt-1">Risiko {{ $mcu->risiko }}</span>
                    </div>
                    <div class="flex gap-2">
                        <a href="{{ route('mcu.pdf',$mcu) }}" target="_blank" class="btn btn-sm bg-white text-blue-700 hover:bg-blue-50 border-0">🖨️ Cetak PDF</a>
                        <a href="{{ route('mcu.index') }}" class="btn btn-sm bg-white/20 text-white border-0">← Kembali</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Fisik & Vital --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold text-slate-700">🩺 Tanda Vital & Antropometri</h3></div>
        <div class="p-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {!! riItem('Berat Badan',$f['bb']??null,'kg',50,90) !!}
            {!! riItem('Tinggi Badan',$f['tb']??null,'cm',150,200) !!}
            {!! riItem('IMT/BMI',$f['bmi']??null,'kg/m²',18.5,24.9) !!}
            {!! riItem('Sistolik',$f['sistol']??null,'mmHg',90,120) !!}
            {!! riItem('Diastolik',$f['diastol']??null,'mmHg',60,80) !!}
            {!! riItem('Denyut Nadi',$f['nadi']??null,'x/mnt',60,100) !!}
            {!! riItem('Suhu Tubuh',$f['suhu']??null,'°C',36.1,37.2) !!}
            {!! riItem('Saturasi O₂',$f['spo2']??null,'%',95,100) !!}
        </div>
    </div>

    {{-- Darah --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold text-slate-700">🔴 Darah Lengkap (Hematologi)</h3></div>
        <div class="p-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {!! riItem('Hemoglobin',$d['hb']??null,'g/dL',12,17.5) !!}
            {!! riItem('Hematokrit',$d['ht']??null,'%',36,53) !!}
            {!! riItem('Eritrosit',$d['rbc']??null,'jt/µL',4.0,5.9) !!}
            {!! riItem('Leukosit',$d['wbc']??null,'rb/µL',4.0,11.0) !!}
            {!! riItem('Trombosit',$d['plt']??null,'rb/µL',150,400) !!}
            {!! riItem('MCV',$d['mcv']??null,'fL',80,100) !!}
            {!! riItem('MCH',$d['mch']??null,'pg',27,33) !!}
            {!! riItem('LED/ESR',$d['led']??null,'mm/jam',0,20) !!}
            {!! riItem('Neutrofil',$d['netro']??null,'%',50,70) !!}
            {!! riItem('Limfosit',$d['limfo']??null,'%',20,40) !!}
            {!! riItem('Monosit',$d['mono']??null,'%',2,8) !!}
            {!! riItem('Eosinofil',$d['eosi']??null,'%',1,4) !!}
        </div>
    </div>

    {{-- Kimia Darah --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold text-slate-700">⚗️ Kimia Darah – Metabolik</h3></div>
        <div class="p-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {!! riItem('Glukosa Puasa',$k['gdp']??null,'mg/dL',70,100) !!}
            {!! riItem('HbA1c',$k['hba1c']??null,'%',0,5.7) !!}
            {!! riItem('Kol. Total',$k['kol']??null,'mg/dL',0,200) !!}
            {!! riItem('HDL',$k['hdl']??null,'mg/dL',60,999) !!}
            {!! riItem('LDL',$k['ldl']??null,'mg/dL',0,100) !!}
            {!! riItem('Trigliserida',$k['trig']??null,'mg/dL',0,150) !!}
            {!! riItem('Asam Urat',$k['au']??null,'mg/dL',2.5,7.0) !!}
            {!! riItem('Kreatinin',$k['krea']??null,'mg/dL',0.6,1.3) !!}
            {!! riItem('SGOT',$k['sgot']??null,'U/L',0,40) !!}
            {!! riItem('SGPT',$k['sgpt']??null,'U/L',0,41) !!}
            {!! riItem('Natrium',$k['na']??null,'mEq/L',136,145) !!}
            {!! riItem('Kalium',$k['k']??null,'mEq/L',3.5,5.1) !!}
        </div>
    </div>

    {{-- Urinalisis --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold text-slate-700">🧫 Urinalisis</h3></div>
        <div class="p-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {!! riText('Warna Urin',$u['warna']??null) !!}
            {!! riText('Protein',$u['prot']??null) !!}
            {!! riText('Glukosa',$u['gluk']??null) !!}
            {!! riText('Nitrit',$u['nitrit']??null) !!}
            {!! riItem('pH Urin',$u['ph']??null,'',4.5,8.0) !!}
            {!! riItem('Eritrosit Sedimen',$u['seri']??null,'/LPB',0,3) !!}
            {!! riItem('Leukosit Sedimen',$u['sleu']??null,'/LPB',0,5) !!}
            {!! riText('Bakteri',$u['bakteri']??null) !!}
        </div>
    </div>

    {{-- Jantung & Paru --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold text-slate-700">❤️ Jantung & 🫁 Paru</h3></div>
        <div class="p-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {!! riText('EKG/ECG',$j['ekg']??null) !!}
            {!! riItem('Irama Jantung',$j['irama']??null,'bpm',60,100) !!}
            {!! riText('Rontgen Thorax',$j['rontgen']??null) !!}
            {!! riText('Troponin I',$j['trop']??null) !!}
            {!! riItem('FEV1/FVC',$j['ratio']??null,'',0.7,1.0) !!}
        </div>
    </div>

    {{-- Mata & THT --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold text-slate-700">👁️ Mata & 👂 THT</h3></div>
        <div class="p-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {!! riText('Visus Kanan (OD)',$m['od']??null) !!}
            {!! riText('Visus Kiri (OS)',$m['os']??null) !!}
            {!! riItem('TIO Kanan',$m['tio_r']??null,'mmHg',10,21) !!}
            {!! riItem('TIO Kiri',$m['tio_l']??null,'mmHg',10,21) !!}
            {!! riText('Buta Warna',$m['bwarna']??null) !!}
            {!! riText('Funduskopi',$m['fundus']??null) !!}
            {!! riItem('Audiometri Kanan',$m['audio_r']??null,'dB',0,25) !!}
            {!! riItem('Audiometri Kiri',$m['audio_l']??null,'dB',0,25) !!}
        </div>
    </div>

    {{-- Kesimpulan --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold text-slate-700">📝 Kesimpulan & Rekomendasi</h3></div>
        <div class="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
            <div class="bg-gray-50 rounded-xl p-4"><p class="text-xs font-bold text-slate-400 uppercase mb-2">Kesimpulan</p><p class="text-sm leading-relaxed">{{ $mcu->kesimpulan }}</p></div>
            <div class="bg-blue-50 rounded-xl p-4"><p class="text-xs font-bold text-slate-400 uppercase mb-2">Rekomendasi</p><p class="text-sm leading-relaxed">{{ $mcu->rekomendasi }}</p></div>
        </div>
        <div class="px-5 pb-5 flex flex-wrap gap-3">
            <div class="bg-gray-50 rounded-xl px-4 py-2"><span class="text-xs text-slate-400">Follow-up: </span><span class="font-semibold text-sm">{{ $mcu->followup?->isoFormat('D MMMM Y')??'-' }}</span></div>
            <div class="bg-gray-50 rounded-xl px-4 py-2"><span class="text-xs text-slate-400">Status: </span><x-status-badge :status="$mcu->status"/></div>
        </div>
    </div>

</div>
@endsection
