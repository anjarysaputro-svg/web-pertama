@extends('layouts.app')
@section('title', '🧪 Hasil MCU')

@section('content')

{{-- Stats --}}
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-2xl shadow-sm p-4 text-center border border-gray-100">
        <p class="text-3xl font-black text-blue-700">{{ $stats['total'] }}</p>
        <p class="text-xs text-slate-500 font-semibold mt-1">Total MCU</p>
    </div>
    <div class="bg-white rounded-2xl shadow-sm p-4 text-center border border-gray-100">
        <p class="text-3xl font-black text-green-600">{{ $stats['normal'] }}</p>
        <p class="text-xs text-slate-500 font-semibold mt-1">Risiko Rendah</p>
    </div>
    <div class="bg-white rounded-2xl shadow-sm p-4 text-center border border-gray-100">
        <p class="text-3xl font-black text-yellow-500">{{ $stats['sedang'] }}</p>
        <p class="text-xs text-slate-500 font-semibold mt-1">Risiko Sedang</p>
    </div>
    <div class="bg-white rounded-2xl shadow-sm p-4 text-center border border-gray-100">
        <p class="text-3xl font-black text-red-600">{{ $stats['tinggi'] }}</p>
        <p class="text-xs text-slate-500 font-semibold mt-1">Risiko Tinggi</p>
    </div>
</div>

<div class="flex flex-col sm:flex-row gap-3 justify-between mb-4">
    <form class="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 py-2 shadow-sm">
        <svg class="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari pasien MCU..." class="text-sm outline-none w-44">
    </form>
    <a href="{{ route('mcu.create') }}" class="btn btn-primary">➕ Input Hasil MCU</a>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="font-bold">Data Hasil MCU (<span class="text-blue-600">{{ $mcus->total() }}</span>)</h3>
    </div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr>
                <th>No. MCU</th><th>Pasien</th><th>Jenis</th>
                <th class="hidden md:table-cell">Dokter</th>
                <th class="hidden md:table-cell">Tanggal</th>
                <th>Risiko</th><th>Status</th><th>Aksi</th>
            </tr></thead>
            <tbody>
            @forelse($mcus as $m)
            <tr>
                <td><span class="font-mono text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded-lg">{{ $m->no_mcu }}</span></td>
                <td class="font-semibold">{{ $m->pasien->nama ?? '-' }}</td>
                <td class="text-slate-500 text-xs">{{ $m->jenis }}</td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ $m->dokter->nama ?? '-' }}</td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ \Carbon\Carbon::parse($m->tgl)->format('d/m/Y') }}</td>
                <td>
                    @if($m->risiko === 'Rendah') <span class="badge badge-green">{{ $m->risiko }}</span>
                    @elseif($m->risiko === 'Sedang') <span class="badge badge-yellow">{{ $m->risiko }}</span>
                    @else <span class="badge badge-red">{{ $m->risiko }}</span>
                    @endif
                </td>
                <td>
                    @if($m->status === 'Selesai') <span class="badge badge-green">{{ $m->status }}</span>
                    @else <span class="badge badge-yellow">{{ $m->status }}</span>
                    @endif
                </td>
                <td>
                    <div class="flex gap-1">
                        <a href="{{ route('mcu.show', $m) }}" class="act-btn" title="Detail">👁️</a>
                        <a href="{{ route('mcu.pdf', $m) }}" target="_blank" class="act-btn" title="Cetak PDF">🖨️</a>
                        <form method="POST" action="{{ route('mcu.destroy', $m) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn" onclick="return confirm('Hapus data MCU ini?')">🗑️</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="8" class="text-center py-12 text-slate-400">
                <p class="text-4xl mb-3">🧪</p>
                <p>Belum ada data MCU</p>
                <a href="{{ route('mcu.create') }}" class="btn btn-primary mt-3 inline-flex">➕ Input Pertama</a>
            </td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($mcus->hasPages())
    <div class="px-6 py-4 border-t border-gray-100">{{ $mcus->withQueryString()->links() }}</div>
    @endif
</div>

<style>.act-btn { @apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer; }</style>
@endsection
