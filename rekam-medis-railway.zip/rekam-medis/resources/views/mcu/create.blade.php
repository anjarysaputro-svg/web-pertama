@extends('layouts.app')
@section('title','🧪 Input Hasil MCU')

@section('content')
<div class="max-w-5xl mx-auto" x-data="{ tab: 'fisik' }">
<form method="POST" action="{{ route('mcu.store') }}">
@csrf

{{-- Header Info --}}
<div class="card mb-5">
    <div class="card-header"><h3 class="font-bold">Input Hasil Medical Check-Up (MCU)</h3>
        <a href="{{ route('mcu.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <div>
                <label class="form-label">Pasien *</label>
                <select name="pasien_id" class="form-select" required>
                    <option value="">-- Pilih Pasien --</option>
                    @foreach($pasiens as $p)
                    <option value="{{ $p->id }}">{{ $p->nama }} ({{ $p->no_rm }})</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="form-label">Dokter Pemeriksa *</label>
                <select name="dokter_id" class="form-select" required>
                    <option value="">-- Pilih Dokter --</option>
                    @foreach($dokters as $d)
                    <option value="{{ $d->id }}">{{ $d->nama }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="form-label">Tanggal MCU *</label>
                <input type="date" name="tgl" value="{{ date('Y-m-d') }}" class="form-input" required>
            </div>
            <div>
                <label class="form-label">Jenis MCU *</label>
                <select name="jenis" class="form-select" required>
                    @foreach(['MCU Basic','MCU Standard','MCU Komprehensif','MCU Executive','MCU Pre-Employment'] as $j)
                    <option value="{{ $j }}">{{ $j }}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
</div>

{{-- Tab Navigation --}}
<div class="flex gap-2 flex-wrap mb-4">
    @foreach([['fisik','🩺 Fisik & Vital'],['darah','🔴 Darah'],['kimia','⚗️ Kimia Darah'],['urin','🧫 Urinalisis'],['jantung','❤️ Jantung & Paru'],['mata','👁️ Mata & THT'],['kesimpulan','📝 Kesimpulan']] as [$t,$l])
    <button type="button" @click="tab='{{ $t }}'"
        :class="tab==='{{ $t }}' ? 'bg-blue-700 text-white border-blue-700' : 'bg-white text-slate-600 border-gray-200 hover:border-blue-400'"
        class="px-4 py-2 rounded-xl border font-semibold text-sm transition-all">{{ $l }}</button>
    @endforeach
</div>

{{-- TAB: FISIK --}}
<div x-show="tab==='fisik'" class="card mb-5">
    <div class="card-header"><h3 class="font-bold text-blue-700">🩺 Pemeriksaan Fisik & Tanda Vital</h3></div>
    <div class="card-body">
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            @php $fisikFields = [['bb','Berat Badan','kg','number','50–90'],['tb','Tinggi Badan','cm','number','150–200'],['bmi','IMT/BMI','kg/m²','number','18.5–24.9'],['sistol','Sistolik','mmHg','number','90–120'],['diastol','Diastolik','mmHg','number','60–80'],['nadi','Denyut Nadi','x/mnt','number','60–100'],['napas','Frek. Napas','x/mnt','number','12–20'],['suhu','Suhu Tubuh','°C','number','36.1–37.2'],['spo2','Saturasi O₂','%','number','≥95'],['lp','Lingkar Perut','cm','number','L<90 P<80'],['ping','Lingkar Pinggang','cm','number','—']]; @endphp
            @foreach($fisikFields as [$k,$label,$unit,$type,$ref])
            <div>
                <label class="form-label">{{ $label }}</label>
                <div class="flex gap-1">
                    <input type="{{ $type }}" step="0.1" name="fisik[{{ $k }}]" class="form-input" placeholder="0"
                           @if($k==='bb') id="f_bb" oninput="calcBMI()" @endif
                           @if($k==='tb') id="f_tb" oninput="calcBMI()" @endif
                           @if($k==='bmi') id="f_bmi" readonly class="form-input bg-gray-50" @endif>
                    <span class="text-xs text-slate-400 self-center whitespace-nowrap">{{ $unit }}</span>
                </div>
                <p class="text-[10px] text-slate-400 mt-0.5">{{ $ref }}</p>
            </div>
            @endforeach
        </div>
    </div>
</div>

{{-- TAB: DARAH --}}
<div x-show="tab==='darah'" class="card mb-5">
    <div class="card-header"><h3 class="font-bold text-red-600">🔴 Darah Lengkap (Hematologi)</h3></div>
    <div class="card-body">
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            @php $darahFields = [['hb','Hemoglobin','g/dL','12–17.5'],['ht','Hematokrit','%','36–53'],['rbc','Eritrosit','jt/µL','4.0–5.9'],['wbc','Leukosit','rb/µL','4.0–11.0'],['plt','Trombosit','rb/µL','150–400'],['mcv','MCV','fL','80–100'],['mch','MCH','pg','27–33'],['mchc','MCHC','g/dL','32–36'],['led','LED/ESR','mm/jam','<20'],['netro','Neutrofil','%','50–70'],['limfo','Limfosit','%','20–40'],['mono','Monosit','%','2–8'],['eosi','Eosinofil','%','1–4'],['baso','Basofil','%','0–1'],['batang','Neutrofil Batang','%','3–5']]; @endphp
            @foreach($darahFields as [$k,$label,$unit,$ref])
            <div>
                <label class="form-label">{{ $label }}</label>
                <div class="flex gap-1">
                    <input type="number" step="0.01" name="darah[{{ $k }}]" class="form-input" placeholder="0">
                    <span class="text-xs text-slate-400 self-center whitespace-nowrap">{{ $unit }}</span>
                </div>
                <p class="text-[10px] text-slate-400 mt-0.5">{{ $ref }}</p>
            </div>
            @endforeach
        </div>
    </div>
</div>

{{-- TAB: KIMIA --}}
<div x-show="tab==='kimia'" class="card mb-5">
    <div class="card-header"><h3 class="font-bold text-purple-600">⚗️ Kimia Darah – Metabolik & Fungsi Organ</h3></div>
    <div class="card-body">
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            @php $kimiaFields = [['gdp','Glukosa Puasa','mg/dL','70–100'],['gpp','Glukosa 2j PP','mg/dL','<140'],['hba1c','HbA1c','%','<5.7'],['kol','Kol. Total','mg/dL','<200'],['hdl','HDL','mg/dL','>60'],['ldl','LDL','mg/dL','<100'],['trig','Trigliserida','mg/dL','<150'],['au','Asam Urat','mg/dL','2.5–7.0'],['krea','Kreatinin','mg/dL','0.6–1.3'],['bun','BUN/Ureum','mg/dL','7–25'],['sgot','SGOT (AST)','U/L','<40'],['sgpt','SGPT (ALT)','U/L','<41'],['bili','Bilirubin Total','mg/dL','0.3–1.2'],['prot','Protein Total','g/dL','6.4–8.3'],['alb','Albumin','g/dL','3.5–5.0'],['ca','Kalsium','mg/dL','8.6–10.2'],['na','Natrium','mEq/L','136–145'],['k','Kalium','mEq/L','3.5–5.1'],['tsh','TSH','µIU/mL','0.4–4.0'],['ft4','FT4','ng/dL','0.8–1.8'],['ft3','FT3','pg/mL','2.3–4.2']]; @endphp
            @foreach($kimiaFields as [$k,$label,$unit,$ref])
            <div>
                <label class="form-label">{{ $label }}</label>
                <div class="flex gap-1">
                    <input type="number" step="0.01" name="kimia[{{ $k }}]" class="form-input" placeholder="0">
                    <span class="text-xs text-slate-400 self-center whitespace-nowrap">{{ $unit }}</span>
                </div>
                <p class="text-[10px] text-slate-400 mt-0.5">{{ $ref }}</p>
            </div>
            @endforeach
        </div>
    </div>
</div>

{{-- TAB: URIN --}}
<div x-show="tab==='urin'" class="card mb-5">
    <div class="card-header"><h3 class="font-bold text-teal-600">🧫 Urinalisis</h3></div>
    <div class="card-body">
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            @php
            $urinSelect = [['warna','Warna Urin',['Kuning Jernih','Kuning Keruh','Kuning Pekat','Merah/Coklat','Lainnya']],['jernih','Kejernihan',['Jernih','Agak Keruh','Keruh']],['prot','Protein',['Negatif','Trace','+1','+2','+3','+4']],['gluk','Glukosa',['Negatif','+1','+2','+3']],['keton','Keton',['Negatif','+1','+2','+3']],['darah','Darah/Eritrosit',['Negatif','Trace','+1','+2']],['nitrit','Nitrit',['Negatif','Positif']],['leu','Leukosit Esterase',['Negatif','Trace','+1','+2']],['bili','Bilirubin',['Negatif','+1','+2']],['uro','Urobilinogen',['Normal','+1','+2']],['silinder','Silinder',['Tidak Ada','Hialin','Granuler','Eritrosit']],['kristal','Kristal',['Tidak Ada','Kalsium Oksalat','Asam Urat','Triple Phosphate']],['bakteri','Bakteri',['Negatif','Positif Sedikit','Positif Banyak']]];
            $urinNum = [['ph','pH Urin','','4.5–8.0'],['bj','Berat Jenis','','1.005–1.030'],['seri','Eritrosit Sedimen','/LPB','0–3'],['sleu','Leukosit Sedimen','/LPB','0–5']];
            @endphp
            @foreach($urinSelect as [$k,$label,$opts])
            <div>
                <label class="form-label">{{ $label }}</label>
                <select name="urin[{{ $k }}]" class="form-select">
                    @foreach($opts as $opt)<option>{{ $opt }}</option>@endforeach
                </select>
            </div>
            @endforeach
            @foreach($urinNum as [$k,$label,$unit,$ref])
            <div>
                <label class="form-label">{{ $label }}</label>
                <div class="flex gap-1">
                    <input type="number" step="0.001" name="urin[{{ $k }}]" class="form-input" placeholder="0">
                    @if($unit)<span class="text-xs text-slate-400 self-center">{{ $unit }}</span>@endif
                </div>
                <p class="text-[10px] text-slate-400 mt-0.5">{{ $ref }}</p>
            </div>
            @endforeach
        </div>
    </div>
</div>

{{-- TAB: JANTUNG --}}
<div x-show="tab==='jantung'" class="card mb-5">
    <div class="card-header"><h3 class="font-bold text-red-600">❤️ Jantung & 🫁 Paru</h3></div>
    <div class="card-body">
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div><label class="form-label">EKG/ECG</label>
                <select name="jantung[ekg]" class="form-select">
                    @foreach(['Normal Sinus Rhythm','Sinus Bradikardi','Sinus Takikardi','Atrial Fibrilasi','Left Bundle Branch Block','Right Bundle Branch Block','ST Elevasi','ST Depresi','Lainnya'] as $o)
                    <option>{{ $o }}</option>@endforeach
                </select>
            </div>
            <div><label class="form-label">Irama Jantung</label><div class="flex gap-1"><input type="number" name="jantung[irama]" class="form-input" placeholder="80"><span class="text-xs text-slate-400 self-center">bpm</span></div></div>
            <div><label class="form-label">Hasil EKG</label>
                <select name="jantung[hasil]" class="form-select">
                    <option>Normal</option><option>Abnormal – Ringan</option><option>Abnormal – Perlu Tindak Lanjut</option>
                </select>
            </div>
            <div><label class="form-label">Troponin I</label><select name="jantung[trop]" class="form-select"><option>Negatif</option><option>Positif Rendah</option><option>Positif Tinggi</option></select></div>
            <div><label class="form-label">CK-MB</label><div class="flex gap-1"><input type="number" name="jantung[ckmb]" class="form-input" placeholder="0"><span class="text-xs text-slate-400 self-center">U/L</span></div></div>
            <div><label class="form-label">Rontgen Thorax</label>
                <select name="jantung[rontgen]" class="form-select">
                    @foreach(['Normal','Kardiomegali','Infiltrat / Pneumonia','Efusi Pleura','TB Paru Aktif','TB Paru Inaktif','Emfisema'] as $o)<option>{{ $o }}</option>@endforeach
                </select>
            </div>
            <div><label class="form-label">Cor (Jantung)</label><select name="jantung[cor]" class="form-select"><option>Normal</option><option>Besar Normal Atas</option><option>Kardiomegali</option></select></div>
            <div><label class="form-label">Pulmo (Paru)</label><select name="jantung[pulmo]" class="form-select"><option>Normal</option><option>Hiperaerasi</option><option>Infiltrat</option><option>Fibrosis</option></select></div>
            <div><label class="form-label">Spirometri FVC</label><div class="flex gap-1"><input type="number" step="0.01" name="jantung[fvc]" class="form-input" placeholder="0"><span class="text-xs text-slate-400 self-center">L</span></div></div>
            <div><label class="form-label">Spirometri FEV1</label><div class="flex gap-1"><input type="number" step="0.01" name="jantung[fev1]" class="form-input" placeholder="0"><span class="text-xs text-slate-400 self-center">L</span></div></div>
            <div><label class="form-label">Rasio FEV1/FVC</label><div class="flex gap-1"><input type="number" step="0.01" name="jantung[ratio]" class="form-input" placeholder="0"><span class="text-xs text-slate-400 self-center"></span></div></div>
        </div>
    </div>
</div>

{{-- TAB: MATA & THT --}}
<div x-show="tab==='mata'" class="card mb-5">
    <div class="card-header"><h3 class="font-bold text-blue-600">👁️ Mata & 👂 THT</h3></div>
    <div class="card-body">
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div><label class="form-label">Visus Mata Kanan (OD)</label><input type="text" name="mata[od]" class="form-input" placeholder="6/6"></div>
            <div><label class="form-label">Visus Mata Kiri (OS)</label><input type="text" name="mata[os]" class="form-input" placeholder="6/6"></div>
            <div><label class="form-label">TIO Kanan (mmHg)</label><input type="number" name="mata[tio_r]" class="form-input" placeholder="0"></div>
            <div><label class="form-label">TIO Kiri (mmHg)</label><input type="number" name="mata[tio_l]" class="form-input" placeholder="0"></div>
            <div><label class="form-label">Buta Warna</label><select name="mata[bwarna]" class="form-select"><option>Normal</option><option>Buta Warna Parsial</option><option>Buta Warna Total</option></select></div>
            <div><label class="form-label">Funduskopi</label><select name="mata[fundus]" class="form-select"><option>Normal</option><option>Retinopati Diabetik</option><option>Retinopati Hipertensi</option><option>Katarak</option><option>Glaukoma</option></select></div>
            <div><label class="form-label">Audiometri Kanan (dB)</label><input type="number" name="mata[audio_r]" class="form-input" placeholder="0"></div>
            <div><label class="form-label">Audiometri Kiri (dB)</label><input type="number" name="mata[audio_l]" class="form-input" placeholder="0"></div>
            <div><label class="form-label">Kondisi Telinga</label><select name="mata[telinga]" class="form-select"><option>Normal</option><option>Serumen Prop</option><option>Otitis Media</option><option>Perforasi Membran Timpani</option></select></div>
            <div><label class="form-label">Kondisi Hidung</label><select name="mata[hidung]" class="form-select"><option>Normal</option><option>Deviasi Septum</option><option>Polip Nasal</option><option>Sinusitis</option></select></div>
            <div><label class="form-label">Kondisi Tenggorokan</label><select name="mata[tenggo]" class="form-select"><option>Normal</option><option>Tonsilitis</option><option>Faringitis</option><option>Hipertrofi Tonsil</option></select></div>
            <div><label class="form-label">Gigi & Mulut</label><select name="mata[gigi]" class="form-select"><option>Normal</option><option>Karies Gigi</option><option>Gingivitis</option><option>Missing Teeth</option></select></div>
        </div>
    </div>
</div>

{{-- TAB: KESIMPULAN --}}
<div x-show="tab==='kesimpulan'" class="card mb-5">
    <div class="card-header"><h3 class="font-bold text-green-600">📝 Kesimpulan & Rekomendasi</h3></div>
    <div class="card-body">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
                <label class="form-label">Kategori Kesehatan *</label>
                <select name="kategori" class="form-select" required>
                    @foreach(['Sehat – Fit untuk Bekerja','Sehat dengan Catatan','Perlu Pemeriksaan Lanjutan','Tidak Fit – Perlu Pengobatan'] as $k)
                    <option>{{ $k }}</option>@endforeach
                </select>
            </div>
            <div>
                <label class="form-label">Tingkat Risiko *</label>
                <select name="risiko" class="form-select" required>
                    <option value="Rendah">🟢 Rendah</option>
                    <option value="Sedang">🟡 Sedang</option>
                    <option value="Tinggi">🔴 Tinggi</option>
                </select>
            </div>
            <div class="sm:col-span-2">
                <label class="form-label">Kesimpulan Umum *</label>
                <textarea name="kesimpulan" class="form-textarea" required placeholder="Kesimpulan hasil MCU secara keseluruhan..."></textarea>
            </div>
            <div class="sm:col-span-2">
                <label class="form-label">Rekomendasi / Saran Dokter</label>
                <textarea name="rekomendasi" class="form-textarea" placeholder="Rekomendasi tindak lanjut..."></textarea>
            </div>
            <div>
                <label class="form-label">Tanggal Follow-up</label>
                <input type="date" name="followup" class="form-input" value="{{ date('Y-m-d', strtotime('+3 months')) }}">
            </div>
            <div>
                <label class="form-label">Status Hasil</label>
                <select name="status" class="form-select">
                    <option value="Selesai">Selesai</option>
                    <option value="Menunggu Lab">Menunggu Lab</option>
                    <option value="Perlu Review Dokter">Perlu Review Dokter</option>
                </select>
            </div>
        </div>
    </div>
</div>

{{-- Action Buttons --}}
<div class="flex flex-wrap gap-3">
    <button type="submit" class="btn btn-primary btn-lg">💾 Simpan Hasil MCU</button>
    <a href="{{ route('mcu.index') }}" class="btn btn-outline btn-lg">Batal</a>
</div>

</form>
</div>

@push('scripts')
<script>
function calcBMI() {
    const bb = parseFloat(document.getElementById('f_bb')?.value) || 0;
    const tb = parseFloat(document.getElementById('f_tb')?.value) || 0;
    const bmiEl = document.getElementById('f_bmi');
    if (bb && tb && bmiEl) {
        bmiEl.value = (bb / Math.pow(tb / 100, 2)).toFixed(1);
    }
}
</script>
@endpush
@endsection
