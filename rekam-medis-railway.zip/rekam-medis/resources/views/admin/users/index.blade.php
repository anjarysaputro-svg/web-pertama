@extends('layouts.app')
@section('title', '⚙️ Manajemen User')
@section('content')
<div class="flex justify-between items-center mb-6">
    <p class="text-slate-500 text-sm">Total <strong>{{ $users->total() }}</strong> user</p>
    <a href="{{ route('users.create') }}" class="btn btn-primary">➕ Tambah User</a>
</div>
<div class="card">
    <div class="card-header"><h3 class="font-bold">Daftar User Sistem</h3></div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr><th>Nama</th><th>Email</th><th>Role</th><th class="hidden md:table-cell">Tgl Daftar</th><th>Aksi</th></tr></thead>
            <tbody>
            @forelse($users as $u)
            <tr>
                <td>
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">{{ substr($u->name,0,1) }}</div>
                        <p class="font-semibold {{ $u->id===auth()->id()?'text-blue-600':'' }}">{{ $u->name }} {{ $u->id===auth()->id()?'(Anda)':'' }}</p>
                    </div>
                </td>
                <td class="text-slate-500 text-sm">{{ $u->email }}</td>
                <td>
                    @foreach($u->roles as $role)
                    <span class="badge {{ ['admin'=>'badge-red','dokter'=>'badge-blue','apoteker'=>'badge-green','kasir'=>'badge-yellow'][$role->name]??'badge-gray' }}">{{ ucfirst($role->name) }}</span>
                    @endforeach
                </td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ $u->created_at->format('d/m/Y') }}</td>
                <td>
                    <div class="flex gap-1">
                        <a href="{{ route('users.edit',$u) }}" class="act-btn">✏️</a>
                        @if($u->id!==auth()->id())
                        <form method="POST" action="{{ route('users.destroy',$u) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn" onclick="return confirm('Hapus user {{ $u->name }}?')">🗑️</button>
                        </form>
                        @endif
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="5" class="text-center py-10 text-slate-400">Belum ada user</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($users->hasPages())<div class="px-6 py-4 border-t">{{ $users->links() }}</div>@endif
</div>
<style>.act-btn{@apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer;}</style>
@endsection
