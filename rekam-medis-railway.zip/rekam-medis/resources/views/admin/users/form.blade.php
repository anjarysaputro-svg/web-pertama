@extends('layouts.app')
@section('title', isset($user) ? '✏️ Edit User' : '➕ Tambah User')
@section('content')
<div class="max-w-xl mx-auto">
    <div class="card">
        <div class="card-header">
            <h3 class="font-bold">{{ isset($user)?'Edit User':'Tambah User Baru' }}</h3>
            <a href="{{ route('users.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ isset($user)?route('users.update',$user):route('users.store') }}">
                @csrf @if(isset($user)) @method('PUT') @endif
                <div class="space-y-4">
                    <div>
                        <label class="form-label">Nama Lengkap *</label>
                        <input type="text" name="name" value="{{ old('name',$user->name??'') }}" class="form-input" required>
                        @error('name')<p class="form-error">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" value="{{ old('email',$user->email??'') }}" class="form-input" required>
                        @error('email')<p class="form-error">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Role *</label>
                        <select name="role" class="form-select" required>
                            @foreach($roles as $r)
                            <option value="{{ $r->name }}" {{ old('role',isset($user)?$user->getRoleNames()->first():'')== $r->name?'selected':'' }}>{{ ucfirst($r->name) }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Password {{ isset($user)?'(Kosongkan jika tidak diubah)':'' }} *</label>
                        <input type="password" name="password" class="form-input" {{ isset($user)?'':'required' }} minlength="8">
                        @error('password')<p class="form-error">{{ $message }}</p>@enderror
                    </div>
                    @if(!isset($user))
                    <div>
                        <label class="form-label">Konfirmasi Password *</label>
                        <input type="password" name="password_confirmation" class="form-input" required>
                    </div>
                    @endif
                </div>
                <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                    <button type="submit" class="btn btn-primary">💾 {{ isset($user)?'Update User':'Simpan User' }}</button>
                    <a href="{{ route('users.index') }}" class="btn btn-outline">Batal</a>
                </div>
            </form>
        </div>
    </div>

    <div class="mt-4 bg-blue-50 border border-blue-200 rounded-xl p-4 text-sm text-blue-700">
        <p class="font-bold mb-2">ℹ️ Panduan Role:</p>
        <ul class="space-y-1">
            <li>🔴 <strong>Admin</strong> — Akses penuh ke semua fitur</li>
            <li>🔵 <strong>Dokter</strong> — Rekam medis, MCU, resep, tindakan</li>
            <li>🟢 <strong>Apoteker</strong> — Data obat, resep</li>
            <li>🟡 <strong>Kasir</strong> — Billing & pembayaran</li>
        </ul>
    </div>
</div>
@endsection
