{{-- resources/views/notifikasi/index.blade.php --}}
@extends('layouts.app')
@section('title','🔔 Notifikasi')
@section('content')
<div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
    {{-- Email --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold">📧 Kirim Notifikasi Email</h3></div>
        <div class="card-body">
            <form method="POST" action="{{ route('notifikasi.email') }}">
                @csrf
                <div class="space-y-4">
                    <div><label class="form-label">Pilih Pasien *</label>
                        <select name="pasien_id" class="form-select" required>
                            <option value="">-- Pilih Pasien --</option>
                            @foreach($pasiens as $p)
                            <option value="{{ $p->id }}">{{ $p->nama }} {{ $p->email?'('.$p->email.')':'(no email)' }}</option>
                            @endforeach
                        </select></div>
                    <div><label class="form-label">Hasil MCU *</label>
                        <select name="mcu_id" class="form-select" required>
                            <option value="">-- Pilih MCU --</option>
                            @foreach($mcus as $m)
                            <option value="{{ $m->id }}">{{ $m->pasien->nama??'-' }} – {{ $m->no_mcu }} ({{ $m->tgl->format('d/m/Y') }})</option>
                            @endforeach
                        </select></div>
                    <div class="bg-blue-50 rounded-xl p-3 text-sm text-blue-700">
                        <p class="font-semibold mb-1">📌 Template email otomatis berisi:</p>
                        <ul class="list-disc list-inside text-xs space-y-1 text-blue-600">
                            <li>Informasi hasil MCU</li><li>Kategori & tingkat risiko</li>
                            <li>Kesimpulan & rekomendasi</li><li>Link lihat hasil lengkap</li>
                        </ul>
                    </div>
                    <button type="submit" class="btn btn-primary w-full">📧 Kirim Email Sekarang</button>
                </div>
            </form>
        </div>
    </div>

    {{-- WhatsApp --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold">💬 Kirim WhatsApp</h3></div>
        <div class="card-body">
            <form method="POST" action="{{ route('notifikasi.wa') }}">
                @csrf
                <div class="space-y-4">
                    <div><label class="form-label">Pilih Pasien *</label>
                        <select name="pasien_id" class="form-select" required>
                            <option value="">-- Pilih Pasien --</option>
                            @foreach($pasiens as $p)
                            <option value="{{ $p->id }}">{{ $p->nama }} {{ $p->no_hp?'('.$p->no_hp.')':'(no HP)' }}</option>
                            @endforeach
                        </select></div>
                    <div><label class="form-label">Pesan WhatsApp *</label>
                        <textarea name="pesan" class="form-textarea" rows="6" required placeholder="Ketik pesan WhatsApp...">*APOTEK SEJAHTERA* 🏥

Halo [Nama Pasien],

Hasil MCU Anda sudah tersedia. Silakan hubungi kami untuk konsultasi lebih lanjut.

_Terima kasih_ 🙏</textarea></div>
                    <div class="bg-green-50 rounded-xl p-3 text-xs text-green-700">
                        <p class="font-semibold">⚙️ Menggunakan Fonnte API</p>
                        <p class="mt-1">Pastikan token Fonnte sudah dikonfigurasi di file .env (FONNTE_TOKEN)</p>
                    </div>
                    <button type="submit" class="btn btn-success w-full">💬 Kirim WhatsApp</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
