@extends('layouts.app')
@section('title', '💰 Detail Tagihan')
@section('content')
<div class="max-w-2xl mx-auto">
    <div class="mb-4 flex justify-between">
        <a href="{{ route('billing.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
        <a href="{{ route('billing.invoice',$billing) }}" target="_blank" class="btn btn-primary btn-sm">🖨️ Cetak Invoice</a>
    </div>
    <div class="card">
        <div class="p-6 bg-gradient-to-r from-blue-700 to-cyan-600 rounded-t-2xl">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-blue-200 text-xs font-bold uppercase tracking-widest">No. Tagihan</p>
                    <p class="text-white text-xl font-black mt-1">{{ $billing->no_tagihan }}</p>
                    <p class="text-blue-200 text-sm mt-2">{{ $billing->pasien->nama??'-' }} · {{ $billing->tgl?->format('d M Y') }}</p>
                </div>
                <span class="px-4 py-2 rounded-xl text-sm font-bold {{ $billing->status=='Lunas'?'bg-green-500 text-white':($billing->status=='Cicilan'?'bg-yellow-400 text-slate-800':'bg-red-500 text-white') }}">
                    {{ $billing->status }}
                </span>
            </div>
        </div>
        <div class="p-6 space-y-4">
            <div class="grid grid-cols-2 gap-4">
                <div class="bg-gray-50 rounded-xl p-4">
                    <p class="text-xs text-slate-400 font-semibold">Layanan</p>
                    <p class="font-bold text-slate-800 mt-1">{{ $billing->layanan }}</p>
                </div>
                <div class="bg-gray-50 rounded-xl p-4">
                    <p class="text-xs text-slate-400 font-semibold">Metode Bayar</p>
                    <p class="font-bold text-slate-800 mt-1">{{ $billing->metode }}</p>
                </div>
            </div>
            <div class="border border-gray-100 rounded-xl overflow-hidden">
                <div class="flex justify-between p-4 border-b border-gray-100">
                    <span class="text-slate-500">Total Tagihan</span>
                    <span class="font-bold text-slate-800">Rp {{ number_format($billing->total,0,',','.') }}</span>
                </div>
                <div class="flex justify-between p-4 border-b border-gray-100">
                    <span class="text-slate-500">Sudah Dibayar</span>
                    <span class="font-bold text-green-600">Rp {{ number_format($billing->bayar,0,',','.') }}</span>
                </div>
                <div class="flex justify-between p-4 bg-slate-50">
                    <span class="font-bold text-slate-700">Sisa Tagihan</span>
                    <span class="font-black text-xl {{ $billing->sisa > 0 ? 'text-red-600' : 'text-green-600' }}">
                        Rp {{ number_format($billing->sisa,0,',','.') }}
                    </span>
                </div>
            </div>
            @if($billing->catatan)
            <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <p class="text-xs font-bold text-yellow-700 mb-1">Catatan:</p>
                <p class="text-sm text-yellow-800">{{ $billing->catatan }}</p>
            </div>
            @endif
            <div class="flex gap-3 pt-2">
                <a href="{{ route('billing.edit',$billing) }}" class="btn btn-outline flex-1 justify-center">✏️ Edit Tagihan</a>
                <a href="{{ route('billing.invoice',$billing) }}" target="_blank" class="btn btn-primary flex-1 justify-center">🖨️ Print Invoice</a>
            </div>
        </div>
    </div>
</div>
@endsection
