@extends('layouts.app')
@section('title', isset($billing) ? '✏️ Edit Tagihan' : '➕ Buat Tagihan')
@section('content')
<div class="max-w-2xl mx-auto">
<div class="card">
    <div class="card-header"><h3 class="font-bold">{{ isset($billing)?'Edit Tagihan':'Buat Tagihan Baru' }}</h3>
        <a href="{{ route('billing.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ isset($billing)?route('billing.update',$billing):route('billing.store') }}">
            @csrf @if(isset($billing)) @method('PUT') @endif
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div><label class="form-label">Pasien *</label>
                    <select name="pasien_id" class="form-select" required>
                        <option value="">-- Pilih Pasien --</option>
                        @foreach($pasiens as $p)<option value="{{ $p->id }}" {{ old('pasien_id',$billing->pasien_id??'')==$p->id?'selected':'' }}>{{ $p->nama }}</option>@endforeach
                    </select></div>
                <div><label class="form-label">Tanggal *</label>
                    <input type="date" name="tgl" value="{{ old('tgl',$billing->tgl?->format('Y-m-d')??date('Y-m-d')) }}" class="form-input" required></div>
                <div class="sm:col-span-2"><label class="form-label">Layanan *</label>
                    <select name="layanan" class="form-select" required>
                        @foreach(['Konsultasi Umum','Konsultasi Spesialis','Tindakan Medis','Obat & Resep','Paket Pemeriksaan MCU','Rawat Inap','Laboratorium'] as $l)
                        <option value="{{ $l }}" {{ old('layanan',$billing->layanan??'')====$l?'selected':'' }}>{{ $l }}</option>@endforeach
                    </select></div>
                <div><label class="form-label">Total Tagihan (Rp) *</label>
                    <input type="number" name="total" value="{{ old('total',$billing->total??0) }}" class="form-input" min="0" required></div>
                <div><label class="form-label">Dibayar (Rp) *</label>
                    <input type="number" name="bayar" value="{{ old('bayar',$billing->bayar??0) }}" class="form-input" min="0" required></div>
                <div><label class="form-label">Metode Bayar *</label>
                    <select name="metode" class="form-select" required>
                        @foreach(['Tunai','Transfer Bank','BPJS','Kartu Debit','Kartu Kredit','QRIS'] as $m)
                        <option value="{{ $m }}" {{ old('metode',$billing->metode??'')====$m?'selected':'' }}>{{ $m }}</option>@endforeach
                    </select></div>
                <div><label class="form-label">Catatan</label>
                    <input type="text" name="catatan" value="{{ old('catatan',$billing->catatan??'') }}" class="form-input" placeholder="Catatan tambahan"></div>
            </div>
            <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                <button type="submit" class="btn btn-primary">💾 {{ isset($billing)?'Update':'Simpan' }} Tagihan</button>
                <a href="{{ route('billing.index') }}" class="btn btn-outline">Batal</a>
            </div>
        </form>
    </div>
</div>
</div>
@endsection
