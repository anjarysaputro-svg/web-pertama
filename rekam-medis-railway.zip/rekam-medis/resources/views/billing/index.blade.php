{{-- resources/views/billing/index.blade.php --}}
@extends('layouts.app')
@section('title','💰 Billing Pasien')
@section('content')
<div class="flex flex-col sm:flex-row gap-3 justify-between mb-5">
    <form class="flex flex-wrap gap-2">
        <div class="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 py-2 shadow-sm">
            <svg class="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            <input name="search" value="{{ request('search') }}" placeholder="Cari pasien..." class="outline-none text-sm w-40">
        </div>
        <select name="status" onchange="this.form.submit()" class="form-select w-auto text-sm">
            <option value="">Semua Status</option>
            @foreach(['Belum Bayar','Cicilan','Lunas'] as $s)
            <option value="{{ $s }}" {{ request('status')===$s?'selected':'' }}>{{ $s }}</option>
            @endforeach
        </select>
    </form>
    <a href="{{ route('billing.create') }}" class="btn btn-primary">➕ Buat Tagihan</a>
</div>
<div class="card">
    <div class="card-header"><h3 class="font-bold">Tagihan Pasien</h3>
        <div class="flex gap-2 flex-wrap text-xs">
            <span class="badge badge-red">Belum Bayar: {{ \App\Models\Billing::where('status','Belum Bayar')->count() }}</span>
            <span class="badge badge-yellow">Cicilan: {{ \App\Models\Billing::where('status','Cicilan')->count() }}</span>
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr><th>No. Tagihan</th><th>Pasien</th><th>Layanan</th><th>Total</th><th class="hidden md:table-cell">Dibayar</th><th class="hidden md:table-cell">Sisa</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            @forelse($billings as $b)
            <tr>
                <td><span class="font-mono text-xs bg-yellow-50 text-yellow-700 px-2 py-1 rounded-lg">{{ $b->no_tagihan }}</span></td>
                <td class="font-semibold">{{ $b->pasien->nama??'-' }}</td>
                <td class="text-slate-500 text-sm">{{ $b->layanan }}</td>
                <td class="font-semibold">Rp {{ number_format($b->total,0,',','.') }}</td>
                <td class="hidden md:table-cell text-green-600">Rp {{ number_format($b->bayar,0,',','.') }}</td>
                <td class="hidden md:table-cell {{ $b->sisa>0?'text-red-600':'text-green-600' }}">Rp {{ number_format($b->sisa,0,',','.') }}</td>
                <td><x-status-badge :status="$b->status_pembayaran"/></td>
                <td>
                    <div class="flex gap-1">
                        <a href="{{ route('billing.invoice',$b) }}" target="_blank" class="act-btn" title="Invoice">🖨️</a>
                        <a href="{{ route('billing.edit',$b) }}" class="act-btn">✏️</a>
                        <form method="POST" action="{{ route('billing.destroy',$b) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn" onclick="return confirm('Hapus tagihan?')">🗑️</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <x-table-empty icon="💰" message="Belum ada tagihan" :colspan="8" create-route="billing.create"/>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($billings->hasPages())<div class="px-6 py-4 border-t border-gray-100">{{ $billings->withQueryString()->links() }}</div>@endif
</div>
<style>.act-btn{@apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer;}</style>
@endsection
