@extends('layouts.app')
@section('title','📊 Laporan')
@section('content')
{{-- Filter --}}
<div class="flex flex-wrap gap-3 mb-5">
    <form class="flex flex-wrap gap-2 items-center">
        <select name="bulan" class="form-select w-auto">
            @foreach(range(1,12) as $b)
            <option value="{{ $b }}" {{ $bulan==$b?'selected':'' }}>{{ \Carbon\Carbon::create(null,$b)->isoFormat('MMMM') }}</option>
            @endforeach
        </select>
        <select name="tahun" class="form-select w-auto">
            @foreach(range(date('Y')-2,date('Y')+1) as $y)
            <option value="{{ $y }}" {{ $tahun==$y?'selected':'' }}>{{ $y }}</option>
            @endforeach
        </select>
        <button type="submit" class="btn btn-primary btn-sm">🔍 Filter</button>
    </form>
    <a href="{{ route('laporan.excel',['tahun'=>$tahun]) }}" class="btn btn-success btn-sm">📥 Export Excel</a>
    <a href="{{ route('laporan.pdf',['bulan'=>$bulan,'tahun'=>$tahun]) }}" target="_blank" class="btn btn-outline btn-sm">🖨️ Cetak PDF</a>
</div>

{{-- Stat Cards --}}
<div class="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-5">
    <div class="stat-card"><div class="stat-icon bg-blue-100">👥</div>
        <div><p class="text-2xl font-black text-blue-700">{{ $data['pasien_baru'] }}</p><p class="text-xs text-slate-500 font-medium">Pasien Baru</p></div></div>
    <div class="stat-card"><div class="stat-icon bg-green-100">📋</div>
        <div><p class="text-2xl font-black text-green-700">{{ $data['total_kunjungan'] }}</p><p class="text-xs text-slate-500 font-medium">Total Kunjungan</p></div></div>
    <div class="stat-card"><div class="stat-icon bg-purple-100">🧪</div>
        <div><p class="text-2xl font-black text-purple-700">{{ $data['total_mcu'] }}</p><p class="text-xs text-slate-500 font-medium">MCU Dilakukan</p></div></div>
    <div class="stat-card"><div class="stat-icon bg-emerald-100">💰</div>
        <div><p class="text-xl font-black text-emerald-700">Rp {{ number_format($data['pendapatan'],0,',','.') }}</p><p class="text-xs text-slate-500 font-medium">Pendapatan</p></div></div>
    <div class="stat-card"><div class="stat-icon bg-red-100">⚠️</div>
        <div><p class="text-2xl font-black text-red-700">Rp {{ number_format($data['tagihan_belum'],0,',','.') }}</p><p class="text-xs text-slate-500 font-medium">Tagihan Belum Bayar</p></div></div>
    <div class="stat-card"><div class="stat-icon bg-yellow-100">💊</div>
        <div><p class="text-2xl font-black text-yellow-700">{{ $data['obat_kritis'] }}</p><p class="text-xs text-slate-500 font-medium">Obat Stok Kritis</p></div></div>
</div>

{{-- Tabel Bulanan --}}
<div class="card">
    <div class="card-header"><h3 class="font-bold">📅 Rekap Bulanan Tahun {{ $tahun }}</h3></div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr><th>Bulan</th><th>Pasien Baru</th><th>Kunjungan</th><th>MCU</th><th>Pendapatan</th></tr></thead>
            <tbody>
            @foreach($bulanan as $row)
            <tr>
                <td class="font-semibold">{{ $row['bulan'] }}</td>
                <td>{{ $row['pasien_baru'] }}</td>
                <td>{{ $row['kunjungan'] }}</td>
                <td>{{ $row['mcu'] }}</td>
                <td class="font-medium text-green-700">Rp {{ number_format($row['pendapatan'],0,',','.') }}</td>
            </tr>
            @endforeach
            </tbody>
            <tfoot><tr class="bg-blue-50 font-bold">
                <td>TOTAL</td>
                <td>{{ $bulanan->sum('pasien_baru') }}</td>
                <td>{{ $bulanan->sum('kunjungan') }}</td>
                <td>{{ $bulanan->sum('mcu') }}</td>
                <td class="text-green-700">Rp {{ number_format($bulanan->sum('pendapatan'),0,',','.') }}</td>
            </tr></tfoot>
        </table>
    </div>
</div>
@endsection
