@extends('layouts.auth')
@section('title', 'Login')

@section('content')
<div class="text-center mb-6">
    <h2 class="text-white text-lg font-bold uppercase tracking-widest">— Area Login —</h2>
</div>

<form method="POST" action="{{ route('login') }}" class="space-y-5">
    @csrf

    {{-- Username / Email --}}
    <div>
        <label class="block text-white/75 text-xs font-bold uppercase tracking-wider mb-2">👤 Username / Email</label>
        <input type="email" name="email" value="{{ old('email') }}" required autofocus
               placeholder="Masukkan email"
               class="w-full bg-white/15 border border-white/25 text-white placeholder-white/40 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-white/60 focus:bg-white/20 transition">
        @error('email')
        <p class="text-red-300 text-xs mt-1">{{ $message }}</p>
        @enderror
    </div>

    {{-- Password --}}
    <div x-data="{ show: false }">
        <label class="block text-white/75 text-xs font-bold uppercase tracking-wider mb-2">🔑 Password</label>
        <div class="relative">
            <input :type="show ? 'text' : 'password'" name="password" required
                   placeholder="Masukkan password"
                   class="w-full bg-white/15 border border-white/25 text-white placeholder-white/40 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-white/60 focus:bg-white/20 transition pr-12">
            <button type="button" @click="show=!show" class="absolute right-3 top-3 text-white/50 hover:text-white">
                <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path x-show="!show" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                    <path x-show="show" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
                </svg>
            </button>
        </div>
        @error('password')
        <p class="text-red-300 text-xs mt-1">{{ $message }}</p>
        @enderror
    </div>

    {{-- Remember me --}}
    <div class="flex items-center gap-2">
        <input type="checkbox" name="remember" id="remember" class="rounded border-white/30 bg-white/10 text-blue-500">
        <label for="remember" class="text-white/70 text-sm">Ingat saya</label>
    </div>

    {{-- Submit --}}
    <button type="submit"
            class="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5 flex items-center justify-center gap-2">
        <span>➜</span> MASUK
    </button>

    {{-- Demo hint --}}
    <div class="bg-white/8 border border-white/15 rounded-xl p-4">
        <p class="text-white/60 text-xs leading-relaxed">
            <span class="text-white/90 font-bold">Demo Akun Admin:</span><br>
            Email: <span class="text-white font-semibold">admin@apotek.com</span><br>
            Password: <span class="text-white font-semibold">password</span>
        </p>
    </div>
</form>
@endsection
