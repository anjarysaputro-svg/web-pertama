{{-- resources/views/components/status-badge.blade.php --}}
@props(['status'])

@php
$map = [
    'Sembuh'           => 'badge-green',
    'Dalam Perawatan'  => 'badge-yellow',
    'Dirujuk'          => 'badge-red',
    'Selesai'          => 'badge-green',
    'Dalam Proses'     => 'badge-yellow',
    'Diberikan'        => 'badge-green',
    'Menunggu'         => 'badge-yellow',
    'Batal'            => 'badge-red',
    'Lunas'            => 'badge-green',
    'Cicilan'          => 'badge-yellow',
    'Belum Bayar'      => 'badge-red',
    'Aktif'            => 'badge-green',
    'Non-Aktif'        => 'badge-gray',
    'Rendah'           => 'badge-green',
    'Sedang'           => 'badge-yellow',
    'Tinggi'           => 'badge-red',
];
$class = $map[$status] ?? 'badge-gray';
@endphp

<span class="badge {{ $class }}">{{ $status }}</span>
