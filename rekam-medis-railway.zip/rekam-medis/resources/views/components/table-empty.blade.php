{{-- resources/views/components/table-empty.blade.php --}}
@props(['icon' => '📋', 'message' => 'Belum ada data', 'colspan' => 6, 'createRoute' => null, 'createLabel' => 'Tambah Data'])

<tr>
    <td colspan="{{ $colspan }}" class="text-center py-16 text-slate-400">
        <div class="text-5xl mb-3">{{ $icon }}</div>
        <p class="font-semibold text-slate-500 mb-1">{{ $message }}</p>
        <p class="text-sm mb-4">Klik tombol di atas untuk menambahkan data baru</p>
        @if($createRoute)
        <a href="{{ route($createRoute) }}" class="btn btn-primary inline-flex">➕ {{ $createLabel }}</a>
        @endif
    </td>
</tr>
