@extends('layouts.app')
@section('title', '👤 Detail Pasien')
@section('content')
<div class="mb-4 flex justify-between items-center">
    <a href="{{ route('pasien.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
    <div class="flex gap-2">
        <a href="{{ route('pasien.edit',$pasien) }}" class="btn btn-outline btn-sm">✏️ Edit</a>
        <a href="{{ route('rekam-medis.create') }}?pasien_id={{ $pasien->id }}" class="btn btn-primary btn-sm">➕ Rekam Medis</a>
    </div>
</div>

{{-- Patient Header --}}
<div class="card mb-6">
    <div class="p-6 bg-gradient-to-r from-blue-700 to-cyan-600 rounded-t-2xl">
        <div class="flex items-center gap-5">
            <div class="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center text-white text-3xl font-black flex-shrink-0">
                {{ substr($pasien->nama,0,1) }}
            </div>
            <div>
                <h2 class="text-white text-2xl font-bold">{{ $pasien->nama }}</h2>
                <p class="text-blue-100 text-sm mt-1">{{ $pasien->no_rm }} &nbsp;|&nbsp; {{ $pasien->jenis_kelamin }} &nbsp;|&nbsp; {{ $pasien->umur }} tahun &nbsp;|&nbsp; Gol. {{ $pasien->gol_darah??'-' }}</p>
            </div>
        </div>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-px bg-gray-100">
        @foreach([['📱 No. HP',$pasien->no_hp??'-'],['🏠 Alamat',Str::limit($pasien->alamat??'-',30)],['⚠️ Alergi',$pasien->alergi??'-'],['🦠 Riwayat',$pasien->riwayat_penyakit??'-']] as [$lbl,$val])
        <div class="bg-white p-4"><p class="text-xs text-slate-400 font-semibold">{{ $lbl }}</p><p class="text-sm font-semibold text-slate-700 mt-1">{{ $val }}</p></div>
        @endforeach
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    {{-- Rekam Medis --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold">📋 Riwayat Rekam Medis</h3></div>
        <div class="divide-y divide-gray-50">
            @forelse($pasien->rekamMedis->take(5) as $r)
            <div class="p-4 hover:bg-gray-50">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="font-semibold text-sm text-slate-800">{{ $r->diagnosis }}</p>
                        <p class="text-xs text-slate-400 mt-0.5">{{ $r->tgl_kunjungan?->format('d M Y') }} — {{ $r->dokter->nama??'-' }}</p>
                    </div>
                    @if($r->status=='Sembuh') <span class="badge badge-green text-xs">{{ $r->status }}</span>
                    @elseif($r->status=='Dalam Perawatan') <span class="badge badge-yellow text-xs">{{ $r->status }}</span>
                    @else <span class="badge badge-red text-xs">{{ $r->status }}</span>
                    @endif
                </div>
            </div>
            @empty
            <p class="p-6 text-center text-slate-400 text-sm">Belum ada rekam medis</p>
            @endforelse
        </div>
    </div>

    {{-- MCU & Billing --}}
    <div class="space-y-6">
        <div class="card">
            <div class="card-header"><h3 class="font-bold">🧪 Hasil MCU</h3></div>
            <div class="divide-y divide-gray-50">
                @forelse($pasien->hasilMcus->take(3) as $m)
                <div class="p-4 flex justify-between items-center">
                    <div>
                        <p class="font-semibold text-sm">{{ $m->jenis }}</p>
                        <p class="text-xs text-slate-400">{{ $m->tgl?->format('d M Y') }}</p>
                    </div>
                    <div class="text-right">
                        <span class="badge {{ $m->risiko=='Rendah'?'badge-green':($m->risiko=='Sedang'?'badge-yellow':'badge-red') }} text-xs">Risiko {{ $m->risiko }}</span>
                        <a href="{{ route('mcu.show',$m) }}" class="block text-xs text-blue-600 hover:underline mt-1">Lihat detail →</a>
                    </div>
                </div>
                @empty
                <p class="p-6 text-center text-slate-400 text-sm">Belum ada data MCU</p>
                @endforelse
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3 class="font-bold">💰 Riwayat Tagihan</h3></div>
            <div class="divide-y divide-gray-50">
                @forelse($pasien->billings->take(3) as $b)
                <div class="p-4 flex justify-between items-center">
                    <div>
                        <p class="font-semibold text-sm">{{ $b->layanan }}</p>
                        <p class="text-xs text-slate-400">{{ $b->tgl?->format('d M Y') }}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm font-bold text-slate-800">Rp {{ number_format($b->total,0,',','.') }}</p>
                        <span class="badge {{ $b->status_pembayaran=='Lunas'?'badge-green':($b->status_pembayaran=='Cicilan'?'badge-yellow':'badge-red') }} text-xs">{{ $b->status_pembayaran }}</span>
                    </div>
                </div>
                @empty
                <p class="p-6 text-center text-slate-400 text-sm">Belum ada tagihan</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
