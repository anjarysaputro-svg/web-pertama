@extends('layouts.app')
@section('title', isset($pasien) ? '✏️ Edit Pasien' : '➕ Tambah Pasien')

@section('content')
<div class="max-w-3xl mx-auto">
    <div class="card">
        <div class="card-header">
            <h3 class="font-bold">{{ isset($pasien) ? 'Edit Data Pasien' : 'Tambah Pasien Baru' }}</h3>
            <a href="{{ route('pasien.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ isset($pasien) ? route('pasien.update', $pasien) : route('pasien.store') }}" enctype="multipart/form-data">
                @csrf
                @if(isset($pasien)) @method('PUT') @endif

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div class="md:col-span-2">
                        <label class="form-label">Nama Lengkap *</label>
                        <input type="text" name="nama" value="{{ old('nama', $pasien->nama ?? '') }}" class="form-input" placeholder="Nama lengkap pasien" required>
                        @error('nama')<p class="form-error">{{ $message }}</p>@enderror
                    </div>

                    <div>
                        <label class="form-label">Tanggal Lahir *</label>
                        <input type="date" name="tgl_lahir" value="{{ old('tgl_lahir', isset($pasien) ? $pasien->tgl_lahir?->format('Y-m-d') : '') }}" class="form-input" required>
                        @error('tgl_lahir')<p class="form-error">{{ $message }}</p>@enderror
                    </div>

                    <div>
                        <label class="form-label">Jenis Kelamin *</label>
                        <select name="jenis_kelamin" class="form-select" required>
                            <option value="">-- Pilih --</option>
                            <option value="Laki-laki" {{ old('jenis_kelamin', $pasien->jenis_kelamin ?? '') === 'Laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                            <option value="Perempuan" {{ old('jenis_kelamin', $pasien->jenis_kelamin ?? '') === 'Perempuan' ? 'selected' : '' }}>Perempuan</option>
                        </select>
                    </div>

                    <div>
                        <label class="form-label">Golongan Darah</label>
                        <select name="gol_darah" class="form-select">
                            @foreach(['A','B','AB','O'] as $g)
                            <option value="{{ $g }}" {{ old('gol_darah', $pasien->gol_darah ?? '') === $g ? 'selected' : '' }}>{{ $g }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="form-label">No. HP</label>
                        <input type="text" name="no_hp" value="{{ old('no_hp', $pasien->no_hp ?? '') }}" class="form-input" placeholder="08xx-xxxx-xxxx">
                    </div>

                    <div>
                        <label class="form-label">Email</label>
                        <input type="email" name="email" value="{{ old('email', $pasien->email ?? '') }}" class="form-input" placeholder="email@domain.com">
                    </div>

                    <div>
                        <label class="form-label">Pekerjaan</label>
                        <input type="text" name="pekerjaan" value="{{ old('pekerjaan', $pasien->pekerjaan ?? '') }}" class="form-input" placeholder="Pekerjaan">
                    </div>

                    <div class="md:col-span-2">
                        <label class="form-label">Alamat</label>
                        <textarea name="alamat" class="form-textarea" placeholder="Alamat lengkap...">{{ old('alamat', $pasien->alamat ?? '') }}</textarea>
                    </div>

                    <div>
                        <label class="form-label">Alergi Obat</label>
                        <input type="text" name="alergi" value="{{ old('alergi', $pasien->alergi ?? '') }}" class="form-input" placeholder="Alergi (jika ada)">
                    </div>

                    <div>
                        <label class="form-label">Riwayat Penyakit</label>
                        <input type="text" name="riwayat_penyakit" value="{{ old('riwayat_penyakit', $pasien->riwayat_penyakit ?? '') }}" class="form-input" placeholder="Penyakit bawaan">
                    </div>

                    <div class="md:col-span-2">
                        <label class="form-label">Foto Pasien</label>
                        <input type="file" name="foto" accept="image/*" class="form-input">
                        <p class="text-xs text-slate-400 mt-1">Format: JPG, PNG. Maks 2MB</p>
                    </div>
                </div>

                <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                    <button type="submit" class="btn btn-primary">
                        💾 {{ isset($pasien) ? 'Update Pasien' : 'Simpan Pasien' }}
                    </button>
                    <a href="{{ route('pasien.index') }}" class="btn btn-outline">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
