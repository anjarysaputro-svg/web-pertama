@extends('layouts.app')
@section('title', '👥 Data Pasien')

@section('content')
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
    <div>
        <p class="text-slate-500 text-sm">Total <strong>{{ $pasiens->total() }}</strong> pasien terdaftar</p>
    </div>
    <div class="flex flex-wrap gap-2">
        <form class="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 py-2 shadow-sm">
            <svg class="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari pasien..." class="text-sm outline-none w-40 lg:w-52">
        </form>
        @role('admin|dokter')
        <a href="{{ route('pasien.create') }}" class="btn btn-primary">➕ Tambah Pasien</a>
        @endrole
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="font-bold text-slate-700">Daftar Pasien</h3>
        @role('admin')
        <a href="{{ route('pasien.export') }}" class="btn btn-outline btn-sm">📥 Export Excel</a>
        @endrole
    </div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead>
                <tr>
                    <th>No. RM</th>
                    <th>Nama Pasien</th>
                    <th>Tgl Lahir</th>
                    <th class="hidden md:table-cell">JK</th>
                    <th class="hidden md:table-cell">Gol. Darah</th>
                    <th class="hidden lg:table-cell">No. HP</th>
                    <th class="hidden lg:table-cell">Alergi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            @forelse($pasiens as $p)
            <tr>
                <td><span class="font-mono text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-lg">{{ $p->no_rm }}</span></td>
                <td>
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                            {{ substr($p->nama, 0, 1) }}
                        </div>
                        <div>
                            <p class="font-semibold text-slate-800">{{ $p->nama }}</p>
                            <p class="text-xs text-slate-400 lg:hidden">{{ $p->no_hp }}</p>
                        </div>
                    </div>
                </td>
                <td class="text-slate-500 text-sm">{{ \Carbon\Carbon::parse($p->tgl_lahir)->format('d/m/Y') }}</td>
                <td class="hidden md:table-cell">
                    @if($p->jenis_kelamin === 'Laki-laki')
                        <span class="badge badge-blue">L</span>
                    @else
                        <span class="badge badge-red" style="background:#FCE4EC">P</span>
                    @endif
                </td>
                <td class="hidden md:table-cell"><span class="badge badge-gray">{{ $p->gol_darah }}</span></td>
                <td class="hidden lg:table-cell text-slate-500 text-sm">{{ $p->no_hp }}</td>
                <td class="hidden lg:table-cell text-slate-500 text-sm">{{ $p->alergi ?: '-' }}</td>
                <td>
                    <div class="flex items-center gap-1">
                        <a href="{{ route('pasien.show', $p) }}" class="act-btn" title="Detail">👁️</a>
                        @role('admin|dokter')
                        <a href="{{ route('pasien.edit', $p) }}" class="act-btn" title="Edit">✏️</a>
                        <form method="POST" action="{{ route('pasien.destroy', $p) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn text-red-500 hover:bg-red-50"
                                    onclick="return confirm('Hapus pasien {{ $p->nama }}?')" title="Hapus">🗑️</button>
                        </form>
                        @endrole
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="8" class="text-center py-12 text-slate-400">
                <p class="text-4xl mb-3">👥</p>
                <p class="font-semibold">Belum ada data pasien</p>
                <a href="{{ route('pasien.create') }}" class="btn btn-primary mt-3 inline-flex">➕ Tambah Pasien Pertama</a>
            </td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($pasiens->hasPages())
    <div class="px-6 py-4 border-t border-gray-100">
        {{ $pasiens->withQueryString()->links() }}
    </div>
    @endif
</div>

<style>
.act-btn { @apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer; }
</style>
@endsection
