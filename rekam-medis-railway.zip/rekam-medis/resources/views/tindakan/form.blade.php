@extends('layouts.app')
@section('title', isset($tindakan)?'✏️ Edit Tindakan':'➕ Tambah Tindakan')
@section('content')
<div class="max-w-2xl mx-auto"><div class="card">
    <div class="card-header"><h3 class="font-bold">{{ isset($tindakan)?'Edit':'Tambah' }} Tindakan Medis</h3>
        <a href="{{ route('tindakan.index') }}" class="btn btn-outline btn-sm">← Kembali</a></div>
    <div class="card-body">
        <form method="POST" action="{{ isset($tindakan)?route('tindakan.update',$tindakan):route('tindakan.store') }}">
            @csrf @if(isset($tindakan)) @method('PUT') @endif
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div><label class="form-label">Pasien *</label>
                    <select name="pasien_id" class="form-select" required>
                        <option value="">-- Pilih Pasien --</option>
                        @foreach($pasiens as $p)<option value="{{ $p->id }}" {{ old('pasien_id',$tindakan->pasien_id??'')==$p->id?'selected':'' }}>{{ $p->nama }}</option>@endforeach
                    </select></div>
                <div><label class="form-label">Dokter *</label>
                    <select name="dokter_id" class="form-select" required>
                        <option value="">-- Pilih Dokter --</option>
                        @foreach($dokters as $d)<option value="{{ $d->id }}" {{ old('dokter_id',$tindakan->dokter_id??'')==$d->id?'selected':'' }}>{{ $d->nama }}</option>@endforeach
                    </select></div>
                <div><label class="form-label">Jenis Tindakan *</label>
                    <select name="jenis" class="form-select" required>
                        @foreach(['Pemeriksaan Fisik','Injeksi','Pemasangan Infus','Nebulisasi','Hecting','Insisi Abses','Pemasangan Kateter','Tindakan Lainnya'] as $j)
                        <option value="{{ $j }}" {{ old('jenis',$tindakan->jenis??'')====$j?'selected':'' }}>{{ $j }}</option>@endforeach
                    </select></div>
                <div><label class="form-label">Tarif (Rp) *</label>
                    <input type="number" name="tarif" value="{{ old('tarif',$tindakan->tarif??0) }}" class="form-input" min="0" required></div>
                <div><label class="form-label">Tanggal *</label>
                    <input type="date" name="tgl" value="{{ old('tgl',$tindakan->tgl?->format('Y-m-d')??date('Y-m-d')) }}" class="form-input" required></div>
                <div><label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="Selesai" {{ old('status',$tindakan->status??'')=='Selesai'?'selected':'' }}>Selesai</option>
                        <option value="Dalam Proses" {{ old('status',$tindakan->status??'')=='Dalam Proses'?'selected':'' }}>Dalam Proses</option>
                    </select></div>
                <div class="sm:col-span-2"><label class="form-label">Catatan</label>
                    <textarea name="catatan" class="form-textarea" placeholder="Catatan tindakan...">{{ old('catatan',$tindakan->catatan??'') }}</textarea></div>
            </div>
            <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                <button type="submit" class="btn btn-primary">💾 {{ isset($tindakan)?'Update':'Simpan' }}</button>
                <a href="{{ route('tindakan.index') }}" class="btn btn-outline">Batal</a>
            </div>
        </form>
    </div>
</div></div>
@endsection
