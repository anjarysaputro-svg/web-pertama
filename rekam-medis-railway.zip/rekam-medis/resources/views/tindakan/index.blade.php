@extends('layouts.app')
@section('title','🔬 Tindakan Medis')
@section('content')
<div class="flex justify-between items-center mb-5">
    <p class="text-slate-500 text-sm">Total <strong>{{ $tindakans->total() }}</strong> tindakan</p>
    <a href="{{ route('tindakan.create') }}" class="btn btn-primary">➕ Tambah Tindakan</a>
</div>
<div class="card">
    <div class="card-header"><h3 class="font-bold">Data Tindakan Medis</h3></div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr><th>Kode</th><th>Pasien</th><th>Jenis Tindakan</th><th class="hidden md:table-cell">Dokter</th><th>Tarif</th><th class="hidden lg:table-cell">Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            @forelse($tindakans as $t)
            <tr>
                <td><span class="font-mono text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded-lg">{{ $t->kode }}</span></td>
                <td class="font-semibold">{{ $t->pasien->nama??'-' }}</td>
                <td>{{ $t->jenis }}</td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ $t->dokter->nama??'-' }}</td>
                <td class="font-medium">Rp {{ number_format($t->tarif,0,',','.') }}</td>
                <td class="hidden lg:table-cell text-slate-500 text-sm">{{ $t->tgl->format('d/m/Y') }}</td>
                <td><x-status-badge :status="$t->status"/></td>
                <td>
                    <div class="flex gap-1">
                        <a href="{{ route('tindakan.edit',$t) }}" class="act-btn">✏️</a>
                        <form method="POST" action="{{ route('tindakan.destroy',$t) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn" onclick="return confirm('Hapus tindakan?')">🗑️</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <x-table-empty icon="🔬" message="Belum ada tindakan" :colspan="8" create-route="tindakan.create"/>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($tindakans->hasPages())<div class="px-6 py-4 border-t border-gray-100">{{ $tindakans->withQueryString()->links() }}</div>@endif
</div>
<style>.act-btn{@apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer;}</style>
@endsection
