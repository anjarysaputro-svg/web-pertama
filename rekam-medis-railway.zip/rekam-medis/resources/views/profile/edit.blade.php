@extends('layouts.app')
@section('title', '👤 Profil Saya')
@section('content')
<div class="max-w-xl mx-auto">
    <div class="card">
        <div class="card-header"><h3 class="font-bold">Edit Profil</h3></div>
        <div class="card-body">
            <form method="POST" action="{{ route('profile.update') }}">
                @csrf @method('PATCH')
                <div class="space-y-4">
                    <div>
                        <label class="form-label">Nama *</label>
                        <input type="text" name="name" value="{{ old('name',$user->name) }}" class="form-input" required>
                        @error('name')<p class="form-error">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" value="{{ old('email',$user->email) }}" class="form-input" required>
                    </div>
                    <hr class="border-gray-100">
                    <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">Ganti Password (opsional)</p>
                    <div>
                        <label class="form-label">Password Baru</label>
                        <input type="password" name="password" class="form-input" minlength="8" placeholder="Minimal 8 karakter">
                    </div>
                    <div>
                        <label class="form-label">Konfirmasi Password</label>
                        <input type="password" name="password_confirmation" class="form-input">
                    </div>
                </div>
                <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                    <button type="submit" class="btn btn-primary">💾 Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
