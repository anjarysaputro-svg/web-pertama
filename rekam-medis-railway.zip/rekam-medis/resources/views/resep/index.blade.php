@extends('layouts.app')
@section('title','📝 Resep Dokter')
@section('content')
<div class="flex justify-between items-center mb-5">
    <p class="text-slate-500 text-sm">Total <strong>{{ $reseps->total() }}</strong> resep</p>
    <a href="{{ route('resep.create') }}" class="btn btn-primary">➕ Buat Resep</a>
</div>
<div class="card">
    <div class="card-header"><h3 class="font-bold">Daftar Resep</h3></div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr><th>No. Resep</th><th>Pasien</th><th>Obat</th><th>Dosis</th><th class="hidden md:table-cell">Aturan</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            @forelse($reseps as $r)
            <tr>
                <td><span class="font-mono text-xs bg-green-50 text-green-700 px-2 py-1 rounded-lg">{{ $r->no_resep }}</span></td>
                <td class="font-semibold">{{ $r->pasien->nama??'-' }}</td>
                <td>{{ $r->obat->nama??'-' }}</td>
                <td>{{ $r->dosis }}</td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ $r->aturan }}</td>
                <td><x-status-badge :status="$r->status"/></td>
                <td>
                    <form method="POST" action="{{ route('resep.destroy',$r) }}" class="inline">
                        @csrf @method('DELETE')
                        <button type="submit" class="act-btn" onclick="return confirm('Hapus resep?')">🗑️</button>
                    </form>
                </td>
            </tr>
            @empty
            <x-table-empty icon="📝" message="Belum ada resep" :colspan="7" create-route="resep.create"/>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($reseps->hasPages())<div class="px-6 py-4 border-t border-gray-100">{{ $reseps->withQueryString()->links() }}</div>@endif
</div>
<style>.act-btn{@apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer;}</style>
@endsection
