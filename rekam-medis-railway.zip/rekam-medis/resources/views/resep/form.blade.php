@extends('layouts.app')
@section('title','➕ Buat Resep')
@section('content')
<div class="max-w-2xl mx-auto">
<div class="card">
    <div class="card-header"><h3 class="font-bold">Buat Resep Baru</h3>
        <a href="{{ route('resep.index') }}" class="btn btn-outline btn-sm">← Kembali</a></div>
    <div class="card-body">
        <form method="POST" action="{{ route('resep.store') }}">
            @csrf
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div><label class="form-label">Pasien *</label>
                    <select name="pasien_id" class="form-select" required>
                        <option value="">-- Pilih Pasien --</option>
                        @foreach($pasiens as $p)<option value="{{ $p->id }}">{{ $p->nama }}</option>@endforeach
                    </select></div>
                <div><label class="form-label">Obat *</label>
                    <select name="obat_id" class="form-select" required>
                        <option value="">-- Pilih Obat --</option>
                        @foreach($obats as $o)
                        <option value="{{ $o->id }}" {{ $o->stok<=0?'disabled':'' }}>{{ $o->nama }} (Stok: {{ $o->stok }})</option>
                        @endforeach
                    </select></div>
                <div><label class="form-label">Jumlah *</label>
                    <input type="number" name="jumlah" class="form-input" min="1" required placeholder="Jumlah"></div>
                <div><label class="form-label">Dosis *</label>
                    <input type="text" name="dosis" class="form-input" required placeholder="3x1 tablet"></div>
                <div><label class="form-label">Aturan Pakai *</label>
                    <select name="aturan" class="form-select" required>
                        <option>Sesudah makan</option><option>Sebelum makan</option>
                        <option>Sebelum tidur</option><option>Bila perlu</option><option>Setiap 8 jam</option>
                    </select></div>
                <div><label class="form-label">Catatan</label>
                    <input type="text" name="catatan" class="form-input" placeholder="Catatan tambahan"></div>
            </div>
            <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                <button type="submit" class="btn btn-primary">💾 Simpan Resep</button>
                <a href="{{ route('resep.index') }}" class="btn btn-outline">Batal</a>
            </div>
        </form>
    </div>
</div>
</div>
@endsection
