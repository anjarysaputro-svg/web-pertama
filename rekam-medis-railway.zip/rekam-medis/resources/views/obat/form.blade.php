@extends('layouts.app')
@section('title', isset($obat) ? '✏️ Edit Obat' : '➕ Tambah Obat')

@section('content')
<div class="max-w-2xl mx-auto">
<div class="card">
    <div class="card-header">
        <h3 class="font-bold">{{ isset($obat) ? 'Edit Data Obat' : 'Tambah Obat Baru' }}</h3>
        <a href="{{ route('obat.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ isset($obat) ? route('obat.update',$obat) : route('obat.store') }}">
            @csrf @if(isset($obat)) @method('PUT') @endif
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div class="sm:col-span-2">
                    <label class="form-label">Nama Obat *</label>
                    <input type="text" name="nama" value="{{ old('nama',$obat->nama??'') }}" class="form-input" required placeholder="Nama obat lengkap">
                    @error('nama')<p class="form-error">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label class="form-label">Satuan *</label>
                    <select name="satuan" class="form-select" required>
                        @foreach(['Tablet','Kapsul','Sirup','Ampul','Botol','Sachet','Tube','Suppositoria'] as $s)
                        <option value="{{ $s }}" {{ old('satuan',$obat->satuan??'')====$s?'selected':'' }}>{{ $s }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="form-label">Kategori *</label>
                    <select name="kategori" class="form-select" required>
                        @foreach(['Antibiotik','Analgesik','Vitamin','Antihipertensi','Antidiabetes','Antasida','Bronkodilator','Antihistamin','Kortikosteroid','Lainnya'] as $k)
                        <option value="{{ $k }}" {{ old('kategori',$obat->kategori??'')====$k?'selected':'' }}>{{ $k }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="form-label">Stok Awal *</label>
                    <input type="number" name="stok" value="{{ old('stok',$obat->stok??0) }}" class="form-input" min="0" required>
                </div>
                <div>
                    <label class="form-label">Harga Jual (Rp) *</label>
                    <input type="number" name="harga" value="{{ old('harga',$obat->harga??0) }}" class="form-input" min="0" required>
                </div>
                <div>
                    <label class="form-label">Tanggal Expired</label>
                    <input type="date" name="expired" value="{{ old('expired',$obat->expired?->format('Y-m-d')??'') }}" class="form-input">
                </div>
                <div>
                    <label class="form-label">Keterangan</label>
                    <input type="text" name="keterangan" value="{{ old('keterangan',$obat->keterangan??'') }}" class="form-input" placeholder="Keterangan tambahan">
                </div>
            </div>
            <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                <button type="submit" class="btn btn-primary">💾 {{ isset($obat)?'Update':'Simpan' }} Obat</button>
                <a href="{{ route('obat.index') }}" class="btn btn-outline">Batal</a>
            </div>
        </form>
    </div>
</div>
</div>
@endsection
