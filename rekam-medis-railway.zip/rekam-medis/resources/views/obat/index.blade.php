@extends('layouts.app')
@section('title','💊 Data Obat')

@section('content')
<div class="flex flex-col sm:flex-row gap-3 justify-between mb-5">
    <form class="flex flex-wrap gap-2">
        <div class="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 py-2 shadow-sm">
            <svg class="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            <input name="search" value="{{ request('search') }}" placeholder="Cari obat..." class="outline-none text-sm w-36 lg:w-48">
        </div>
        <select name="kategori" onchange="this.form.submit()" class="form-select w-auto text-sm">
            <option value="">Semua Kategori</option>
            @foreach($kategoris as $k)
            <option value="{{ $k }}" {{ request('kategori')===$k?'selected':'' }}>{{ $k }}</option>
            @endforeach
        </select>
    </form>
    <a href="{{ route('obat.create') }}" class="btn btn-primary">➕ Tambah Obat</a>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="font-bold text-slate-700">Stok Obat (<span class="text-blue-600">{{ $obats->total() }}</span>)</h3>
        <div class="flex gap-2">
            <span class="badge badge-red">{{ \App\Models\Obat::where('stok','<=',10)->count() }} Kritis</span>
            <span class="badge badge-yellow">{{ \App\Models\Obat::whereBetween('stok',[11,30])->count() }} Rendah</span>
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr>
                <th>Kode</th><th>Nama Obat</th><th>Satuan</th>
                <th>Kategori</th><th>Stok</th>
                <th class="hidden md:table-cell">Harga</th>
                <th class="hidden lg:table-cell">Expired</th>
                <th>Aksi</th>
            </tr></thead>
            <tbody>
            @forelse($obats as $o)
            <tr>
                <td><span class="font-mono text-xs bg-gray-50 px-2 py-1 rounded-lg text-slate-500">{{ $o->kode }}</span></td>
                <td>
                    <p class="font-semibold text-slate-800">{{ $o->nama }}</p>
                    <p class="text-xs text-slate-400 md:hidden">Rp {{ number_format($o->harga,0,',','.') }}</p>
                </td>
                <td class="text-slate-500 text-sm">{{ $o->satuan }}</td>
                <td><span class="badge badge-blue">{{ $o->kategori }}</span></td>
                <td>
                    @if($o->stok <= 0)       <span class="badge badge-red font-bold">HABIS</span>
                    @elseif($o->stok <= 10)  <span class="badge badge-red">{{ $o->stok }}</span>
                    @elseif($o->stok <= 30)  <span class="badge badge-yellow">{{ $o->stok }}</span>
                    @else                    <span class="badge badge-green">{{ $o->stok }}</span>
                    @endif
                </td>
                <td class="hidden md:table-cell text-slate-600 font-medium">Rp {{ number_format($o->harga,0,',','.') }}</td>
                <td class="hidden lg:table-cell text-sm {{ $o->expired && $o->expired->isPast() ? 'text-red-600 font-bold' : 'text-slate-500' }}">
                    {{ $o->expired ? $o->expired->format('d/m/Y') : '-' }}
                    @if($o->expired && $o->expired->isPast()) <span class="text-xs">(EXPIRED!)</span> @endif
                </td>
                <td>
                    <div class="flex gap-1">
                        <a href="{{ route('obat.edit',$o) }}" class="act-btn">✏️</a>
                        <form method="POST" action="{{ route('obat.destroy',$o) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn" onclick="return confirm('Hapus obat {{ $o->nama }}?')">🗑️</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <x-table-empty icon="💊" message="Belum ada data obat" :colspan="8" create-route="obat.create" create-label="Tambah Obat"/>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($obats->hasPages())
    <div class="px-6 py-4 border-t border-gray-100">{{ $obats->withQueryString()->links() }}</div>
    @endif
</div>
<style>.act-btn{@apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer;}</style>
@endsection
