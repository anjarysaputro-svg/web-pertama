@extends('layouts.app')
@section('title', '🏠 Dashboard')

@section('content')

{{-- Stats Row --}}
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <div class="stat-card">
        <div class="stat-icon bg-blue-100">👥</div>
        <div>
            <p class="text-2xl lg:text-3xl font-black text-slate-800">{{ $stats['pasien'] }}</p>
            <p class="text-xs text-slate-500 font-medium mt-1">Total Pasien</p>
            <p class="text-xs text-green-600 font-semibold mt-1">↑ +{{ $stats['pasien_baru'] }} bulan ini</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-green-100">📋</div>
        <div>
            <p class="text-2xl lg:text-3xl font-black text-slate-800">{{ $stats['rekam_medis'] }}</p>
            <p class="text-xs text-slate-500 font-medium mt-1">Rekam Medis</p>
            <p class="text-xs text-yellow-600 font-semibold mt-1">{{ $stats['rekam_aktif'] }} dalam perawatan</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-yellow-100">💊</div>
        <div>
            <p class="text-2xl lg:text-3xl font-black text-slate-800">{{ $stats['obat'] }}</p>
            <p class="text-xs text-slate-500 font-medium mt-1">Jenis Obat</p>
            <p class="text-xs text-red-600 font-semibold mt-1">{{ $stats['obat_kritis'] }} stok kritis</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-purple-100">💰</div>
        <div>
            <p class="text-xl lg:text-2xl font-black text-slate-800">{{ number_format($stats['pendapatan_bulan'], 0, ',', '.') }}</p>
            <p class="text-xs text-slate-500 font-medium mt-1">Pendapatan Bulan Ini</p>
            <p class="text-xs text-green-600 font-semibold mt-1">Rp</p>
        </div>
    </div>
</div>

{{-- Charts Row --}}
<div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">

    {{-- Kunjungan Chart --}}
    <div class="lg:col-span-2 card">
        <div class="card-header">
            <h3 class="font-bold text-slate-700">📈 Kunjungan 7 Hari Terakhir</h3>
        </div>
        <div class="card-body">
            <canvas id="chartKunjungan" height="120"></canvas>
        </div>
    </div>

    {{-- Status Pasien --}}
    <div class="card">
        <div class="card-header">
            <h3 class="font-bold text-slate-700">🩺 Status Pasien</h3>
        </div>
        <div class="card-body flex flex-col items-center">
            <canvas id="chartStatus" width="180" height="180"></canvas>
            <div class="mt-4 space-y-2 w-full">
                <div class="flex items-center justify-between text-sm">
                    <span class="flex items-center gap-2"><span class="w-3 h-3 rounded-sm bg-green-500 inline-block"></span>Sembuh</span>
                    <span class="font-bold text-green-600">{{ $stats['sembuh'] }}</span>
                </div>
                <div class="flex items-center justify-between text-sm">
                    <span class="flex items-center gap-2"><span class="w-3 h-3 rounded-sm bg-yellow-500 inline-block"></span>Perawatan</span>
                    <span class="font-bold text-yellow-600">{{ $stats['rekam_aktif'] }}</span>
                </div>
                <div class="flex items-center justify-between text-sm">
                    <span class="flex items-center gap-2"><span class="w-3 h-3 rounded-sm bg-red-500 inline-block"></span>Dirujuk</span>
                    <span class="font-bold text-red-600">{{ $stats['dirujuk'] }}</span>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Bottom Row --}}
<div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

    {{-- Kunjungan Terbaru --}}
    <div class="lg:col-span-2 card">
        <div class="card-header">
            <h3 class="font-bold text-slate-700">🕐 Kunjungan Terbaru</h3>
            <a href="{{ route('rekam-medis.index') }}" class="btn btn-outline btn-sm">Lihat Semua</a>
        </div>
        <div class="overflow-x-auto">
            <table class="tbl">
                <thead><tr><th>Pasien</th><th>Diagnosis</th><th>Dokter</th><th>Status</th></tr></thead>
                <tbody>
                @forelse($kunjungan_terbaru as $k)
                <tr>
                    <td class="font-semibold">{{ $k->pasien->nama ?? '-' }}</td>
                    <td class="text-slate-500">{{ Str::limit($k->diagnosis, 30) }}</td>
                    <td class="text-slate-500 text-xs">{{ $k->dokter->nama ?? '-' }}</td>
                    <td>
                        @if($k->status === 'Sembuh') <span class="badge badge-green">{{ $k->status }}</span>
                        @elseif($k->status === 'Dalam Perawatan') <span class="badge badge-yellow">{{ $k->status }}</span>
                        @else <span class="badge badge-red">{{ $k->status }}</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr><td colspan="4" class="text-center text-slate-400 py-8">Belum ada data kunjungan</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Stok Obat Kritis --}}
    <div class="card">
        <div class="card-header">
            <h3 class="font-bold text-slate-700">⚠️ Stok Kritis</h3>
            <a href="{{ route('obat.index') }}" class="btn btn-outline btn-sm">Lihat</a>
        </div>
        <div class="p-4 space-y-3">
            @forelse($obat_kritis as $obat)
            <div class="flex items-center justify-between p-3 bg-red-50 rounded-xl border border-red-100">
                <div>
                    <p class="text-sm font-semibold text-slate-700">{{ $obat->nama }}</p>
                    <p class="text-xs text-slate-400">{{ $obat->kategori }}</p>
                </div>
                <span class="badge badge-red">{{ $obat->stok }} {{ $obat->satuan }}</span>
            </div>
            @empty
            <div class="text-center py-8 text-slate-400">
                <p class="text-2xl mb-2">✅</p>
                <p class="text-sm">Semua stok aman</p>
            </div>
            @endforelse
        </div>
    </div>

</div>

@endsection

@push('scripts')
<script>
// Chart Kunjungan
new Chart(document.getElementById('chartKunjungan'), {
    type: 'bar',
    data: {
        labels: {!! json_encode($chart_labels) !!},
        datasets: [{
            label: 'Kunjungan',
            data: {!! json_encode($chart_data) !!},
            backgroundColor: 'rgba(21,101,192,0.8)',
            borderRadius: 8,
            borderSkipped: false,
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { stepSize: 5 } },
            x: { grid: { display: false } }
        }
    }
});

// Chart Status
new Chart(document.getElementById('chartStatus'), {
    type: 'doughnut',
    data: {
        labels: ['Sembuh', 'Perawatan', 'Dirujuk'],
        datasets: [{
            data: [{{ $stats['sembuh'] }}, {{ $stats['rekam_aktif'] }}, {{ $stats['dirujuk'] }}],
            backgroundColor: ['#22c55e', '#f59e0b', '#ef4444'],
            borderWidth: 0,
        }]
    },
    options: {
        cutout: '70%',
        plugins: { legend: { display: false } }
    }
});
</script>
@endpush
