<!DOCTYPE html>
<html lang="id" x-data="{ sidebarOpen: false, mobileSidebarOpen: false }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name') }} — @yield('title', 'Dashboard')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @stack('styles')
</head>
<body class="bg-gray-100 font-sans">

{{-- ===== SIDEBAR DESKTOP ===== --}}
<aside class="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-slate-900 z-40">
    @include('layouts.partials.sidebar')
</aside>

{{-- ===== SIDEBAR MOBILE OVERLAY ===== --}}
<div x-show="mobileSidebarOpen" x-cloak class="fixed inset-0 z-50 lg:hidden">
    <div class="fixed inset-0 bg-black/60 backdrop-blur-sm" @click="mobileSidebarOpen=false"></div>
    <aside class="relative flex w-72 flex-col bg-slate-900 h-full shadow-2xl">
        <button @click="mobileSidebarOpen=false" class="absolute top-4 right-4 text-slate-400 hover:text-white">
            <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
        @include('layouts.partials.sidebar')
    </aside>
</div>

{{-- ===== MAIN CONTENT ===== --}}
<div class="lg:pl-64 flex flex-col min-h-screen">

    {{-- Topbar --}}
    <header class="sticky top-0 z-30 bg-white border-b border-gray-200 shadow-sm no-print">
        <div class="flex items-center justify-between px-4 py-3 lg:px-6">
            <div class="flex items-center gap-3">
                {{-- Hamburger mobile --}}
                <button @click="mobileSidebarOpen=true" class="lg:hidden p-2 rounded-xl text-slate-600 hover:bg-gray-100 transition">
                    <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
                </button>
                <div>
                    <h1 class="text-base lg:text-lg font-bold text-slate-800">@yield('title', 'Dashboard')</h1>
                    <p class="text-xs text-slate-400 hidden lg:block">{{ now()->isoFormat('dddd, D MMMM Y') }}</p>
                </div>
            </div>
            <div class="flex items-center gap-2 lg:gap-3">
                {{-- Notif bell --}}
                <button class="relative p-2 rounded-xl text-slate-500 hover:bg-gray-100 transition">
                    <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                </button>
                {{-- User dropdown --}}
                <div x-data="{ open: false }" class="relative">
                    <button @click="open=!open" class="flex items-center gap-2 p-1.5 rounded-xl hover:bg-gray-100 transition">
                        <div class="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">
                            {{ substr(auth()->user()->name ?? 'A', 0, 1) }}
                        </div>
                        <div class="hidden lg:block text-left">
                            <p class="text-sm font-semibold text-slate-700">{{ auth()->user()->name ?? 'Admin' }}</p>
                            <p class="text-xs text-slate-400">{{ auth()->user()->getRoleNames()->first() ?? 'Admin' }}</p>
                        </div>
                        <svg class="w-4 h-4 text-slate-400 hidden lg:block" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div x-show="open" @click.outside="open=false" x-cloak
                         class="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-lg border border-gray-100 py-2 z-50">
                        <a href="{{ route('profile.edit') }}" class="flex items-center gap-2 px-4 py-2 text-sm text-slate-600 hover:bg-gray-50">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                            Profil Saya
                        </a>
                        <hr class="my-1 border-gray-100">
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                                Logout
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </header>

    {{-- Flash Messages --}}
    @if(session('success'))
    <div id="flash-message" class="alert-success mx-4 mt-4 lg:mx-6 transition-opacity duration-500">
        ✅ {{ session('success') }}
    </div>
    @endif
    @if(session('error'))
    <div id="flash-message" class="alert-error mx-4 mt-4 lg:mx-6">
        ❌ {{ session('error') }}
    </div>
    @endif

    {{-- Page Content --}}
    <main class="flex-1 p-4 lg:p-6 pb-20 lg:pb-6">
        @yield('content')
    </main>

    {{-- ===== BOTTOM NAV MOBILE ===== --}}
    <nav class="lg:hidden fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-700 z-30 no-print">
        <div class="flex items-center overflow-x-auto scrollbar-none">
            @include('layouts.partials.bottom-nav')
        </div>
    </nav>

</div>

@stack('scripts')
</body>
</html>
