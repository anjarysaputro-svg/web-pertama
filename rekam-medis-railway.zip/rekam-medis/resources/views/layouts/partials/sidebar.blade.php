{{-- resources/views/layouts/partials/sidebar.blade.php --}}
<div class="flex flex-col h-full">

    {{-- Logo --}}
    <div class="px-5 py-5 border-b border-slate-700/50">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white text-xl font-bold flex-shrink-0 shadow-lg">
                ✚
            </div>
            <div>
                <h2 class="text-white font-bold text-sm leading-tight">Apotek Sejahtera</h2>
                <span class="text-slate-400 text-xs">Rekam Medis Digital</span>
            </div>
        </div>
    </div>

    {{-- Navigation --}}
    <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-0.5 scrollbar-none">

        <p class="px-3 py-2 text-slate-500 text-[10px] font-bold uppercase tracking-widest">Utama</p>
        <a href="{{ route('dashboard') }}" class="sb-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <span class="icon">🏠</span><span>Beranda</span>
        </a>

        <p class="px-3 py-2 mt-2 text-slate-500 text-[10px] font-bold uppercase tracking-widest">Master Data</p>
        <a href="{{ route('pasien.index') }}" class="sb-link {{ request()->routeIs('pasien.*') ? 'active' : '' }}">
            <span class="icon">👥</span><span>Data Pasien</span>
        </a>
        @role('admin')
        <a href="{{ route('dokter.index') }}" class="sb-link {{ request()->routeIs('dokter.*') ? 'active' : '' }}">
            <span class="icon">🩺</span><span>Data Dokter</span>
        </a>
        <a href="{{ route('poliklinik.index') }}" class="sb-link {{ request()->routeIs('poliklinik.*') ? 'active' : '' }}">
            <span class="icon">🏥</span><span>Poliklinik</span>
        </a>
        @endrole
        @role('admin|apoteker')
        <a href="{{ route('obat.index') }}" class="sb-link {{ request()->routeIs('obat.*') ? 'active' : '' }}">
            <span class="icon">💊</span><span>Data Obat</span>
        </a>
        @endrole

        <p class="px-3 py-2 mt-2 text-slate-500 text-[10px] font-bold uppercase tracking-widest">Pelayanan</p>
        @role('admin|dokter')
        <a href="{{ route('rekam-medis.index') }}" class="sb-link {{ request()->routeIs('rekam-medis.*') ? 'active' : '' }}">
            <span class="icon">📋</span><span>Rekam Medis</span>
            @php $pending = \App\Models\RekamMedis::where('status','Dalam Perawatan')->count(); @endphp
            @if($pending > 0)
            <span class="ml-auto bg-cyan-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full">{{ $pending }}</span>
            @endif
        </a>
        <a href="{{ route('mcu.index') }}" class="sb-link {{ request()->routeIs('mcu.*') ? 'active' : '' }}">
            <span class="icon">🧪</span><span>Hasil MCU</span>
        </a>
        @endrole
        @role('admin|dokter|apoteker')
        <a href="{{ route('resep.index') }}" class="sb-link {{ request()->routeIs('resep.*') ? 'active' : '' }}">
            <span class="icon">📝</span><span>Resep Dokter</span>
        </a>
        @endrole
        @role('admin|dokter')
        <a href="{{ route('tindakan.index') }}" class="sb-link {{ request()->routeIs('tindakan.*') ? 'active' : '' }}">
            <span class="icon">🔬</span><span>Tindakan Medis</span>
        </a>
        @endrole

        <p class="px-3 py-2 mt-2 text-slate-500 text-[10px] font-bold uppercase tracking-widest">Keuangan</p>
        @role('admin|kasir')
        <a href="{{ route('billing.index') }}" class="sb-link {{ request()->routeIs('billing.*') ? 'active' : '' }}">
            <span class="icon">💰</span><span>Billing Pasien</span>
        </a>
        @endrole
        @role('admin')
        <a href="{{ route('laporan.index') }}" class="sb-link {{ request()->routeIs('laporan.*') ? 'active' : '' }}">
            <span class="icon">📊</span><span>Laporan</span>
        </a>
        <a href="{{ route('notifikasi.index') }}" class="sb-link {{ request()->routeIs('notifikasi.*') ? 'active' : '' }}">
            <span class="icon">🔔</span><span>Notifikasi</span>
        </a>

        <p class="px-3 py-2 mt-2 text-slate-500 text-[10px] font-bold uppercase tracking-widest">Pengaturan</p>
        <a href="{{ route('users.index') }}" class="sb-link {{ request()->routeIs('users.*') ? 'active' : '' }}">
            <span class="icon">⚙️</span><span>Manajemen User</span>
        </a>
        @endrole
    </nav>

    {{-- User Info --}}
    <div class="px-4 py-4 border-t border-slate-700/50">
        <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                {{ substr(auth()->user()->name ?? 'A', 0, 1) }}
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-white text-sm font-semibold truncate">{{ auth()->user()->name ?? 'Admin' }}</p>
                <p class="text-slate-400 text-xs capitalize">{{ auth()->user()->getRoleNames()->first() ?? 'admin' }}</p>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-900/20 transition" title="Logout">
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7"/></svg>
                </button>
            </form>
        </div>
    </div>
</div>
