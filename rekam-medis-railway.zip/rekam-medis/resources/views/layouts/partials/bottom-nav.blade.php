{{-- resources/views/layouts/partials/bottom-nav.blade.php --}}
@php
$navItems = [
    ['route' => 'dashboard',      'icon' => '🏠', 'label' => 'Beranda'],
    ['route' => 'pasien.index',   'icon' => '👥', 'label' => 'Pasien'],
    ['route' => 'rekam-medis.index','icon'=> '📋', 'label' => 'Rekam'],
    ['route' => 'mcu.index',      'icon' => '🧪', 'label' => 'MCU'],
    ['route' => 'billing.index',  'icon' => '💰', 'label' => 'Billing'],
    ['route' => 'laporan.index',  'icon' => '📊', 'label' => 'Laporan'],
];
@endphp
@foreach($navItems as $item)
<a href="{{ route($item['route']) }}"
   class="flex flex-col items-center justify-center gap-1 px-3 py-2 min-w-[56px] flex-shrink-0 transition-all
          {{ request()->routeIs(rtrim($item['route'],'.*').'*') ? 'text-cyan-400' : 'text-slate-400 hover:text-white' }}">
    <span class="text-xl leading-none">{{ $item['icon'] }}</span>
    <span class="text-[9px] font-semibold">{{ $item['label'] }}</span>
</a>
@endforeach
