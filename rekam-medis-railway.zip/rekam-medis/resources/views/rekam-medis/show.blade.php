@extends('layouts.app')
@section('title','📋 Detail Rekam Medis')

@section('content')
<div class="max-w-4xl mx-auto space-y-5">
    {{-- Header --}}
    <div class="card overflow-hidden">
        <div class="bg-gradient-to-r from-blue-700 to-cyan-600 p-6 text-white">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <p class="text-blue-200 text-xs font-bold uppercase tracking-widest mb-1">Rekam Medis</p>
                    <h2 class="text-xl font-black">{{ $rekamMedis->pasien->nama }}</h2>
                    <p class="text-blue-100 text-sm mt-1">No. RM: {{ $rekamMedis->pasien->no_rm }} &nbsp;|&nbsp; No. Kunjungan: {{ $rekamMedis->no_rm_kunjungan }}</p>
                </div>
                <div class="flex gap-2 flex-wrap">
                    <x-status-badge :status="$rekamMedis->status"/>
                    <a href="{{ route('rekam-medis.edit',$rekamMedis) }}" class="btn btn-sm bg-white/20 text-white hover:bg-white/30 border-0">✏️ Edit</a>
                    <a href="{{ route('rekam-medis.index') }}" class="btn btn-sm bg-white/20 text-white hover:bg-white/30 border-0">← Kembali</a>
                </div>
            </div>
        </div>
        <div class="p-6 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div><p class="text-xs font-bold text-slate-400 uppercase mb-1">Dokter</p><p class="font-semibold text-sm">{{ $rekamMedis->dokter->nama??'-' }}</p></div>
            <div><p class="text-xs font-bold text-slate-400 uppercase mb-1">Poliklinik</p><p class="font-semibold text-sm">{{ $rekamMedis->poliklinik->nama??'-' }}</p></div>
            <div><p class="text-xs font-bold text-slate-400 uppercase mb-1">Tanggal</p><p class="font-semibold text-sm">{{ $rekamMedis->tgl_kunjungan->isoFormat('D MMMM Y') }}</p></div>
            <div><p class="text-xs font-bold text-slate-400 uppercase mb-1">Status</p><x-status-badge :status="$rekamMedis->status"/></div>
        </div>
    </div>

    {{-- Tanda Vital --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold">🩺 Tanda Vital</h3></div>
        <div class="p-5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            @foreach([['Tekanan Darah','tekanan_darah','mmHg'],['Nadi','nadi','x/mnt'],['Suhu','suhu','°C'],['Berat Badan','berat_badan','kg'],['Tinggi Badan','tinggi_badan','cm']] as [$label,$field,$unit])
            <div class="bg-blue-50 rounded-xl p-3 text-center">
                <p class="text-xs font-bold text-slate-500 uppercase mb-1">{{ $label }}</p>
                <p class="text-xl font-black text-blue-700">{{ $rekamMedis->$field??'–' }}</p>
                <p class="text-xs text-slate-400">{{ $unit }}</p>
            </div>
            @endforeach
        </div>
    </div>

    {{-- Diagnosis --}}
    <div class="card">
        <div class="card-header"><h3 class="font-bold">📋 Hasil Pemeriksaan</h3></div>
        <div class="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
            <div><p class="text-xs font-bold text-slate-400 uppercase mb-2">Keluhan</p><p class="text-sm leading-relaxed bg-gray-50 p-3 rounded-xl">{{ $rekamMedis->keluhan }}</p></div>
            <div><p class="text-xs font-bold text-slate-400 uppercase mb-2">Diagnosis</p><p class="text-sm leading-relaxed bg-gray-50 p-3 rounded-xl font-medium">{{ $rekamMedis->diagnosis }}</p></div>
            @if($rekamMedis->terapi)
            <div><p class="text-xs font-bold text-slate-400 uppercase mb-2">Terapi</p><p class="text-sm leading-relaxed bg-green-50 p-3 rounded-xl">{{ $rekamMedis->terapi }}</p></div>
            @endif
            @if($rekamMedis->catatan)
            <div><p class="text-xs font-bold text-slate-400 uppercase mb-2">Catatan Dokter</p><p class="text-sm leading-relaxed bg-yellow-50 p-3 rounded-xl">{{ $rekamMedis->catatan }}</p></div>
            @endif
        </div>
    </div>

    {{-- Resep --}}
    @if($rekamMedis->reseps->count())
    <div class="card">
        <div class="card-header"><h3 class="font-bold">📝 Resep Obat</h3></div>
        <div class="overflow-x-auto">
            <table class="tbl">
                <thead><tr><th>Obat</th><th>Jumlah</th><th>Dosis</th><th>Aturan</th><th>Status</th></tr></thead>
                <tbody>
                @foreach($rekamMedis->reseps as $r)
                <tr>
                    <td class="font-medium">{{ $r->obat->nama??'-' }}</td>
                    <td>{{ $r->jumlah }} {{ $r->obat->satuan??'' }}</td>
                    <td>{{ $r->dosis }}</td>
                    <td>{{ $r->aturan }}</td>
                    <td><x-status-badge :status="$r->status"/></td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
    @endif

    {{-- Tindakan --}}
    @if($rekamMedis->tindakans->count())
    <div class="card">
        <div class="card-header"><h3 class="font-bold">🔬 Tindakan Medis</h3></div>
        <div class="overflow-x-auto">
            <table class="tbl">
                <thead><tr><th>Jenis Tindakan</th><th>Dokter</th><th>Tarif</th><th>Status</th></tr></thead>
                <tbody>
                @foreach($rekamMedis->tindakans as $t)
                <tr>
                    <td class="font-medium">{{ $t->jenis }}</td>
                    <td>{{ $t->dokter->nama??'-' }}</td>
                    <td>Rp {{ number_format($t->tarif,0,',','.') }}</td>
                    <td><x-status-badge :status="$t->status"/></td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
    @endif
</div>
@endsection
