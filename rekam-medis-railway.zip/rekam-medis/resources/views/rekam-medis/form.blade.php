@extends('layouts.app')
@section('title', isset($rekamMedis) ? '✏️ Edit Rekam Medis' : '➕ Tambah Rekam Medis')

@section('content')
<div class="max-w-3xl mx-auto">
<div class="card">
    <div class="card-header">
        <h3 class="font-bold">{{ isset($rekamMedis) ? 'Edit Rekam Medis' : 'Tambah Rekam Medis Baru' }}</h3>
        <a href="{{ route('rekam-medis.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ isset($rekamMedis) ? route('rekam-medis.update',$rekamMedis) : route('rekam-medis.store') }}">
            @csrf @if(isset($rekamMedis)) @method('PUT') @endif

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                <div>
                    <label class="form-label">Pasien *</label>
                    <select name="pasien_id" class="form-select" required>
                        <option value="">-- Pilih Pasien --</option>
                        @foreach($pasiens as $p)
                        <option value="{{ $p->id }}" {{ old('pasien_id',$rekamMedis->pasien_id??'')==$p->id?'selected':'' }}>
                            {{ $p->nama }} ({{ $p->no_rm }})
                        </option>
                        @endforeach
                    </select>
                    @error('pasien_id')<p class="form-error">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label class="form-label">Poliklinik</label>
                    <select name="poliklinik_id" class="form-select">
                        <option value="">-- Pilih Poli --</option>
                        @foreach($polikliniks as $pl)
                        <option value="{{ $pl->id }}" {{ old('poliklinik_id',$rekamMedis->poliklinik_id??'')==$pl->id?'selected':'' }}>{{ $pl->nama }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="form-label">Dokter *</label>
                    <select name="dokter_id" class="form-select" required>
                        <option value="">-- Pilih Dokter --</option>
                        @foreach($dokters as $d)
                        <option value="{{ $d->id }}" {{ old('dokter_id',$rekamMedis->dokter_id??'')==$d->id?'selected':'' }}>{{ $d->nama }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="form-label">Tanggal Kunjungan *</label>
                    <input type="date" name="tgl_kunjungan" value="{{ old('tgl_kunjungan',$rekamMedis->tgl_kunjungan?->format('Y-m-d')??date('Y-m-d')) }}" class="form-input" required>
                </div>
            </div>

            {{-- Tanda Vital --}}
            <div class="bg-blue-50 rounded-2xl p-4 mb-5">
                <p class="text-sm font-bold text-blue-700 mb-3">🩺 Tanda Vital</p>
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                    <div><label class="form-label">Tekanan Darah</label><input type="text" name="tekanan_darah" value="{{ old('tekanan_darah',$rekamMedis->tekanan_darah??'') }}" class="form-input" placeholder="120/80"></div>
                    <div><label class="form-label">Nadi (x/mnt)</label><input type="number" name="nadi" value="{{ old('nadi',$rekamMedis->nadi??'') }}" class="form-input" placeholder="80"></div>
                    <div><label class="form-label">Suhu (°C)</label><input type="number" step="0.1" name="suhu" value="{{ old('suhu',$rekamMedis->suhu??'') }}" class="form-input" placeholder="36.5"></div>
                    <div><label class="form-label">Berat (kg)</label><input type="number" step="0.1" name="berat_badan" value="{{ old('berat_badan',$rekamMedis->berat_badan??'') }}" class="form-input" placeholder="60"></div>
                    <div><label class="form-label">Tinggi (cm)</label><input type="number" step="0.1" name="tinggi_badan" value="{{ old('tinggi_badan',$rekamMedis->tinggi_badan??'') }}" class="form-input" placeholder="160"></div>
                </div>
            </div>

            <div class="grid grid-cols-1 gap-5 mb-5">
                <div>
                    <label class="form-label">Keluhan Pasien *</label>
                    <textarea name="keluhan" class="form-textarea" required placeholder="Keluhan utama pasien...">{{ old('keluhan',$rekamMedis->keluhan??'') }}</textarea>
                </div>
                <div>
                    <label class="form-label">Diagnosis *</label>
                    <textarea name="diagnosis" class="form-textarea" required placeholder="Diagnosis dokter...">{{ old('diagnosis',$rekamMedis->diagnosis??'') }}</textarea>
                </div>
                <div>
                    <label class="form-label">Terapi / Tatalaksana</label>
                    <textarea name="terapi" class="form-textarea" placeholder="Terapi yang diberikan...">{{ old('terapi',$rekamMedis->terapi??'') }}</textarea>
                </div>
                <div>
                    <label class="form-label">Catatan Tambahan</label>
                    <textarea name="catatan" class="form-textarea" placeholder="Catatan dokter...">{{ old('catatan',$rekamMedis->catatan??'') }}</textarea>
                </div>
            </div>

            <div>
                <label class="form-label">Status *</label>
                <select name="status" class="form-select" required>
                    @foreach(['Dalam Perawatan','Sembuh','Dirujuk'] as $s)
                    <option value="{{ $s }}" {{ old('status',$rekamMedis->status??'Dalam Perawatan')===$s?'selected':'' }}>{{ $s }}</option>
                    @endforeach
                </select>
            </div>

            <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                <button type="submit" class="btn btn-primary">💾 {{ isset($rekamMedis)?'Update':'Simpan' }} Rekam Medis</button>
                <a href="{{ route('rekam-medis.index') }}" class="btn btn-outline">Batal</a>
            </div>
        </form>
    </div>
</div>
</div>
@endsection
