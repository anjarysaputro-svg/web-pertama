@extends('layouts.app')
@section('title','📋 Rekam Medis')

@section('content')
<div class="flex flex-col sm:flex-row gap-3 justify-between mb-5">
    <form class="flex flex-wrap gap-2">
        <div class="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 py-2 shadow-sm">
            <svg class="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            <input name="search" value="{{ request('search') }}" placeholder="Cari pasien / diagnosis..." class="outline-none text-sm w-40 lg:w-52">
        </div>
        <select name="status" onchange="this.form.submit()" class="form-select w-auto text-sm">
            <option value="">Semua Status</option>
            @foreach(['Dalam Perawatan','Sembuh','Dirujuk'] as $s)
            <option value="{{ $s }}" {{ request('status')===$s?'selected':'' }}>{{ $s }}</option>
            @endforeach
        </select>
    </form>
    <a href="{{ route('rekam-medis.create') }}" class="btn btn-primary">➕ Tambah Rekam Medis</a>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="font-bold text-slate-700">Data Rekam Medis (<span class="text-blue-600">{{ $rekams->total() }}</span>)</h3>
        <div class="flex gap-2 flex-wrap">
            <span class="badge badge-yellow">{{ \App\Models\RekamMedis::where('status','Dalam Perawatan')->count() }} Aktif</span>
            <span class="badge badge-green">{{ \App\Models\RekamMedis::where('status','Sembuh')->count() }} Sembuh</span>
        </div>
    </div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr>
                <th>No. Kunjungan</th><th>Pasien</th>
                <th class="hidden md:table-cell">Poliklinik</th>
                <th class="hidden md:table-cell">Dokter</th>
                <th>Diagnosis</th>
                <th class="hidden lg:table-cell">Tgl Periksa</th>
                <th>Status</th><th>Aksi</th>
            </tr></thead>
            <tbody>
            @forelse($rekams as $r)
            <tr>
                <td><span class="font-mono text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-lg">{{ $r->no_rm_kunjungan }}</span></td>
                <td>
                    <p class="font-semibold text-slate-800">{{ $r->pasien->nama??'-' }}</p>
                    <p class="text-xs text-slate-400">{{ $r->pasien->no_rm??'' }}</p>
                </td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ $r->poliklinik->nama??'-' }}</td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ $r->dokter->nama??'-' }}</td>
                <td class="max-w-[160px]">
                    <p class="text-sm font-medium truncate">{{ $r->diagnosis }}</p>
                    <p class="text-xs text-slate-400 truncate">{{ Str::limit($r->keluhan,40) }}</p>
                </td>
                <td class="hidden lg:table-cell text-slate-500 text-sm">{{ $r->tgl_kunjungan->format('d/m/Y') }}</td>
                <td><x-status-badge :status="$r->status"/></td>
                <td>
                    <div class="flex gap-1">
                        <a href="{{ route('rekam-medis.show',$r) }}" class="act-btn">👁️</a>
                        <a href="{{ route('rekam-medis.edit',$r) }}" class="act-btn">✏️</a>
                        <form method="POST" action="{{ route('rekam-medis.destroy',$r) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn" onclick="return confirm('Hapus rekam medis ini?')">🗑️</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <x-table-empty icon="📋" message="Belum ada data rekam medis" :colspan="8" create-route="rekam-medis.create"/>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($rekams->hasPages())
    <div class="px-6 py-4 border-t border-gray-100">{{ $rekams->withQueryString()->links() }}</div>
    @endif
</div>
<style>.act-btn{@apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer;}</style>
@endsection
