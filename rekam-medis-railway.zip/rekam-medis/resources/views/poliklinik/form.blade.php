@extends('layouts.app')
@section('title', isset($poliklinik) ? '✏️ Edit Poliklinik' : '➕ Tambah Poliklinik')
@section('content')
<div class="max-w-xl mx-auto">
    <div class="card">
        <div class="card-header">
            <h3 class="font-bold">{{ isset($poliklinik)?'Edit Poliklinik':'Tambah Poliklinik' }}</h3>
            <a href="{{ route('poliklinik.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ isset($poliklinik)?route('poliklinik.update',$poliklinik):route('poliklinik.store') }}">
                @csrf @if(isset($poliklinik)) @method('PUT') @endif
                <div class="space-y-4">
                    <div>
                        <label class="form-label">Nama Poliklinik *</label>
                        <input type="text" name="nama" value="{{ old('nama',$poliklinik->nama??'') }}" class="form-input" placeholder="Poli Umum" required>
                    </div>
                    <div>
                        <label class="form-label">Gedung / Lantai</label>
                        <input type="text" name="gedung" value="{{ old('gedung',$poliklinik->gedung??'') }}" class="form-input" placeholder="Gedung A / Lantai 1">
                    </div>
                    <div>
                        <label class="form-label">Dokter Penanggung Jawab</label>
                        <select name="dokter_id" class="form-select">
                            <option value="">-- Pilih Dokter --</option>
                            @foreach($dokters as $d)
                            <option value="{{ $d->id }}" {{ old('dokter_id',$poliklinik->dokter_id??'')==$d->id?'selected':'' }}>{{ $d->nama }} — {{ $d->spesialis }}</option>
                            @endforeach
                        </select>
                    </div>
                    @if(isset($poliklinik))
                    <div>
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="Aktif" {{ $poliklinik->status=='Aktif'?'selected':'' }}>Aktif</option>
                            <option value="Non-Aktif" {{ $poliklinik->status=='Non-Aktif'?'selected':'' }}>Non-Aktif</option>
                        </select>
                    </div>
                    @endif
                </div>
                <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                    <button type="submit" class="btn btn-primary">💾 {{ isset($poliklinik)?'Update':'Simpan' }}</button>
                    <a href="{{ route('poliklinik.index') }}" class="btn btn-outline">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
