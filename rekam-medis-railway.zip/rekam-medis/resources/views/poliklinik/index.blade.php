@extends('layouts.app')
@section('title', '🏥 Poliklinik')
@section('content')
<div class="flex justify-between items-center mb-6">
    <p class="text-slate-500 text-sm">Total <strong>{{ $polikliniks->total() }}</strong> poliklinik</p>
    <a href="{{ route('poliklinik.create') }}" class="btn btn-primary">➕ Tambah Poli</a>
</div>
<div class="card">
    <div class="card-header"><h3 class="font-bold">Data Poliklinik</h3></div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr><th>Kode</th><th>Nama Poliklinik</th><th class="hidden md:table-cell">Gedung</th><th>Dokter PJ</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            @forelse($polikliniks as $p)
            <tr>
                <td><span class="font-mono text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">{{ $p->kode }}</span></td>
                <td class="font-semibold">{{ $p->nama }}</td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ $p->gedung??'-' }}</td>
                <td class="text-slate-600 text-sm">{{ $p->dokter->nama??'-' }}</td>
                <td><span class="badge {{ $p->status=='Aktif'?'badge-green':'badge-gray' }}">{{ $p->status }}</span></td>
                <td>
                    <div class="flex gap-1">
                        <a href="{{ route('poliklinik.edit',$p) }}" class="act-btn">✏️</a>
                        <form method="POST" action="{{ route('poliklinik.destroy',$p) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn" onclick="return confirm('Hapus poli {{ $p->nama }}?')">🗑️</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" class="text-center py-10 text-slate-400"><p class="text-3xl mb-2">🏥</p><p>Belum ada poliklinik</p></td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($polikliniks->hasPages())<div class="px-6 py-4 border-t">{{ $polikliniks->links() }}</div>@endif
</div>
<style>.act-btn{@apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer;}</style>
@endsection
