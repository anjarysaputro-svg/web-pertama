@extends('layouts.app')
@section('title', isset($dokter) ? '✏️ Edit Dokter' : '➕ Tambah Dokter')
@section('content')
<div class="max-w-2xl mx-auto">
    <div class="card">
        <div class="card-header">
            <h3 class="font-bold">{{ isset($dokter)?'Edit Data Dokter':'Tambah Dokter Baru' }}</h3>
            <a href="{{ route('dokter.index') }}" class="btn btn-outline btn-sm">← Kembali</a>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ isset($dokter)?route('dokter.update',$dokter):route('dokter.store') }}">
                @csrf @if(isset($dokter)) @method('PUT') @endif
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div class="md:col-span-2">
                        <label class="form-label">Nama Dokter *</label>
                        <input type="text" name="nama" value="{{ old('nama',$dokter->nama??'') }}" class="form-input" placeholder="dr. Nama Dokter" required>
                        @error('nama')<p class="form-error">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="form-label">Spesialis *</label>
                        <select name="spesialis" class="form-select" required>
                            @foreach(['Dokter Umum','Penyakit Dalam','Anak','Kandungan & Kebidanan','Bedah Umum','THT','Mata','Kulit & Kelamin','Saraf','Jantung','Paru','Ortopedi','Psikiatri'] as $s)
                            <option value="{{ $s }}" {{ old('spesialis',$dokter->spesialis??'')==$s?'selected':'' }}>{{ $s }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="form-label">No. SIP</label>
                        <input type="text" name="sip" value="{{ old('sip',$dokter->sip??'') }}" class="form-input" placeholder="SIP-xxx/2024">
                    </div>
                    <div>
                        <label class="form-label">No. HP</label>
                        <input type="text" name="no_hp" value="{{ old('no_hp',$dokter->no_hp??'') }}" class="form-input" placeholder="08xx-xxxx-xxxx">
                    </div>
                    <div>
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="Aktif" {{ old('status',$dokter->status??'')=='Aktif'?'selected':'' }}>Aktif</option>
                            <option value="Non-Aktif" {{ old('status',$dokter->status??'')=='Non-Aktif'?'selected':'' }}>Non-Aktif</option>
                        </select>
                    </div>
                    <div class="md:col-span-2">
                        <label class="form-label">Jadwal Praktek</label>
                        <input type="text" name="jadwal" value="{{ old('jadwal',$dokter->jadwal??'') }}" class="form-input" placeholder="Senin–Jumat, 08:00–14:00">
                    </div>
                    @if(isset($users) && $users->count())
                    <div class="md:col-span-2">
                        <label class="form-label">Link ke User (opsional)</label>
                        <select name="user_id" class="form-select">
                            <option value="">-- Tidak di-link --</option>
                            @foreach($users as $u)
                            <option value="{{ $u->id }}" {{ old('user_id',$dokter->user_id??'')==$u->id?'selected':'' }}>{{ $u->name }} ({{ $u->email }})</option>
                            @endforeach
                        </select>
                    </div>
                    @endif
                </div>
                <div class="flex gap-3 mt-6 pt-5 border-t border-gray-100">
                    <button type="submit" class="btn btn-primary">💾 {{ isset($dokter)?'Update':'Simpan' }}</button>
                    <a href="{{ route('dokter.index') }}" class="btn btn-outline">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
