@extends('layouts.app')
@section('title', '🩺 Data Dokter')
@section('content')
<div class="flex justify-between items-center mb-6">
    <p class="text-slate-500 text-sm">Total <strong>{{ $dokters->total() }}</strong> dokter</p>
    <a href="{{ route('dokter.create') }}" class="btn btn-primary">➕ Tambah Dokter</a>
</div>
<div class="card">
    <div class="card-header"><h3 class="font-bold">Daftar Dokter</h3></div>
    <div class="overflow-x-auto">
        <table class="tbl">
            <thead><tr><th>Nama Dokter</th><th>Spesialis</th><th class="hidden md:table-cell">No. HP</th><th class="hidden lg:table-cell">Jadwal</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            @forelse($dokters as $d)
            <tr>
                <td>
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">{{ substr($d->nama,0,1) }}</div>
                        <div><p class="font-semibold">{{ $d->nama }}</p><p class="text-xs text-slate-400">{{ $d->sip??'-' }}</p></div>
                    </div>
                </td>
                <td><span class="badge badge-blue">{{ $d->spesialis }}</span></td>
                <td class="hidden md:table-cell text-slate-500 text-sm">{{ $d->no_hp??'-' }}</td>
                <td class="hidden lg:table-cell text-slate-500 text-sm">{{ $d->jadwal??'-' }}</td>
                <td><span class="badge {{ $d->status=='Aktif'?'badge-green':'badge-gray' }}">{{ $d->status }}</span></td>
                <td>
                    <div class="flex gap-1">
                        <a href="{{ route('dokter.edit',$d) }}" class="act-btn">✏️</a>
                        <form method="POST" action="{{ route('dokter.destroy',$d) }}" class="inline">
                            @csrf @method('DELETE')
                            <button type="submit" class="act-btn" onclick="return confirm('Hapus dokter {{ $d->nama }}?')">🗑️</button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" class="text-center py-10 text-slate-400"><p class="text-3xl mb-2">🩺</p><p>Belum ada dokter</p></td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($dokters->hasPages())<div class="px-6 py-4 border-t">{{ $dokters->links() }}</div>@endif
</div>
<style>.act-btn{@apply inline-flex items-center justify-center w-8 h-8 rounded-lg border border-gray-200 text-sm hover:bg-gray-50 transition cursor-pointer;}</style>
@endsection
