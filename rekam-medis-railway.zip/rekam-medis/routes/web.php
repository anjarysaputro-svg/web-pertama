<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PasienController;
use App\Http\Controllers\DokterController;
use App\Http\Controllers\PoliklinikController;
use App\Http\Controllers\ObatController;
use App\Http\Controllers\RekamMedisController;
use App\Http\Controllers\McuController;
use App\Http\Controllers\ResepController;
use App\Http\Controllers\TindakanController;
use App\Http\Controllers\BillingController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\NotifikasiController;
use App\Http\Controllers\Admin\UserController;

Route::get('/', fn() => redirect()->route('dashboard'));

require __DIR__.'/auth.php';

Route::middleware(['auth'])->group(function () {

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/profile', [App\Http\Controllers\ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');

    // Pasien
    Route::resource('pasien', PasienController::class);
    Route::get('pasien-export', [PasienController::class, 'export'])->name('pasien.export');

    // Dokter & Poliklinik (admin only)
    Route::resource('dokter', DokterController::class)->middleware('role:admin');
    Route::resource('poliklinik', PoliklinikController::class)->middleware('role:admin');

    // Obat (admin & apoteker)
    Route::resource('obat', ObatController::class)->middleware('role:admin|apoteker');

    // Rekam Medis (admin & dokter)
    Route::resource('rekam-medis', RekamMedisController::class)->middleware('role:admin|dokter');

    // MCU (admin & dokter)
    Route::resource('mcu', McuController::class)->middleware('role:admin|dokter');
    Route::get('mcu/{mcu}/pdf',   [McuController::class, 'pdf'])->name('mcu.pdf')->middleware('role:admin|dokter');

    // Resep (admin, dokter, apoteker)
    Route::resource('resep', ResepController::class)->middleware('role:admin|dokter|apoteker');

    // Tindakan (admin & dokter)
    Route::resource('tindakan', TindakanController::class)->middleware('role:admin|dokter');

    // Billing (admin & kasir)
    Route::resource('billing', BillingController::class)->middleware('role:admin|kasir');
    Route::get('billing/{billing}/invoice', [BillingController::class, 'invoice'])->name('billing.invoice')->middleware('role:admin|kasir');

    // Laporan (admin)
    Route::prefix('laporan')->name('laporan.')->middleware('role:admin')->group(function () {
        Route::get('/',              [LaporanController::class, 'index'])->name('index');
        Route::get('/export-excel', [LaporanController::class, 'exportExcel'])->name('excel');
        Route::get('/export-pdf',   [LaporanController::class, 'exportPdf'])->name('pdf');
    });

    // Notifikasi (admin)
    Route::prefix('notifikasi')->name('notifikasi.')->middleware('role:admin')->group(function () {
        Route::get('/',          [NotifikasiController::class, 'index'])->name('index');
        Route::post('/email',    [NotifikasiController::class, 'kirimEmail'])->name('email');
        Route::post('/whatsapp', [NotifikasiController::class, 'kirimWhatsapp'])->name('wa');
    });

    // User Management (admin)
    Route::resource('users', UserController::class)->middleware('role:admin');
});
